# الاختبارات: ما كُتب وما نُفِّذ

**نُفِّذ فعلاً: لا شيء من اختبارات Kotlin** (لا Gradle هنا). ستعمل على GitHub Actions داخل خطوة «Unit tests»، والنتيجة في `test-reports`.

| # | المطلوب | الملف / الاختبار | حالة |
|---|---|---|---|
| 1-2 | إضافة مشترك وحساب اشتراكه | FinanceRepositoryTest.addSubscriberAndComputeFee | مكتوب، لم يُشغَّل |
| 3-4 | توليد الجميع ومنع التكرار | generateForAllAndPreventDuplicate | مكتوب، لم يُشغَّل |
| 5-6 | تسديد كامل / جزئي | fullPayment / partialPayment | مكتوب، لم يُشغَّل |
| 7-8 | عدة أشهر وأقدم دين | multiMonthOldestFirst + PaymentAllocatorTest | مكتوب، لم يُشغَّل |
| 9-10 | إلغاء بقيد عكسي وصحة الرصيد | cancelReceiptReversal | مكتوب، لم يُشغَّل |
| 11 | تطابق الصندوق مع العمليات | cashMatchesOperations | مكتوب، لم يُشغَّل |
| 12 | مصروف/وقود | expenseAndFuel | مكتوب، لم يُشغَّل |
| 13-14 | راتب وسلفة | advanceAndPayroll | مكتوب، لم يُشغَّل |
| 15 | إغلاق الصندوق | closeCash | مكتوب، لم يُشغَّل |
| 16 | نسخ واستعادة | backupAndRestore | مكتوب، لم يُشغَّل |
| 17 | Migration دون فقد بيانات | حارس migrationsCoverSchemaVersion فقط | **غير مغطى فعلياً** (لا إصدار 2 بعد) |
| 18 | منع تكرار رقم السند | receiptSerials + فهرس فريد | مكتوب، لم يُشغَّل |
| 19 | الصلاحيات | permissions | مكتوب، لم يُشغَّل |
| 20 | العمل دون إنترنت | noInternetPermission | مكتوب، لم يُشغَّل |
| 21 | الاستحقاق وأيام التأخير (28/29/30/31) | DueDatesTest | مكتوب، لم يُشغَّل (منطقه فُحص بنسخة Python) |
| + | الشهر الأول، التنسيق، التفقيط، الهاتف، PIN، منع الدفعة المكررة والتراجع | CoreTests / idempotentAndRollback | مكتوب، لم يُشغَّل |

اختبارات قاعدة البيانات تعمل على JVM عبر Robolectric (لا تحتاج هاتفاً)، وقد تحتاج تعديلاً بسيطاً عند أول تشغيل.
لم يُنفَّذ أي اختبار على هاتف فعلي أو محاكٍ.
