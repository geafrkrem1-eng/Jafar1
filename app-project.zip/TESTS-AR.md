# الاختبارات — الإصدار 2.0.0

**نُفِّذ فعلاً: لا شيء من اختبارات Kotlin** (لا Gradle في بيئتي). كلها تعمل على GitHub Actions في خطوة «Unit tests»، والنتيجة في `test-reports`. أرسل لي التقرير وأصلح ما يفشل. (خطوة الاختبارات لا توقف بناء الـ APK.)

| الحالة المطلوبة في تعليماتك | الاختبار | الحالة |
|---|---|---|
| إنشاء دورة شهرية تلقائياً + لا تكرار | FinanceRepositoryTest.autoCyclesAndDueOnFirstDay | كُتب، لم يُشغَّل |
| الاستحقاق من أول يوم | نفس الاختبار + CyclesTest | كُتب، لم يُشغَّل |
| التسديد خلال 1–5 وتحول المتبقي إلى دين بعدها | graceThenLate + CyclesTest.statusAndLateDays | كُتب، لم يُشغَّل |
| اشتراك نسبي منتصف الشهر (70,000 → 35,000) | proratedMidMonthThenFull + CyclesTest | كُتب، لم يُشغَّل (الحساب الحسابي فُحص يدوياً) |
| اشتراك من ينضم آخر يوم | proratedLastDayAndImmediatePayment | كُتب، لم يُشغَّل |
| التحول إلى كامل في الدورة التالية | proratedMidMonthThenFull | كُتب، لم يُشغَّل |
| تسديد فوري / عدم التسديد فيصير ديناً | proratedLastDayAndImmediatePayment | كُتب، لم يُشغَّل |
| تغيير السعر لأشهر محددة وعدم تغيّر ما لم يُحدَّد | priceChangeForSelectedMonths | كُتب، لم يُشغَّل |
| عدم تغيّر الفواتير المسدَّدة/المغلقة | priceChangeSkipsPaidAndClosed | كُتب، لم يُشغَّل |
| البوردات: توزيع ونقل وحذف دون مساس بالحسابات | boardsMoveAndDeleteKeepAccounts | كُتب، لم يُشغَّل |
| إنشاء وصل صحيح + المنفذ + حالة التسديد | reprintAndStatementConsistency (حفظ المنفذ والحالة) | كُتب، لم يُشغَّل |
| كشف حساب صحيح بعد الدفع والإلغاء | reprintAndStatementConsistency | كُتب، لم يُشغَّل |
| إعادة الطباعة لا تنشئ حركة مالية | reprintAndStatementConsistency | كُتب، لم يُشغَّل |
| صحة الأرصدة والديون بعد عمليات متعددة | balancesAfterManyOperations | كُتب، لم يُشغَّل |
| إعادة تفعيل داخل الدورة (نسبي)، التفعيل بتاريخ سابق | reactivationMidCycleIsProrated / backdatedActivationCatchesUp | كُتب، لم يُشغَّل |
| ظهور اسم المدير والمولدة والمنفذ والتاريخ والساعة في المستند | — | **غير مختبر آلياً** (واجهة/رسم)، يُراجَع بالعين |
| Migration 1→2 دون فقد بيانات | حارس العدد فقط + فحص SQL على SQLite يدوياً | **غير مغطى فعلياً بـ Room** |

بقية اختبارات الإصدار السابق (القبض، الإلغاء، الصندوق، الرواتب، النسخ الاحتياطي، التنسيق بلغة عربية...) ما زالت قائمة.
