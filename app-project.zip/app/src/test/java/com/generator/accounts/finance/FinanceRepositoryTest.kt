package com.generator.accounts.finance

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.generator.accounts.Container
import com.generator.accounts.core.*
import com.generator.accounts.data.*
import com.generator.accounts.output.Backup
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.util.concurrent.Executors

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class FinanceRepositoryTest {
    private lateinit var db: AppDatabase
    private lateinit var repo: FinanceRepository
    private var clock = 1_760_000_000_000L
    private val U = "tester"

    @Before fun setup() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, AppDatabase::class.java).allowMainThreadQueries()
            .setTransactionExecutor(Executors.newSingleThreadExecutor()).setQueryExecutor(Executors.newSingleThreadExecutor()).build()
        repo = FinanceRepository(db, { "dev1" }, { "A" }, { clock++ })
    }
    @After fun tearDown() { db.close() }

    private fun addSub(name: String = "علي", amps: Int = 5, day: Int = 10): Subscriber = runBlocking {
        val r = repo.addSubscriber(SubscriberInput(name, "07701234567", "", "", amps, LocalDate.of(2026, 1, 10).toEpochDay(), day, "", null), U, "FULL", 10000)
        (r as FinResult.Ok).value
    }
    private fun month(ym: String) = runBlocking { repo.createMonth(ym, 10000, "FULL", U) }
    private fun paid(sid: String) = runBlocking { db.invoices().balances(sid).sumOf { it.paid } }
    private fun cash() = runBlocking { db.cash().balanceNow() }
    private fun collect(sid: String, amt: Long, key: String = java.util.UUID.randomUUID().toString()) = runBlocking { repo.collect(sid, amt, "نقداً", null, U, key) }

    // 1+2: إضافة مشترك وحساب اشتراكه 5 × 10,000
    @Test fun addSubscriberAndComputeFee() { val s = addSub(); assertEquals(50_000L, s.monthlyFeeIqd); assertEquals(1001, s.code.toInt()) }

    // 3+4: توليد اشتراك الجميع ومنع التكرار
    @Test fun generateForAllAndPreventDuplicate() {
        addSub("أ"); addSub("ب"); addSub("ج")
        assertEquals(3, (month("2026-01") as FinResult.Ok).value)
        assertTrue(month("2026-01") is FinResult.Err)
        assertEquals(3L, ReportEngineCount("invoices"))
    }
    private fun ReportEngineCount(t: String) = ReportEngine.scalar(db, "SELECT COUNT(*) FROM $t")

    // 5: تسديد كامل
    @Test fun fullPayment() { val s = addSub(); month("2026-01"); val r = collect(s.id, 50_000); assertTrue(r is FinResult.Ok)
        assertEquals(50_000L, paid(s.id)); assertEquals(50_000L, cash()); assertEquals(0L, (r as FinResult.Ok).value.balanceAfterIqd) }

    // 6: تسديد جزئي
    @Test fun partialPayment() { val s = addSub(); month("2026-01"); val r = collect(s.id, 20_000) as FinResult.Ok
        assertEquals(30_000L, r.value.balanceAfterIqd); assertEquals(20_000L, paid(s.id)) }

    // 7+8: عدة أشهر بدفعة واحدة والتوزيع على الأقدم أولاً
    @Test fun multiMonthOldestFirst() {
        val s = addSub(); month("2026-01"); month("2026-02"); month("2026-03")
        collect(s.id, 120_000)
        val b = runBlocking { db.invoices().balances(s.id) }
        assertEquals(listOf(50_000L, 50_000L, 20_000L), b.map { it.paid })
    }

    // 9+10: إلغاء بقيد عكسي وصحة الرصيد بعده، السند الأصلي يبقى
    @Test fun cancelReceiptReversal() {
        val s = addSub(); month("2026-01"); val r = (collect(s.id, 50_000) as FinResult.Ok).value
        assertTrue(runBlocking { repo.cancelReceipt(r.id, "خطأ في الإدخال", U) } is FinResult.Ok)
        assertEquals(0L, paid(s.id)); assertEquals(0L, cash())
        val again = runBlocking { db.receipts().get(r.id) }!!
        assertEquals("CANCELLED", again.status); assertEquals(1L, ReportEngineCount("receipts"))
        assertEquals(2L, ReportEngineCount("receipt_allocations"))          // الأصلي + العكسي
        assertTrue(runBlocking { repo.cancelReceipt(r.id, "مرة ثانية", U) } is FinResult.Err)
        assertTrue(runBlocking { repo.cancelReceipt(r.id, "", U) } is FinResult.Err)
    }

    // منع تكرار الدفعة (Idempotency) والتراجع الكامل عند الخطأ
    @Test fun idempotentAndRollback() {
        val s = addSub(); month("2026-01")
        val a = (collect(s.id, 10_000, "k1") as FinResult.Ok).value; val b = (collect(s.id, 10_000, "k1") as FinResult.Ok).value
        assertEquals(a.id, b.id); assertEquals(10_000L, cash())
        assertTrue(collect(s.id, 999_999_999, "k2") is FinResult.Err)           // أكبر من المستحق
        assertEquals(1L, ReportEngineCount("receipts")); assertEquals(1L, ReportEngineCount("cash_entries"))
    }

    // 18: ترقيم السندات متسلسل ولا يتكرر
    @Test fun receiptSerials() {
        val s = addSub(); month("2026-01")
        val a = (collect(s.id, 1000) as FinResult.Ok).value; val b = (collect(s.id, 1000) as FinResult.Ok).value
        assertEquals("A-${a.year}-0001", a.serialNo); assertEquals("A-${b.year}-0002", b.serialNo)
    }

    // 11: تطابق حركات الصندوق مع العمليات
    @Test fun cashMatchesOperations() {
        val s = addSub(); month("2026-01"); collect(s.id, 30_000)
        runBlocking { repo.addExpense(ExpenseInput("GENERAL", "إيجار", 10_000, 20000, "", "نقداً", "x", "", null), U) }
        assertEquals(20_000L, cash())
        assertEquals(1L, ReportEngine.scalar(db, "SELECT COUNT(*) FROM cash_entries WHERE sourceType='RECEIPT'"))
        assertEquals(1L, ReportEngine.scalar(db, "SELECT COUNT(*) FROM cash_entries WHERE sourceType='EXPENSE'"))
    }

    // 12: مصروف ووقود وإلغاؤه
    @Test fun expenseAndFuel() {
        val e = runBlocking { repo.addExpense(ExpenseInput("FUEL", "وقود", 0, 20000, "", "نقداً", "", "", null, "ديزل", 100_500, 1000, "مورد", "1"), U) } as FinResult.Ok
        assertEquals(-100_500L, cash())
        assertTrue(runBlocking { repo.voidExpense(e.value, "خطأ", U) } is FinResult.Ok); assertEquals(0L, cash())
    }

    // 13+14: سلفة وخصمها وصرف راتب
    @Test fun advanceAndPayroll() = runBlocking {
        val w = (repo.saveWorker(null, "عامل", "", "", "فني", 20000, "MONTHLY", 500_000, "ACTIVE", "", U) as FinResult.Ok).value
        repo.addAdvance(w, 100_000, 20000, "سلفة", U)
        assertTrue(repo.createSlip(w, "2026-01", 0, 0, 0, 150_000, U) is FinResult.Err)       // أكثر من المتبقي
        val slip = (repo.createSlip(w, "2026-01", 0, 0, 0, 40_000, U) as FinResult.Ok).value
        assertEquals(460_000L, db.slips().get(slip)!!.netIqd)
        repo.approveSlip(slip, U); repo.paySlip(slip, U)
        assertEquals(-560_000L, db.cash().balanceNow())                                      // 100,000 سلفة + 460,000 راتب
        assertEquals(60_000L, repo.advanceBalance(w))
        assertTrue(repo.voidSlip(slip, "x", U) is FinResult.Err)                             // لا إلغاء بعد الصرف
    }

    // 15: إغلاق الصندوق
    @Test fun closeCash() = runBlocking {
        repo.manualCash("IN", 100_000, "أخرى", "افتتاحي", U)
        assertTrue(repo.closeCash(90_000, "", U) is FinResult.Err)
        assertEquals(-10_000L, (repo.closeCash(90_000, "نقص", U) as FinResult.Ok).value)
        assertEquals(0L, (repo.closeCash(100_000, "", U) as FinResult.Ok).value)
    }

    // الأشهر المغلقة لا تقبل تعديلاً عشوائياً
    @Test fun closedMonthRejectsAdjust() = runBlocking {
        val s = addSub(); month("2026-01")
        val inv = db.invoices().forSubscriber(s.id).first()
        assertTrue(repo.adjustInvoice(inv.id, -5000, "خصم", U) is FinResult.Ok)
        repo.closeMonth("2026-01", U)
        assertTrue(repo.adjustInvoice(inv.id, 1000, "رسم", U) is FinResult.Err)
    }

    // أعمدة جدول المشتركين من القاعدة: الدين السابق والمسدد والمتبقي (التوزيع أقدم أولاً)
    @Test fun subscriberRowsColumns() = runBlocking {
        val s = addSub(); month("2026-01"); month("2026-02"); collect(s.id, 70_000)
        val row = db.subscribers().rows("2026-02", "", "", 0, 0, 10, 0).first()
        assertEquals(0L, row.prevDebt)            // يناير سُدّد بالكامل
        assertEquals(20_000L, row.paidThisMonth)  // 20,000 من فبراير
        assertEquals(30_000L, row.remaining)
    }

    // 16: نسخ احتياطي واستعادة
    @Test fun backupAndRestore() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val c = Container(ctx); runBlocking { c.init() }
        runBlocking { c.repo.addSubscriber(SubscriberInput("أ", "", "", "", 1, 20000, 1, "", null), U, "FULL", 10000) }
        val out = ByteArrayOutputStream(); Backup.write(c, out)
        runBlocking { c.repo.addSubscriber(SubscriberInput("ب", "", "", "", 1, 20000, 1, "", null), U, "FULL", 10000) }
        assertEquals("الملف التالف مرفوض", "الملف تالف أو غير مكتمل", Backup.restore(c, ByteArrayInputStream(byteArrayOf(1, 2, 3))))
        assertNull(Backup.restore(c, ByteArrayInputStream(out.toByteArray())))
        val db2 = AppDatabase.build(ctx)
        assertEquals(1L, ReportEngine.scalar(db2, "SELECT COUNT(*) FROM subscribers")); db2.close()
    }

    // 17 (حارس): كل رفع لإصدار المخطط يتطلب Migration فعلياً
    @Test fun migrationsCoverSchemaVersion() {
        val v = AppDatabase::class.java.getAnnotation(Database::class.java)!!.version
        assertEquals(v - 1, Migrations.ALL.size)
    }

    // 19: الصلاحيات
    @Test fun permissions() {
        assertTrue(Perm.effective("ADMIN", "").containsAll(Perm.all))
        assertFalse(Perm.CANCEL_RECEIPT in Perm.effective("STAFF", Perm.staffDefault.joinToString(",")))
        assertFalse(Perm.USERS in Perm.accountant); assertTrue(Perm.COLLECT in Perm.accountant)
    }

    // 20: العمل دون إنترنت (لا صلاحية INTERNET)
    @Test fun noInternetPermission() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val info = ctx.packageManager.getPackageInfo(ctx.packageName, android.content.pm.PackageManager.GET_PERMISSIONS)
        assertFalse((info.requestedPermissions ?: emptyArray()).contains("android.permission.INTERNET"))
    }
}
