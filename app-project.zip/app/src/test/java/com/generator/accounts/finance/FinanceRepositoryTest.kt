package com.generator.accounts.finance

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.generator.accounts.Container
import com.generator.accounts.core.*
import com.generator.accounts.data.*
import com.generator.accounts.output.Backup
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.time.YearMonth
import java.util.concurrent.Executors

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class FinanceRepositoryTest {
    private lateinit var db: AppDatabase
    private lateinit var repo: FinanceRepository
    private var clock = 1_760_000_000_000L
    private val U = "tester"

    @Before fun setup() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, AppDatabase::class.java).allowMainThreadQueries()
            .setTransactionExecutor(Executors.newSingleThreadExecutor()).setQueryExecutor(Executors.newSingleThreadExecutor()).build()
        repo = FinanceRepository(db, { "dev1" }, { "A" }, { clock++ })
    }
    @After fun tearDown() { db.close() }

    private fun addSub(name: String = "علي", amps: Int = 5, day: Int = 10): Subscriber = runBlocking {
        val r = repo.addSubscriber(SubscriberInput(name, "07701234567", "", "", amps, LocalDate.of(2026, 1, 10).toEpochDay(), day, "", null), U, "FULL", 10000)
        (r as FinResult.Ok).value
    }
    private fun month(ym: String) = runBlocking { repo.createMonth(ym, 10000, "FULL", U) }
    private fun paid(sid: String) = runBlocking { db.invoices().balances(sid).sumOf { it.paid } }
    private fun cash() = runBlocking { db.cash().balanceNow() }
    private fun collect(sid: String, amt: Long, key: String = java.util.UUID.randomUUID().toString()) = runBlocking { repo.collect(sid, amt, "نقداً", null, U, key) }

    // 1+2: إضافة مشترك وحساب اشتراكه 5 × 10,000
    @Test fun addSubscriberAndComputeFee() { val s = addSub(); assertEquals(50_000L, s.monthlyFeeIqd); assertEquals(1001, s.code.toInt()) }

    // 3+4: توليد اشتراك الجميع ومنع التكرار
    @Test fun generateForAllAndPreventDuplicate() {
        addSub("أ"); addSub("ب"); addSub("ج")
        assertEquals(3, (month("2026-01") as FinResult.Ok).value)
        assertTrue(month("2026-01") is FinResult.Err)
        assertEquals(3L, ReportEngineCount("invoices"))
    }
    private fun ReportEngineCount(t: String) = ReportEngine.scalar(db, "SELECT COUNT(*) FROM $t")

    // 5: تسديد كامل
    @Test fun fullPayment() { val s = addSub(); month("2026-01"); val r = collect(s.id, 50_000); assertTrue(r is FinResult.Ok)
        assertEquals(50_000L, paid(s.id)); assertEquals(50_000L, cash()); assertEquals(0L, (r as FinResult.Ok).value.balanceAfterIqd) }

    // 6: تسديد جزئي
    @Test fun partialPayment() { val s = addSub(); month("2026-01"); val r = collect(s.id, 20_000) as FinResult.Ok
        assertEquals(30_000L, r.value.balanceAfterIqd); assertEquals(20_000L, paid(s.id)) }

    // 7+8: عدة أشهر بدفعة واحدة والتوزيع على الأقدم أولاً
    @Test fun multiMonthOldestFirst() {
        val s = addSub(); month("2026-01"); month("2026-02"); month("2026-03")
        collect(s.id, 120_000)
        val b = runBlocking { db.invoices().balances(s.id) }
        assertEquals(listOf(50_000L, 50_000L, 20_000L), b.map { it.paid })
    }

    // 9+10: إلغاء بقيد عكسي وصحة الرصيد بعده، السند الأصلي يبقى
    @Test fun cancelReceiptReversal() {
        val s = addSub(); month("2026-01"); val r = (collect(s.id, 50_000) as FinResult.Ok).value
        assertTrue(runBlocking { repo.cancelReceipt(r.id, "خطأ في الإدخال", U) } is FinResult.Ok)
        assertEquals(0L, paid(s.id)); assertEquals(0L, cash())
        val again = runBlocking { db.receipts().get(r.id) }!!
        assertEquals("CANCELLED", again.status); assertEquals(1L, ReportEngineCount("receipts"))
        assertEquals(2L, ReportEngineCount("receipt_allocations"))          // الأصلي + العكسي
        assertTrue(runBlocking { repo.cancelReceipt(r.id, "مرة ثانية", U) } is FinResult.Err)
        assertTrue(runBlocking { repo.cancelReceipt(r.id, "", U) } is FinResult.Err)
    }

    // منع تكرار الدفعة (Idempotency) والتراجع الكامل عند الخطأ
    @Test fun idempotentAndRollback() {
        val s = addSub(); month("2026-01")
        val a = (collect(s.id, 10_000, "k1") as FinResult.Ok).value; val b = (collect(s.id, 10_000, "k1") as FinResult.Ok).value
        assertEquals(a.id, b.id); assertEquals(10_000L, cash())
        assertTrue(collect(s.id, 999_999_999, "k2") is FinResult.Err)           // أكبر من المستحق
        assertEquals(1L, ReportEngineCount("receipts")); assertEquals(1L, ReportEngineCount("cash_entries"))
    }

    // 18: ترقيم السندات متسلسل ولا يتكرر
    @Test fun receiptSerials() {
        val s = addSub(); month("2026-01")
        val a = (collect(s.id, 1000) as FinResult.Ok).value; val b = (collect(s.id, 1000) as FinResult.Ok).value
        assertEquals("A-${a.year}-0001", a.serialNo); assertEquals("A-${b.year}-0002", b.serialNo)
    }

    // 11: تطابق حركات الصندوق مع العمليات
    @Test fun cashMatchesOperations() {
        val s = addSub(); month("2026-01"); collect(s.id, 30_000)
        runBlocking { repo.addExpense(ExpenseInput("GENERAL", "إيجار", 10_000, 20000, "", "نقداً", "x", "", null), U) }
        assertEquals(20_000L, cash())
        assertEquals(1L, ReportEngine.scalar(db, "SELECT COUNT(*) FROM cash_entries WHERE sourceType='RECEIPT'"))
        assertEquals(1L, ReportEngine.scalar(db, "SELECT COUNT(*) FROM cash_entries WHERE sourceType='EXPENSE'"))
    }

    // 12: مصروف ووقود وإلغاؤه
    @Test fun expenseAndFuel() {
        val e = runBlocking { repo.addExpense(ExpenseInput("FUEL", "وقود", 0, 20000, "", "نقداً", "", "", null, "ديزل", 100_500, 1000, "مورد", "1"), U) } as FinResult.Ok
        assertEquals(-100_500L, cash())
        assertTrue(runBlocking { repo.voidExpense(e.value, "خطأ", U) } is FinResult.Ok); assertEquals(0L, cash())
    }

    // 13+14: سلفة وخصمها وصرف راتب
    @Test fun advanceAndPayroll() = runBlocking {
        val w = (repo.saveWorker(null, "عامل", "", "", "فني", 20000, "MONTHLY", 500_000, "ACTIVE", "", U) as FinResult.Ok).value
        repo.addAdvance(w, 100_000, 20000, "سلفة", U)
        assertTrue(repo.createSlip(w, "2026-01", 0, 0, 0, 150_000, U) is FinResult.Err)       // أكثر من المتبقي
        val slip = (repo.createSlip(w, "2026-01", 0, 0, 0, 40_000, U) as FinResult.Ok).value
        assertEquals(460_000L, db.slips().get(slip)!!.netIqd)
        repo.approveSlip(slip, U); repo.paySlip(slip, U)
        assertEquals(-560_000L, db.cash().balanceNow())                                      // 100,000 سلفة + 460,000 راتب
        assertEquals(60_000L, repo.advanceBalance(w))
        assertTrue(repo.voidSlip(slip, "x", U) is FinResult.Err)                             // لا إلغاء بعد الصرف
    }

    // 15: إغلاق الصندوق
    @Test fun closeCash() = runBlocking {
        repo.manualCash("IN", 100_000, "أخرى", "افتتاحي", U)
        assertTrue(repo.closeCash(90_000, "", U) is FinResult.Err)
        assertEquals(-10_000L, (repo.closeCash(90_000, "نقص", U) as FinResult.Ok).value)
        assertEquals(0L, (repo.closeCash(100_000, "", U) as FinResult.Ok).value)
    }

    // الأشهر المغلقة لا تقبل تعديلاً عشوائياً
    @Test fun closedMonthRejectsAdjust() = runBlocking {
        val s = addSub(); month("2026-01")
        val inv = db.invoices().forSubscriber(s.id).first()
        assertTrue(repo.adjustInvoice(inv.id, -5000, "خصم", U) is FinResult.Ok)
        repo.closeMonth("2026-01", U)
        assertTrue(repo.adjustInvoice(inv.id, 1000, "رسم", U) is FinResult.Err)
    }

    // أعمدة جدول المشتركين من القاعدة: الدين السابق والمسدد والمتبقي (التوزيع أقدم أولاً)
    @Test fun subscriberRowsColumns() = runBlocking {
        val s = addSub(); month("2026-01"); month("2026-02"); collect(s.id, 70_000)
        val row = db.subscribers().rows("2026-02", "", "", "", 0, 0, 10, 0).first()
        assertEquals(0L, row.prevDebt)            // يناير سُدّد بالكامل
        assertEquals(20_000L, row.paidThisMonth)  // 20,000 من فبراير
        assertEquals(30_000L, row.remaining)
    }

    // 16: نسخ احتياطي واستعادة
    @Test fun backupAndRestore() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val c = Container(ctx); runBlocking { c.init() }
        runBlocking { c.repo.addSubscriber(SubscriberInput("أ", "", "", "", 1, 20000, 1, "", null), U, "FULL", 10000) }
        val out = ByteArrayOutputStream(); Backup.write(c, out)
        runBlocking { c.repo.addSubscriber(SubscriberInput("ب", "", "", "", 1, 20000, 1, "", null), U, "FULL", 10000) }
        assertEquals("الملف التالف مرفوض", "الملف تالف أو غير مكتمل", Backup.restore(c, ByteArrayInputStream(byteArrayOf(1, 2, 3))))
        assertNull(Backup.restore(c, ByteArrayInputStream(out.toByteArray())))
        val db2 = AppDatabase.build(ctx)
        assertEquals(1L, ReportEngine.scalar(db2, "SELECT COUNT(*) FROM subscribers")); db2.close()
    }

    // 17 (حارس): كل رفع لإصدار المخطط يتطلب Migration فعلياً
    @Test fun migrationsCoverSchemaVersion() {
        val v = db.openHelper.readableDatabase.version
        assertEquals(v - 1, Migrations.ALL.size)
    }

    // 19: الصلاحيات
    @Test fun permissions() {
        assertTrue(Perm.effective("ADMIN", "").containsAll(Perm.all))
        assertFalse(Perm.CANCEL_RECEIPT in Perm.effective("STAFF", Perm.staffDefault.joinToString(",")))
        assertFalse(Perm.USERS in Perm.accountant); assertTrue(Perm.COLLECT in Perm.accountant)
    }

    // 20: العمل دون إنترنت (لا صلاحية INTERNET)
    @Test fun noInternetPermission() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val info = ctx.packageManager.getPackageInfo(ctx.packageName, android.content.pm.PackageManager.GET_PERMISSIONS)
        assertFalse((info.requestedPermissions ?: emptyArray()).contains("android.permission.INTERNET"))
    }

    // ═════════ التحديث 2: الدورات، فترة التسديد، النسبي، التسعير، البوردات ═════════
    private fun addAt(start: LocalDate, amps: Int = 7, mode: String = "PRORATED", board: String? = null): Subscriber = runBlocking {
        (repo.addSubscriber(SubscriberInput("م", "07701234567", "", "", amps, start.toEpochDay(), start.dayOfMonth, "", null, board), U, mode, 10000) as FinResult.Ok).value
    }
    private fun invoiceOf(sid: String, ym: String) = runBlocking { db.invoices().forSubscriber(sid).first { it.periodYm == ym } }
    private fun cycles(today: LocalDate) = runBlocking { repo.ensureCycles(today, U, "PRORATED", 10000) }
    private fun d(y: Int, m: Int, day: Int) = LocalDate.of(y, m, day)

    // 1+2: إنشاء الدورات تلقائياً، واستحقاق الاشتراك من أول يوم، وعدم التكرار
    @Test fun autoCyclesAndDueOnFirstDay() {
        assertEquals(0, (cycles(d(2026, 11, 16)) as FinResult.Ok).value)             // لا مشتركين بعد
        val s = addAt(d(2026, 11, 1))
        val nov = invoiceOf(s.id, "2026-11")
        assertEquals(70_000L, nov.baseAmount); assertFalse(nov.isProrated)
        assertEquals(d(2026, 11, 1).toEpochDay(), nov.dueEpochDay); assertEquals(d(2026, 12, 1).toEpochDay(), nov.cycleEndEpochDay)
        assertEquals(30, nov.cycleDays)
        assertEquals(d(2026, 11, 5).toEpochDay(), nov.graceEndEpochDay)
        assertEquals(1, (cycles(d(2026, 12, 2)) as FinResult.Ok).value)             // دورة ديسمبر تلقائياً
        assertEquals(0, (cycles(d(2026, 12, 20)) as FinResult.Ok).value)            // لا تكرار
        assertEquals(2L, ReportEngineCount("months")); assertEquals(2L, ReportEngineCount("invoices"))
        assertEquals(31, invoiceOf(s.id, "2026-12").cycleDays)
    }

    // 3+4: فترة التسديد 1–5 ثم الدين المتأخر، ولا يختفي المبلغ
    @Test fun graceThenLate() {
        cycles(d(2026, 11, 1)); val s = addAt(d(2026, 11, 1)); val inv = invoiceOf(s.id, "2026-11")
        val ge = LocalDate.ofEpochDay(inv.graceEndEpochDay)
        assertEquals(Cycles.Status.IN_GRACE, Cycles.status(70_000, ge, d(2026, 11, 5)))
        assertEquals(Cycles.Status.LATE, Cycles.status(70_000, ge, d(2026, 11, 6)))
        assertEquals(1L, Cycles.lateDays(ge, d(2026, 11, 6)))
        assertEquals(70_000L, runBlocking { db.invoices().balances(s.id).sumOf { it.total - it.paid } })   // الدين باقٍ
        collect(s.id, 70_000)
        assertEquals(Cycles.Status.PAID, Cycles.status(0, ge, d(2026, 11, 6)))
    }

    // 5+7: اشتراك نسبي لمن ينضم 16/11 (70,000 × 15 ÷ 30 = 35,000) ثم كامل في الدورة التالية
    @Test fun proratedMidMonthThenFull() {
        cycles(d(2026, 11, 16)); val s = addAt(d(2026, 11, 16))
        val inv = invoiceOf(s.id, "2026-11")
        assertEquals(35_000L, inv.baseAmount); assertEquals(70_000L, inv.fullAmount)
        assertEquals(15, inv.daysCharged); assertEquals(30, inv.cycleDays); assertTrue(inv.isProrated)
        assertEquals(d(2026, 11, 16).toEpochDay(), inv.activationEpochDay); assertEquals(d(2026, 11, 16).toEpochDay(), inv.dueEpochDay)
        assertTrue((inv.firstMonthNote ?: "").contains("15 من 30"))
        cycles(d(2026, 12, 3))
        val dec = invoiceOf(s.id, "2026-12")
        assertEquals(70_000L, dec.baseAmount); assertFalse(dec.isProrated)
    }

    // 6: ينضم في آخر يوم من الدورة (يوم واحد) + سداد فوري + دين إن لم يسدد
    @Test fun proratedLastDayAndImmediatePayment() {
        cycles(d(2026, 11, 30)); val s = addAt(d(2026, 11, 30))
        val inv = invoiceOf(s.id, "2026-11")
        assertEquals(1, inv.daysCharged); assertEquals(2_333L, inv.baseAmount)
        val ge = LocalDate.ofEpochDay(inv.graceEndEpochDay)
        assertEquals(Cycles.Status.LATE, Cycles.status(2_333, ge, d(2026, 12, 1)))    // لم يسدد يوم التفعيل ⇒ دين
        val r = (collect(s.id, 2_333) as FinResult.Ok).value
        assertEquals(0L, r.balanceAfterIqd)
    }

    // تفعيل بتاريخ سابق: نسبي لدورة التفعيل ثم كامل لكل دورة موجودة بعدها
    @Test fun backdatedActivationCatchesUp() {
        runBlocking { repo.createMonth("2026-09", 10000, "PRORATED", U); repo.createMonth("2026-10", 10000, "PRORATED", U) }
        val s = addAt(d(2026, 9, 16))
        assertEquals(35_000L, invoiceOf(s.id, "2026-09").baseAmount)                  // أيلول 30 يوماً: 15 من 30
        assertEquals(70_000L, invoiceOf(s.id, "2026-10").baseAmount)
    }

    // 8+9: تغيير سعر لأشهر محددة، وعدم تغير المسدَّد، وعدم المساس بالأشهر غير المحددة
    @Test fun priceChangeForSelectedMonths() = runBlocking {
        cycles(d(2026, 11, 1)); val s = addAt(d(2026, 11, 1))
        assertEquals(70_000L, invoiceOf(s.id, "2026-11").baseAmount)
        val pv = repo.previewPriceChange(listOf("2026-11", "2026-12"), 7000, 10000).associate { it.ym to it.state }
        assertEquals("REPRICE", pv["2026-11"]); assertEquals("NOT_CREATED", pv["2026-12"])
        assertEquals(2, (repo.applyPriceChange(listOf("2026-11", "2026-12"), 7000, 10000, U) as FinResult.Ok).value)
        assertEquals(49_000L, invoiceOf(s.id, "2026-11").baseAmount)                  // 7 × 7,000
        repo.ensureCycles(d(2026, 12, 5), U, "PRORATED", 10000)
        assertEquals(49_000L, invoiceOf(s.id, "2026-12").baseAmount)                  // السعر المحفوظ للدورة
        repo.ensureCycles(d(2027, 1, 5), U, "PRORATED", 10000)
        assertEquals(70_000L, invoiceOf(s.id, "2027-01").baseAmount)                  // شهر غير محدد = السعر الافتراضي
        assertEquals(2L, ReportEngine.scalar(db, "SELECT COUNT(*) FROM audit_log WHERE entityType='PriceChange'"))   // سجل لكل شهر
        assertEquals(3L, ReportEngineCount("invoices"))                               // لا مطالبات مكررة
    }

    @Test fun priceChangeSkipsPaidAndClosed() = runBlocking {
        cycles(d(2026, 11, 1)); val s = addAt(d(2026, 11, 1))
        collect(s.id, 1000)
        assertEquals("SKIP_PAID", repo.previewPriceChange(listOf("2026-11"), 7000, 10000).first().state)
        repo.applyPriceChange(listOf("2026-11"), 7000, 10000, U)
        assertEquals(70_000L, invoiceOf(s.id, "2026-11").baseAmount)                  // لم يتغير
        assertEquals(1000L, paid(s.id))                                              // التسديد لم يُمس
        repo.closeMonth("2026-11", U)
        assertEquals("SKIP_CLOSED", repo.previewPriceChange(listOf("2026-11"), 7000, 10000).first().state)
    }

    // إيقاف ثم إعادة تفعيل داخل الدورة: نسبي لبقية الدورة (16 من 31 يوماً في ديسمبر)
    @Test fun reactivationMidCycleIsProrated() = runBlocking {
        var clk = d(2026, 12, 16).atTime(9, 0).atZone(Fmt.zone).toInstant().toEpochMilli()
        val r2 = FinanceRepository(db, { "dev1" }, { "A" }, { clk++ })
        val s = (r2.addSubscriber(SubscriberInput("ب", "", "", "", 7, d(2026, 11, 1).toEpochDay(), 1, "", null), U, "PRORATED", 10000) as FinResult.Ok).value
        r2.setSubscriberStatus(s.id, "PAUSED", null, U)
        r2.createMonth("2026-12", 10000, "PRORATED", U)
        assertEquals(0, db.invoices().forSubscriber(s.id).size)                       // الموقوف لا يُطالَب
        r2.setSubscriberStatus(s.id, "ACTIVE", null, U)
        val inv = db.invoices().forSubscriber(s.id).first()
        assertEquals(16, inv.daysCharged); assertEquals(36_129L, inv.baseAmount); assertTrue(inv.isProrated)
    }

    // 10: البوردات: إنشاء ونقل وحذف دون المساس بالحسابات
    @Test fun boardsMoveAndDeleteKeepAccounts() = runBlocking {
        cycles(d(2026, 11, 1))
        val b1 = (repo.createBoard("البورد الأول", U) as FinResult.Ok).value
        val b2 = (repo.createBoard("البورد الثاني", U) as FinResult.Ok).value
        val s1 = addAt(d(2026, 11, 1), board = b1); val s2 = addAt(d(2026, 11, 1), board = b1)
        collect(s1.id, 20_000)
        val before = db.invoices().balances(s1.id).map { it.total to it.paid }
        assertEquals(2, db.subscribers().boardCounts().first { it.boardId == b1 }.cnt)
        assertEquals(2L, db.subscribers().totals("2026-11", "", "", b1).cnt.toLong())
        repo.moveSubscribers(listOf(s1.id), b2, U)
        assertEquals(b2, db.subscribers().get(s1.id)!!.boardId)
        assertEquals(before, db.invoices().balances(s1.id).map { it.total to it.paid })   // الحساب لم يتأثر
        assertEquals(1L, db.subscribers().totals("2026-11", "", "", b2).cnt.toLong())
        assertEquals(1, (repo.deleteBoard(b1, U) as FinResult.Ok).value)
        assertNull(db.subscribers().get(s2.id)!!.boardId)                              // صار بدون بورد
        assertEquals(1L, db.subscribers().totals("2026-11", "", "", "-").cnt.toLong())
        assertEquals(2L, ReportEngineCount("subscribers"))                             // لم يُحذف مشترك
        assertTrue(repo.moveSubscribers(listOf(s2.id), b1, U) is FinResult.Err)       // لا نقل لبورد محذوف
    }

    // 11+12+14: الوصل وكشف الحساب: إعادة الطباعة لا تنشئ حركة، والكشف متسق بعد الدفع والإلغاء
    @Test fun reprintAndStatementConsistency() = runBlocking {
        cycles(d(2026, 11, 1)); val s = addAt(d(2026, 11, 1))
        val r = (collect(s.id, 30_000) as FinResult.Ok).value
        assertEquals("مسدد جزئياً", Cycles.settlement(r.amountIqd, r.balanceAfterIqd))
        assertEquals(U, r.meta.createdBy)                                              // المنفذ الفعلي محفوظ في السند
        val cashBefore = ReportEngineCount("cash_entries"); val rcptBefore = ReportEngineCount("receipts")
        repo.markPrinted(r.id); repo.markPrinted(r.id)
        assertEquals(cashBefore, ReportEngineCount("cash_entries")); assertEquals(rcptBefore, ReportEngineCount("receipts"))
        assertEquals("SENT_TO_PRINTER", db.receipts().get(r.id)!!.printStatus)
        var st = Reports.statement(db, s.id)
        assertEquals("40,000", st.rows.last().cells[4])                                // 70,000 - 30,000
        repo.cancelReceipt(r.id, "خطأ إدخال", U)
        st = Reports.statement(db, s.id)
        assertEquals("70,000", st.rows.last().cells[4]); assertEquals("70,000", st.totals!![4])
        assertEquals(70_000L, db.invoices().balances(s.id).sumOf { it.total - it.paid })
    }

    // قبل التسليم: الأرصدة والديون صحيحة بعد عمليات متعددة
    @Test fun balancesAfterManyOperations() = runBlocking {
        cycles(d(2026, 11, 1)); val a = addAt(d(2026, 11, 1)); val b = addAt(d(2026, 11, 16))        // 70,000 و35,000
        cycles(d(2026, 12, 2))                                                                       // + 70,000 لكل منهما
        collect(a.id, 100_000); collect(b.id, 35_000)
        assertEquals(40_000L, db.invoices().balances(a.id).sumOf { it.total - it.paid })
        assertEquals(70_000L, db.invoices().balances(b.id).sumOf { it.total - it.paid })
        assertEquals(135_000L, cash())
        val row = db.subscribers().rows("2026-12", "", "", "", 0, 0, 10, 0).first { it.id == a.id }
        assertEquals(0L, row.prevDebt - 0L)                                                          // نوفمبر سُدّد كله
        assertEquals(30_000L, row.paidThisMonth); assertEquals(40_000L, row.remaining)
    }
}
