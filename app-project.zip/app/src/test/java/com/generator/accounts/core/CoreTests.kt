package com.generator.accounts.core

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

class DueDatesTest {
    @Test fun normalDay() = assertEquals(LocalDate.of(2026, 3, 10), DueDates.dueDate(YearMonth.of(2026, 3), 10))
    @Test fun day31InThirtyDayMonth() = assertEquals(LocalDate.of(2026, 4, 30), DueDates.dueDate(YearMonth.of(2026, 4), 31))
    @Test fun day30InFebruary() = assertEquals(LocalDate.of(2026, 2, 28), DueDates.dueDate(YearMonth.of(2026, 2), 30))
    @Test fun day29InLeapFebruary() = assertEquals(LocalDate.of(2028, 2, 29), DueDates.dueDate(YearMonth.of(2028, 2), 29))
    @Test fun day29InNonLeapFebruary() = assertEquals(LocalDate.of(2027, 2, 28), DueDates.dueDate(YearMonth.of(2027, 2), 29))
    @Test fun cycleEndIsDayBeforeNextDue() = assertEquals(LocalDate.of(2026, 4, 9), DueDates.cycleEnd(YearMonth.of(2026, 3), 10))
    @Test fun overdueDays() {
        val due = LocalDate.of(2026, 3, 10)
        assertEquals(0L, DueDates.daysOverdue(due, LocalDate.of(2026, 3, 10)))
        assertEquals(5L, DueDates.daysOverdue(due, LocalDate.of(2026, 3, 15)))
        assertEquals(0L, DueDates.daysOverdue(due, LocalDate.of(2026, 3, 1)))
    }
}

class PaymentAllocatorTest {
    private val open = listOf(OpenInvoice("b", 20, 50_000), OpenInvoice("a", 10, 50_000), OpenInvoice("c", 30, 50_000))
    @Test fun oldestFirstPartial() {
        val r = PaymentAllocator.autoOldestFirst(open, 70_000) as PaymentAllocator.Result.Ok
        assertEquals(listOf(AllocationLine("a", 50_000), AllocationLine("b", 20_000)), r.lines)
    }
    @Test fun fullPayment() {
        val r = PaymentAllocator.autoOldestFirst(open, 150_000) as PaymentAllocator.Result.Ok
        assertEquals(150_000L, r.lines.sumOf { it.amount })
    }
    @Test fun rejectsOverpaymentAndZero() {
        assertTrue(PaymentAllocator.autoOldestFirst(open, 150_001) is PaymentAllocator.Result.Error)
        assertTrue(PaymentAllocator.autoOldestFirst(open, 0) is PaymentAllocator.Result.Error)
    }
    @Test fun manualMustSumAndNotExceed() {
        assertTrue(PaymentAllocator.manual(open, 60_000, listOf(AllocationLine("a", 60_000))) is PaymentAllocator.Result.Error)
        assertTrue(PaymentAllocator.manual(open, 60_000, listOf(AllocationLine("a", 30_000), AllocationLine("c", 30_000))) is PaymentAllocator.Result.Ok)
        assertTrue(PaymentAllocator.manual(open, 60_000, listOf(AllocationLine("a", 30_000))) is PaymentAllocator.Result.Error)
    }
}

class ArabicMoneyTest {
    @Test fun fiftyThousand() = assertEquals("خمسون ألف دينار عراقي فقط لا غير", ArabicMoney.words(50_000))
    @Test fun twoThousand() = assertEquals("ألفان دينار عراقي فقط لا غير", ArabicMoney.words(2_000))
    @Test fun composite() = assertEquals("مليون ومائتان وخمسون ألف دينار عراقي فقط لا غير", ArabicMoney.words(1_250_000))
    @Test fun withUnits() = assertEquals("خمسة وعشرون دينار عراقي فقط لا غير", ArabicMoney.words(25))
    @Test fun zero() = assertEquals("صفر دينار عراقي فقط لا غير", ArabicMoney.words(0))
}

class PhoneFormatTest {
    @Test fun local() = assertEquals("9647701234567", PhoneFormat.toInternational("0770 123 4567"))
    @Test fun alreadyIntl() = assertEquals("9647701234567", PhoneFormat.toInternational("+964 770 123 4567"))
    @Test fun doubleZero() = assertEquals("9647701234567", PhoneFormat.toInternational("00964770123456" + "7"))
    @Test fun invalid() = assertNull(PhoneFormat.toInternational("12345"))
}

class PinHasherTest {
    @Test fun verifyWorks() {
        val salt = PinHasher.newSalt()
        val h = PinHasher.hash("1234".toCharArray(), salt)
        assertTrue(PinHasher.verify("1234".toCharArray(), salt, h))
        assertFalse(PinHasher.verify("1235".toCharArray(), salt, h))
        assertNotEquals("1234", h)
    }
}

class FirstMonthTest {
    private val due = LocalDate.of(2026, 3, 10); private val end = LocalDate.of(2026, 4, 9)
    @Test fun full() = assertEquals(50_000L to null, FirstMonth.apply(50_000, "FULL", due, due, end))
    @Test fun free() = assertEquals(0L, FirstMonth.apply(50_000, "FREE", due, due, end).first)
    @Test fun proratedMidCycle() {
        val r = FirstMonth.apply(31_000, "PRORATED", LocalDate.of(2026, 3, 20), due, end)   // 31 يوماً، المتبقي 21
        assertEquals(21_000L, r.first); assertNotNull(r.second)
    }
    @Test fun proratedFullIfStartsAtDue() = assertEquals(50_000L to null, FirstMonth.apply(50_000, "PRORATED", due, due, end))
}
class FmtTest {
    @Test fun parseMoney() { assertEquals(50000L, Fmt.parseMoney("50,000")); assertEquals(1500L, Fmt.parseMoney("١٥٠٠")); assertNull(Fmt.parseMoney("abc")) }
    @Test fun liters() { assertEquals(12500L, Fmt.parseLitersMilli("12.5")); assertEquals("12.5", Fmt.liters(12500)); assertNull(Fmt.parseLitersMilli("-1")) }
}

class ArabicLocaleTest {
    @Test fun formattingIgnoresDeviceLocale() {
        val old = java.util.Locale.getDefault()
        try {
            java.util.Locale.setDefault(java.util.Locale("ar", "IQ"))
            assertEquals("2026-11", Fmt.ym(2026, 11))
            assertEquals("A-2026-0007", Fmt.serial("A", 2026, 7))
            assertEquals("50,000", Fmt.money(50_000))
            assertEquals(2026, java.time.YearMonth.parse(Fmt.ym(Fmt.today())).year)
        } finally { java.util.Locale.setDefault(old) }
    }
}

class CyclesTest {
    private val nov = YearMonth.of(2026, 11)
    @Test fun cycleBoundariesAndDays() {
        assertEquals(LocalDate.of(2026, 11, 1), Cycles.start(nov)); assertEquals(LocalDate.of(2026, 12, 1), Cycles.endExclusive(nov))
        assertEquals(30, Cycles.days(nov)); assertEquals(31, Cycles.days(YearMonth.of(2026, 12)))
        assertEquals(28, Cycles.days(YearMonth.of(2027, 2))); assertEquals(29, Cycles.days(YearMonth.of(2028, 2)))
    }
    @Test fun graceEndIsFifthDay() { assertEquals(LocalDate.of(2026, 11, 5), Cycles.graceEnd(nov, 5)); assertEquals(LocalDate.of(2026, 11, 1), Cycles.graceEnd(nov, 1)) }
    @Test fun daysFromActivationIncludeActivationDay() {
        assertEquals(15, Cycles.daysFrom(nov, LocalDate.of(2026, 11, 16))); assertEquals(30, Cycles.daysFrom(nov, LocalDate.of(2026, 11, 1)))
        assertEquals(1, Cycles.daysFrom(nov, LocalDate.of(2026, 11, 30)))
        assertEquals(15, Cycles.daysFrom(YearMonth.of(2028, 2), LocalDate.of(2028, 2, 15)))   // 15..29 في شباط الكبيس
    }
    @Test fun prorateExampleAndRounding() {
        assertEquals(35_000L, Cycles.prorate(70_000, 15, 30)); assertEquals(2_333L, Cycles.prorate(70_000, 1, 30))
        assertEquals(33L, Cycles.prorate(100, 1, 3)); assertEquals(67L, Cycles.prorate(100, 2, 3)); assertEquals(70_000L, Cycles.prorate(70_000, 30, 30))
    }
    @Test fun statusAndLateDays() {
        val ge = LocalDate.of(2026, 11, 5)
        assertEquals(Cycles.Status.IN_GRACE, Cycles.status(1, ge, LocalDate.of(2026, 11, 5))); assertEquals(Cycles.Status.LATE, Cycles.status(1, ge, LocalDate.of(2026, 11, 6)))
        assertEquals(Cycles.Status.PAID, Cycles.status(0, ge, LocalDate.of(2026, 12, 1)))
        assertEquals(0L, Cycles.lateDays(ge, LocalDate.of(2026, 11, 3))); assertEquals(10L, Cycles.lateDays(ge, LocalDate.of(2026, 11, 15)))
    }
    @Test fun settlementText() { assertEquals("مسدد", Cycles.settlement(5, 0)); assertEquals("مسدد جزئياً", Cycles.settlement(5, 5)); assertEquals("غير مسدد", Cycles.settlement(0, 5)) }
}
