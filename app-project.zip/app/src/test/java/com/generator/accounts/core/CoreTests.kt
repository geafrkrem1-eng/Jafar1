package com.generator.accounts.core

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

class DueDatesTest {
    @Test fun normalDay() = assertEquals(LocalDate.of(2026, 3, 10), DueDates.dueDate(YearMonth.of(2026, 3), 10))
    @Test fun day31InThirtyDayMonth() = assertEquals(LocalDate.of(2026, 4, 30), DueDates.dueDate(YearMonth.of(2026, 4), 31))
    @Test fun day30InFebruary() = assertEquals(LocalDate.of(2026, 2, 28), DueDates.dueDate(YearMonth.of(2026, 2), 30))
    @Test fun day29InLeapFebruary() = assertEquals(LocalDate.of(2028, 2, 29), DueDates.dueDate(YearMonth.of(2028, 2), 29))
    @Test fun day29InNonLeapFebruary() = assertEquals(LocalDate.of(2027, 2, 28), DueDates.dueDate(YearMonth.of(2027, 2), 29))
    @Test fun cycleEndIsDayBeforeNextDue() = assertEquals(LocalDate.of(2026, 4, 9), DueDates.cycleEnd(YearMonth.of(2026, 3), 10))
    @Test fun overdueDays() {
        val due = LocalDate.of(2026, 3, 10)
        assertEquals(0, DueDates.daysOverdue(due, LocalDate.of(2026, 3, 10)))
        assertEquals(5, DueDates.daysOverdue(due, LocalDate.of(2026, 3, 15)))
        assertEquals(0, DueDates.daysOverdue(due, LocalDate.of(2026, 3, 1)))
    }
}

class PaymentAllocatorTest {
    private val open = listOf(OpenInvoice("b", 20, 50_000), OpenInvoice("a", 10, 50_000), OpenInvoice("c", 30, 50_000))
    @Test fun oldestFirstPartial() {
        val r = PaymentAllocator.autoOldestFirst(open, 70_000) as PaymentAllocator.Result.Ok
        assertEquals(listOf(AllocationLine("a", 50_000), AllocationLine("b", 20_000)), r.lines)
    }
    @Test fun fullPayment() {
        val r = PaymentAllocator.autoOldestFirst(open, 150_000) as PaymentAllocator.Result.Ok
        assertEquals(150_000L, r.lines.sumOf { it.amount })
    }
    @Test fun rejectsOverpaymentAndZero() {
        assertTrue(PaymentAllocator.autoOldestFirst(open, 150_001) is PaymentAllocator.Result.Error)
        assertTrue(PaymentAllocator.autoOldestFirst(open, 0) is PaymentAllocator.Result.Error)
    }
    @Test fun manualMustSumAndNotExceed() {
        assertTrue(PaymentAllocator.manual(open, 60_000, listOf(AllocationLine("a", 60_000))) is PaymentAllocator.Result.Error)
        assertTrue(PaymentAllocator.manual(open, 60_000, listOf(AllocationLine("a", 30_000), AllocationLine("c", 30_000))) is PaymentAllocator.Result.Ok)
        assertTrue(PaymentAllocator.manual(open, 60_000, listOf(AllocationLine("a", 30_000))) is PaymentAllocator.Result.Error)
    }
}

class ArabicMoneyTest {
    @Test fun fiftyThousand() = assertEquals("خمسون ألف دينار عراقي فقط لا غير", ArabicMoney.words(50_000))
    @Test fun twoThousand() = assertEquals("ألفان دينار عراقي فقط لا غير", ArabicMoney.words(2_000))
    @Test fun composite() = assertEquals("مليون ومائتان وخمسون ألف دينار عراقي فقط لا غير", ArabicMoney.words(1_250_000))
    @Test fun withUnits() = assertEquals("خمسة وعشرون دينار عراقي فقط لا غير", ArabicMoney.words(25))
    @Test fun zero() = assertEquals("صفر دينار عراقي فقط لا غير", ArabicMoney.words(0))
}

class PhoneFormatTest {
    @Test fun local() = assertEquals("9647701234567", PhoneFormat.toInternational("0770 123 4567"))
    @Test fun alreadyIntl() = assertEquals("9647701234567", PhoneFormat.toInternational("+964 770 123 4567"))
    @Test fun doubleZero() = assertEquals("9647701234567", PhoneFormat.toInternational("00964770123456" + "7"))
    @Test fun invalid() = assertNull(PhoneFormat.toInternational("12345"))
}

class PinHasherTest {
    @Test fun verifyWorks() {
        val salt = PinHasher.newSalt()
        val h = PinHasher.hash("1234".toCharArray(), salt)
        assertTrue(PinHasher.verify("1234".toCharArray(), salt, h))
        assertFalse(PinHasher.verify("1235".toCharArray(), salt, h))
        assertNotEquals("1234", h)
    }
}

class FirstMonthTest {
    private val due = LocalDate.of(2026, 3, 10); private val end = LocalDate.of(2026, 4, 9)
    @Test fun full() = assertEquals(50_000L to null, FirstMonth.apply(50_000, "FULL", due, due, end))
    @Test fun free() = assertEquals(0L, FirstMonth.apply(50_000, "FREE", due, due, end).first)
    @Test fun proratedMidCycle() {
        val r = FirstMonth.apply(31_000, "PRORATED", LocalDate.of(2026, 3, 20), due, end)   // 31 يوماً، المتبقي 21
        assertEquals(21_000L, r.first); assertNotNull(r.second)
    }
    @Test fun proratedFullIfStartsAtDue() = assertEquals(50_000L to null, FirstMonth.apply(50_000, "PRORATED", due, due, end))
}
class FmtTest {
    @Test fun parseMoney() { assertEquals(50000L, Fmt.parseMoney("50,000")); assertEquals(1500L, Fmt.parseMoney("١٥٠٠")); assertNull(Fmt.parseMoney("abc")) }
    @Test fun liters() { assertEquals(12500L, Fmt.parseLitersMilli("12.5")); assertEquals("12.5", Fmt.liters(12500)); assertNull(Fmt.parseLitersMilli("-1")) }
}
