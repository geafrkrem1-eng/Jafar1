package com.generator.accounts.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [Subscriber::class, MonthRecord::class, Invoice::class, Receipt::class, ReceiptAllocation::class,
        CashEntry::class, Expense::class, Worker::class, Advance::class, PayrollSlip::class, CashClosing::class,
        ReminderLog::class, AuditLog::class, AppUser::class, AppSetting::class],
    version = 1, exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun subscribers(): SubscriberDao
    abstract fun months(): MonthDao
    abstract fun invoices(): InvoiceDao
    abstract fun receipts(): ReceiptDao
    abstract fun allocations(): AllocationDao
    abstract fun cash(): CashDao
    abstract fun expenses(): ExpenseDao
    abstract fun workers(): WorkerDao
    abstract fun advances(): AdvanceDao
    abstract fun slips(): SlipDao
    abstract fun closings(): ClosingDao
    abstract fun reminders(): ReminderDao
    abstract fun audit(): AuditDao
    abstract fun users(): UserDao
    abstract fun settings(): SettingDao

    companion object {
        const val DB_NAME = "generator.db"
        fun build(ctx: Context): AppDatabase =
            Room.databaseBuilder(ctx, AppDatabase::class.java, DB_NAME)
                .addMigrations(*Migrations.ALL)   // ممنوع استخدام الحذف التلقائي للقاعدة إطلاقاً
                .build()
    }
}
