package com.generator.accounts.core

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** PIN مخزّن بمشتق PBKDF2-HMAC-SHA256 مع Salt عشوائي، لا نصاً واضحاً. */
object PinHasher {
    private const val ITER = 120_000
    private const val BITS = 256

    fun newSalt(): ByteArray = ByteArray(16).also { SecureRandom().nextBytes(it) }

    fun hash(pin: CharArray, salt: ByteArray): String {
        val spec = PBEKeySpec(pin, salt, ITER, BITS)
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return Base64.getEncoder().encodeToString(key)
    }

    fun verify(pin: CharArray, salt: ByteArray, expected: String): Boolean =
        MessageDigest.isEqual(hash(pin, salt).toByteArray(), expected.toByteArray())
}
