package com.generator.accounts.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.generator.accounts.core.Fmt
import com.generator.accounts.core.Perm
import com.generator.accounts.data.Reports
import com.generator.accounts.finance.PricePreview
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** تغيير سعر الأمبير لأشهر محددة (مرة واحدة): سعر جديد + سنة + أشهر + معاينة قديم/جديد + تأكيد + سجل. */
@Composable
fun PriceChangeScreen() {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope()
    if (!app.can(Perm.SETTINGS)) { Screen("تسعيرة الأمبير", onBack = { app.pop() }) { Empty("لا تملك الصلاحية") }; return }
    var price by remember { mutableStateOf("") }
    var year by remember { mutableStateOf(Fmt.today().year.toString()) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var preview by remember { mutableStateOf<List<PricePreview>>(emptyList()) }
    var confirm by remember { mutableStateOf(false) }
    val newPrice = Fmt.parseMoney(price) ?: 0L
    val y = Fmt.normDigits(year).toIntOrNull()
    val defaultPrice = app.c.settings.getLong("amp_price", 10000)

    LaunchedEffect(selected, newPrice, app.tick) {
        preview = if (selected.isEmpty() || newPrice <= 0) emptyList()
        else withContext(Dispatchers.IO) { app.c.repo.previewPriceChange(selected.toList(), newPrice, defaultPrice) }
    }
    fun stateText(s: String) = when (s) {
        "NOT_CREATED" -> "لم تُنشأ بعد: يُطبَّق عند إنشائها" to t.good
        "REPRICE" -> "أُنشئت بلا تسديدات: تُعاد تسعيرتها" to t.warn
        "SKIP_PAID" -> "مستثناة: عليها تسديدات (لا تتغير)" to t.bad
        else -> "مستثناة: الدورة مغلقة (لا تتغير)" to t.bad
    }
    Screen("تغيير سعر الأمبير لأشهر محددة", onBack = { app.pop() }) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("لكل دورة سعر محفوظ ومستقل. لا يتغير أي شهر لم تحدده، ولا تتغير الأشهر المسدّدة أو المغلقة.", color = t.sub, fontSize = 12.sp)
            Field("سعر الأمبير الجديد (د.ع)", price, { price = it }, number = true)
            Field("السنة", year, { year = it }, number = true)
            Text("اختر الأشهر (يمكن غير المتتالية)", color = t.text, fontWeight = FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (m in 1..12) {
                    val key = if (y != null) Fmt.ym(y, m) else ""
                    val on = key in selected
                    Box(Modifier.clip(RoundedCornerShape(50)).background(if (on) t.primary else t.card)
                        .clickable(enabled = y != null) { selected = if (on) selected - key else selected + key }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                        Text(m.toString(), color = if (on) Color.White else t.text, fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (selected.isNotEmpty()) TextButton(onClick = { selected = emptySet() }) { Text("مسح الاختيار", color = t.sub) }
            preview.forEach { p ->
                val (txt, col) = stateText(p.state)
                Card2(Modifier.fillMaxWidth()) {
                    Text(p.ym, color = t.text, fontWeight = FontWeight.Bold)
                    Info("السعر القديم", Fmt.iqd(p.oldPrice)); Info("السعر الجديد", Fmt.iqd(p.newPrice), t.primary)
                    Text(txt, color = col, fontSize = 12.sp)
                }
            }
            BigButton("اعتماد التغيير", t.primary, enabled = preview.isNotEmpty() && newPrice > 0) { confirm = true }
            SectionTitle("سجل تغييرات الأسعار")
            SpecTable(Reports.priceLog(), listOf(130, 90, 100, 100, 220, 110), Modifier.height(280.dp), "price-log", app.tick)
        }
        if (confirm) ConfirmDialog("تأكيد تغيير السعر",
            "سعر ${Fmt.iqd(newPrice)} للأمبير على ${preview.size} شهر. ستُطبَّق التغييرات المسموحة فقط وتُسجَّل باسمك.", "اعتماد", { confirm = false }) {
            confirm = false
            scope.launch { app.handle(app.c.repo.applyPriceChange(selected.toList(), newPrice, defaultPrice, app.uid()), "تم تطبيق التسعيرة") { n -> app.say("طُبّقت على $n شهر، والباقي مستثنى") } }
        }
    }
}
