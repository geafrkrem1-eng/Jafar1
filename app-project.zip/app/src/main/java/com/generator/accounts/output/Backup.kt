package com.generator.accounts.output

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.generator.accounts.Container
import com.generator.accounts.core.Fmt
import com.generator.accounts.data.AppDatabase
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** ملف النسخة: zip فيه meta.json (إصدار المخطط، الجهاز، التاريخ، بصمة) + generator.db. */
object Backup {
    const val DB_ENTRY = "generator.db"
    private fun sha(f: File): String = MessageDigest.getInstance("SHA-256").let { md ->
        f.inputStream().use { i -> val b = ByteArray(8192); while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) } }
        md.digest().joinToString("") { String.format(java.util.Locale.ROOT, "%02x", it) }
    }
    fun dir(ctx: Context) = File(ctx.getExternalFilesDir(null), "backups").apply { mkdirs() }

    fun write(c: Container, out: OutputStream) {
        val sdb = c.db.openHelper.writableDatabase
        sdb.query("PRAGMA wal_checkpoint(TRUNCATE)").use { it.moveToFirst() }     // دمج WAL في الملف الرئيسي
        val dbFile = c.ctx.getDatabasePath(AppDatabase.DB_NAME)
        val meta = """{"app":"com.generator.accounts","schemaVersion":${sdb.version},"deviceId":"${c.settings.get("device_id")}","createdAt":${System.currentTimeMillis()},"sha256":"${sha(dbFile)}"}"""
        ZipOutputStream(out).use { z ->
            z.putNextEntry(ZipEntry("meta.json")); z.write(meta.toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry(DB_ENTRY)); dbFile.inputStream().use { it.copyTo(z) }; z.closeEntry()
            File(c.ctx.filesDir, "logo.png").takeIf { it.exists() }?.let { l ->
                z.putNextEntry(ZipEntry("logo.png")); l.inputStream().use { it.copyTo(z) }; z.closeEntry()
            }
        }
    }

    suspend fun autoIfNeeded(c: Container) {
        val last = c.settings.getLong("last_backup", 0)
        if (System.currentTimeMillis() - last < 24 * 3600_000L) return
        runCatching {
            val f = File(dir(c.ctx), "auto-" + Fmt.dateTime(System.currentTimeMillis()).replace(" ", "_").replace(":", "") + ".zip")
            f.outputStream().use { write(c, it) }
            dir(c.ctx).listFiles { x -> x.name.startsWith("auto-") }?.sortedByDescending { it.name }?.drop(10)?.forEach { it.delete() }
            c.settings.set("last_backup", System.currentTimeMillis().toString())
        }
    }

    /** يعيد رسالة خطأ أو null عند النجاح. بعد النجاح يجب إعادة تشغيل التطبيق. لا فقد صامت: النسخة الحالية تُحفظ قبل الاستبدال. */
    fun restore(c: Container, input: InputStream): String? {
        val tmp = File(c.ctx.cacheDir, "restore").apply { deleteRecursively(); mkdirs() }
        var metaTxt: String? = null; var dbOk = false
        try {
            ZipInputStream(input).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    when (e.name) {
                        "meta.json" -> metaTxt = z.readBytes().toString(Charsets.UTF_8)
                        DB_ENTRY -> { File(tmp, DB_ENTRY).outputStream().use { z.copyTo(it) }; dbOk = true }
                        "logo.png" -> File(tmp, "logo.png").outputStream().use { z.copyTo(it) }
                    }
                }
            }
        } catch (e: Exception) { return "الملف تالف أو غير مكتمل" }
        if (metaTxt == null && !dbOk) return "الملف تالف أو غير مكتمل"
        val meta = metaTxt ?: return "ملف النسخة لا يحوي بيانات الإصدار"
        if (!dbOk) return "ملف النسخة لا يحوي قاعدة البيانات"
        if (!meta.contains("com.generator.accounts")) return "هذا الملف ليس نسخة من هذا التطبيق"
        val ver = Regex("\"schemaVersion\":(\\d+)").find(meta)?.groupValues?.get(1)?.toInt() ?: return "إصدار النسخة غير معروف"
        val current = c.db.openHelper.readableDatabase.version
        if (ver > current) return "النسخة من إصدار أحدث ($ver) من التطبيق المثبت ($current). حدّث التطبيق أولاً"
        val expected = Regex("\"sha256\":\"([0-9a-f]+)\"").find(meta)?.groupValues?.get(1)
        val dbTmp = File(tmp, DB_ENTRY)
        if (expected != null && expected != sha(dbTmp)) return "الملف تالف (فشل فحص البصمة)"
        try {
            SQLiteDatabase.openDatabase(dbTmp.path, null, SQLiteDatabase.OPEN_READONLY).use { s ->
                s.rawQuery("PRAGMA integrity_check", null).use { if (!it.moveToFirst() || it.getString(0) != "ok") return "قاعدة البيانات داخل النسخة تالفة" }
                s.rawQuery("SELECT name FROM sqlite_master WHERE name IN ('receipts','subscribers','cash_entries')", null).use { if (it.count < 3) return "النسخة ناقصة الجداول" }
            }
        } catch (e: Exception) { return "تعذّر فتح قاعدة البيانات في النسخة" }
        // نسخة أمان من القاعدة الحالية قبل الاستبدال
        val safety = File(dir(c.ctx), "pre-restore-" + System.currentTimeMillis() + ".zip")
        safety.outputStream().use { write(c, it) }
        c.db.close()
        val live = c.ctx.getDatabasePath(AppDatabase.DB_NAME)
        dbTmp.copyTo(live, overwrite = true)
        File(live.path + "-wal").delete(); File(live.path + "-shm").delete()
        File(tmp, "logo.png").takeIf { it.exists() }?.copyTo(File(c.ctx.filesDir, "logo.png"), overwrite = true)
        return null
    }
}
