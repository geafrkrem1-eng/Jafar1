package com.generator.accounts.core

object Perm {
    const val SUB_VIEW = "SUB_VIEW"; const val SUB_ADD = "SUB_ADD"; const val SUB_EDIT = "SUB_EDIT"
    const val COLLECT = "COLLECT"; const val CANCEL_RECEIPT = "CANCEL_RECEIPT"; const val DEBTS = "DEBTS"
    const val REMIND = "REMIND"; const val EXPENSES = "EXPENSES"; const val FUEL = "FUEL"; const val MAINT = "MAINT"
    const val WORKERS = "WORKERS"; const val PAYROLL = "PAYROLL"; const val REPORTS = "REPORTS"
    const val CASH = "CASH"; const val MONTHS = "MONTHS"; const val SETTINGS = "SETTINGS"
    const val BACKUP = "BACKUP"; const val USERS = "USERS"

    val labels = linkedMapOf(
        SUB_VIEW to "عرض المشتركين", SUB_ADD to "إضافة مشترك", SUB_EDIT to "تعديل المشتركين",
        COLLECT to "التحصيل", CANCEL_RECEIPT to "إلغاء سند", DEBTS to "عرض الديون", REMIND to "إرسال التذكيرات",
        EXPENSES to "تسجيل المصاريف", FUEL to "إدارة الوقود", MAINT to "إدارة الصيانة",
        WORKERS to "إدارة الموظفين", PAYROLL to "الرواتب", REPORTS to "التقارير", CASH to "الصندوق",
        MONTHS to "الأشهر المالية", SETTINGS to "إعدادات التطبيق", BACKUP to "النسخ الاحتياطي والاستعادة", USERS to "إدارة المستخدمين")
    val all: Set<String> = labels.keys
    val accountant: Set<String> = setOf(SUB_VIEW, COLLECT, DEBTS, REMIND, EXPENSES, FUEL, MAINT, REPORTS, CASH)
    val staffDefault: Set<String> = setOf(SUB_VIEW, COLLECT, DEBTS)

    fun effective(role: String, csv: String): Set<String> =
        if (role == "ADMIN") all else csv.split(',').filter { it.isNotBlank() }.toSet()
}
