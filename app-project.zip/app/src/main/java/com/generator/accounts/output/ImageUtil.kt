package com.generator.accounts.output

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

object ImageUtil {
    /** ينسخ صورة من المعرض إلى مجلد التطبيق مصغّرة. يعيد المسار أو null. */
    fun save(ctx: Context, uri: Uri, name: String, maxSide: Int = 800): String? = try {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (maxOf(opts.outWidth, opts.outHeight) / sample > maxSide * 2) sample *= 2
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
        if (bmp == null) null else {
            val k = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
            val out = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true) else bmp
            val f = File(File(ctx.filesDir, "images").apply { mkdirs() }, name)
            f.outputStream().use { out.compress(if (name.endsWith(".png")) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 88, it) }
            f.path
        }
    } catch (e: Exception) { null }
}
