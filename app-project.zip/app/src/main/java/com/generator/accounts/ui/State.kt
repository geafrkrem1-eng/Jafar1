package com.generator.accounts.ui

import androidx.compose.runtime.*
import com.generator.accounts.Container
import com.generator.accounts.data.AppUser
import com.generator.accounts.core.Perm
import com.generator.accounts.finance.FinResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed interface Route {
    object Home : Route; object Subscribers : Route; data class Collect(val subscriberId: String? = null) : Route
    object Debts : Route; object More : Route; object FollowUp : Route
    data class SubDetail(val id: String) : Route; data class SubForm(val id: String?) : Route
    object Receipts : Route; data class ReceiptView(val id: String) : Route
    object Months : Route; object Expenses : Route; object Workers : Route; data class WorkerDetail(val id: String) : Route
    object Cash : Route; object Reports : Route; object Users : Route; object Settings : Route
    object BackupScreen : Route; object PrinterScreen : Route; object PriceChange : Route
}

class AppState(val c: Container) {
    var user by mutableStateOf<AppUser?>(null)
    var stack by mutableStateOf<List<Route>>(listOf(Route.Home))
    var tick by mutableIntStateOf(0)
    var themePreview by mutableStateOf<ThemePrefs?>(null)
    var message by mutableStateOf<String?>(null)
    var boardFilter by mutableStateOf("")      // "" الكل، "-" بدون بورد، أو معرّف البورد
    @Volatile var lastTouch = System.currentTimeMillis()

    val route get() = stack.last()
    fun push(r: Route) { stack = stack + r }
    fun pop() { if (stack.size > 1) stack = stack.dropLast(1) }
    fun root(r: Route) { stack = listOf(r) }
    fun refresh() { tick++ }
    fun say(m: String) { message = m }
    fun uid(): String = user?.id ?: "system"
    fun userName(): String = user?.name ?: ""
    fun perms(): Set<String> = user?.let { Perm.effective(it.role, it.permissionsCsv) } ?: emptySet()
    fun can(p: String) = p in perms()

    fun prefs(): ThemePrefs = themePreview ?: ThemePrefs(
        c.settings.get("theme_palette", "royal"), c.settings.get("theme_dark") == "1",
        c.settings.get("theme_radius", "18").toIntOrNull() ?: 18, c.settings.get("theme_font", "1").toFloatOrNull() ?: 1f,
        c.settings.get("theme_primary"), c.settings.get("theme_accent"))

    /** يعرض الخطأ إن وُجد ويحدّث الشاشات عند النجاح. */
    fun <T> handle(r: FinResult<T>, okMsg: String? = null, onOk: (T) -> Unit = {}) {
        when (r) {
            is FinResult.Err -> say(r.message)
            is FinResult.Ok -> { okMsg?.let { say(it) }; refresh(); onOk(r.value) }
        }
    }
}

val LocalApp = staticCompositionLocalOf<AppState> { error("no app") }

/** تحميل بيانات في الخلفية وإعادة التحميل عند refresh(). */
@Composable
fun <T> load(vararg keys: Any?, block: suspend () -> T): State<T?> {
    val app = LocalApp.current
    return produceState<T?>(null, app.tick, *keys) {
        try { value = withContext(Dispatchers.IO) { block() } }
        catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: Throwable) { app.say("تعذّر تحميل البيانات: " + (e.message ?: e.javaClass.simpleName)) }
    }
}
