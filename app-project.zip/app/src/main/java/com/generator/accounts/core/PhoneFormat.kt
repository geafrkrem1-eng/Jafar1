package com.generator.accounts.core

object PhoneFormat {
    /** 07XXXXXXXXX → 9647XXXXXXXXX. يعيد null إن لم يكن رقماً عراقياً صالحاً. */
    fun toInternational(raw: String): String? {
        var d = raw.filter { it.isDigit() }
        if (d.startsWith("00964")) d = d.removePrefix("00")
        d = when {
            d.startsWith("964") -> d
            d.startsWith("07") -> "964" + d.drop(1)
            d.startsWith("7") && d.length == 10 -> "964$d"
            else -> return null
        }
        return if (d.length == 13 && d.startsWith("9647")) d else null
    }
}
