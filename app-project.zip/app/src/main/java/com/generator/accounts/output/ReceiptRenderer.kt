package com.generator.accounts.output

import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import com.generator.accounts.core.ArabicMoney
import com.generator.accounts.core.Fmt

data class ReceiptData(
    val genName: String, val genAddress: String, val genPhone: String, val logo: Bitmap?,
    val serial: String, val dateTime: String, val subName: String, val subCode: String, val amps: Int,
    val months: String, val amount: Long, val method: String, val before: Long, val after: Long,
    val staff: String, val footer: String, val cancelled: Boolean, val cancelReason: String?,
    val manager: String = "", val monthLines: List<String> = emptyList(), val settlement: String = "",
    val isCopy: Boolean = false, val copyStamp: String = ""
)

/** يرسم السند كصورة (يضمن ظهور العربية على أي طابعة حرارية) أو يعيد ارتفاعه فقط عند canvas = null. */
object ReceiptRenderer {
    private fun layout(text: String, size: Float, bold: Boolean, align: Layout.Alignment, w: Int, color: Int = Color.BLACK): StaticLayout {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; isFakeBoldText = bold; this.color = color }
        return StaticLayout.Builder.obtain(text, 0, text.length, p, w)
            .setAlignment(align).setTextDirection(TextDirectionHeuristics.RTL).setLineSpacing(0f, 1.1f).build()
    }

    fun draw(canvas: Canvas?, d: ReceiptData, w: Int): Int {
        val pad = (w * 0.04f).toInt()
        val inner = w - 2 * pad
        val base = w / 24f
        var y = pad.toFloat()
        fun put(text: String, size: Float = base, bold: Boolean = false, center: Boolean = false, color: Int = Color.BLACK) {
            if (text.isBlank()) return
            val l = layout(text, size, bold, if (center) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_NORMAL, inner, color)
            canvas?.let { it.save(); it.translate(pad.toFloat(), y); l.draw(it); it.restore() }
            y += l.height + base * 0.25f
        }
        fun rule() {
            canvas?.drawLine(pad.toFloat(), y, (w - pad).toFloat(), y, Paint().apply { color = Color.BLACK; strokeWidth = 1.5f })
            y += base * 0.5f
        }
        canvas?.drawColor(Color.WHITE)
        d.logo?.let { lg ->
            val h = base * 3.2f; val ww = h * lg.width / lg.height
            canvas?.drawBitmap(lg, null, RectF((w - ww) / 2, y, (w + ww) / 2, y + h), Paint(Paint.FILTER_BITMAP_FLAG))
            y += h + base * 0.3f
        }
        put(d.genName, base * 1.3f, true, true)
        if (d.manager.isNotBlank()) put("المدير: ${d.manager}", base * 0.9f, false, true)
        put(d.genAddress, base * 0.85f, false, true)
        put(d.genPhone, base * 0.85f, false, true)
        rule()
        put("سند قبض" + if (d.cancelled) " (ملغى)" else "", base * 1.15f, true, true, if (d.cancelled) Color.RED else Color.BLACK)
        if (d.isCopy) put("نسخة معاد طباعتها" + if (d.copyStamp.isNotBlank()) " — ${d.copyStamp}" else "", base * 0.85f, false, true, Color.DKGRAY)
        put("الرقم: ${d.serial}")
        put("التاريخ: ${d.dateTime}")
        put("المشترك: ${d.subName} (${d.subCode})")
        put("الأمبيرات: ${d.amps}")
        if (d.monthLines.isNotEmpty()) { put("الأشهر المسددة:"); d.monthLines.forEach { put("  $it", base * 0.95f) } }
        else put("الأشهر: ${d.months.ifBlank { "-" }}")
        rule()
        put("المبلغ المقبوض: ${Fmt.iqd(d.amount)}", base * 1.1f, true)
        put(ArabicMoney.words(d.amount), base * 0.85f)
        put("طريقة الدفع: ${d.method}")
        put("المستحق قبل الدفع: ${Fmt.iqd(d.before)}")
        put("المتبقي بعد الدفع: ${Fmt.iqd(d.after)}", bold = true)
        if (d.settlement.isNotBlank()) put("حالة التسديد: ${d.settlement}", bold = true)
        rule()
        put("المستلم / المنفذ: ${d.staff}")
        put("التوقيع: ____________")
        if (d.cancelled) put("سبب الإلغاء: ${d.cancelReason ?: ""}", base * 0.85f, color = Color.RED)
        put(d.footer, base * 0.85f, false, true)
        return (y + pad).toInt()
    }

    fun render(d: ReceiptData, w: Int): Bitmap {
        val h = draw(null, d, w)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        draw(Canvas(bmp), d, w)
        return bmp
    }
}
