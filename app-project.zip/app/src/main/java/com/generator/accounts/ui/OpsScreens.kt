package com.generator.accounts.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.generator.accounts.core.*
import com.generator.accounts.data.*
import com.generator.accounts.finance.ExpenseInput
import com.generator.accounts.output.Exporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun signedMoney(s: String): Long? {
    val v = Fmt.parseMoney(s) ?: return null
    return if (Fmt.normDigits(s).trim().startsWith("-")) -v else v
}
private fun ymOk(s: String) = runCatching { java.time.YearMonth.parse(s) }.isSuccess

// ───────────── الأشهر المالية ─────────────
@Composable
fun MonthsScreen() {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope()
    val months by load { app.c.db.months().all() }
    var sel by remember { mutableStateOf(currentYm()) }
    var dlg by remember { mutableStateOf("") }
    var newYm by remember { mutableStateOf(currentYm()) }
    var price by remember { mutableStateOf(app.c.settings.get("amp_price", "10000")) }
    var adjId by remember { mutableStateOf<String?>(null) }
    var adjDelta by remember { mutableStateOf("") }
    var adjReason by remember { mutableStateOf("") }
    val cur = months?.firstOrNull { it.ym == sel }
    Screen("الأشهر المالية", onBack = { app.pop() }) {
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (app.can(Perm.MONTHS)) BigButton("إنشاء شهر جديد وتوليد الاشتراكات", t.primary, icon = Icons.Filled.Event) { dlg = "new" }
            Chips((months ?: emptyList()).map { it.ym to (it.ym + if (it.status == "CLOSED") " 🔒" else "") }, sel) { sel = it }
            if (cur != null) {
                Card2(Modifier.fillMaxWidth()) {
                    Info("سعر الأمبير المثبّت لهذا الشهر", Fmt.iqd(cur.ampPriceIqd)); Info("الحالة", if (cur.status == "OPEN") "مفتوح" else "مغلق بعد المراجعة", if (cur.status == "OPEN") t.good else t.warn)
                    if (cur.status == "OPEN" && app.can(Perm.MONTHS)) TextButton(onClick = { dlg = "close" }) { Text("إغلاق الشهر بعد المراجعة", color = t.bad) }
                }
                SpecTable(Reports.monthlySubscriptions(cur.ym, ""), listOf(150, 80, 90, 100, 90, 100, 100, 100), Modifier.weight(1f), "month-${cur.ym}", cur.ym,
                    onRowClick = { r -> if (cur.status == "OPEN" && app.can(Perm.MONTHS)) { adjId = r.id?.substringAfter('|'); adjDelta = ""; adjReason = "" } else app.say("الشهر مغلق") },
                    colorFor = { i, r -> if (i == 6 && (Fmt.parseMoney(r.cells[6]) ?: 0) > 0) t.bad else null })
                Text("اضغط على صف لإضافة رسم أو خصم استثنائي موثّق.", color = t.sub, fontSize = 12.sp)
            } else Empty("لا توجد أشهر بعد. أنشئ أول شهر مالي.")
        }
        if (dlg == "new") AlertDialog(onDismissRequest = { dlg = "" }, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text("شهر مالي جديد") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("الشهر (2026-11)", newYm, { newYm = Fmt.normDigits(it) }); Field("سعر الأمبير لهذا الشهر", price, { price = it }, number = true)
                Text("يُثبَّت السعر تاريخياً ولا يتأثر بتغييره لاحقاً. تُنشأ فاتورة لكل مشترك فعّال.", fontSize = 12.sp, color = t.sub) } },
            confirmButton = { TextButton(onClick = {
                val p = Fmt.parseMoney(price) ?: 0
                scope.launch { app.handle(app.c.repo.createMonth(newYm, p, app.c.settings.get("first_month_mode", "FULL"), app.uid())) { n -> sel = newYm; app.say("تم توليد $n اشتراك") } }; dlg = "" }) { Text("إنشاء", color = t.primary) } },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("تراجع", color = t.sub) } })
        if (dlg == "close") ConfirmDialog("إغلاق الشهر $sel", "بعد الإغلاق لا يمكن تعديل فواتيره. يمكن الاستمرار بتحصيل الديون.", "إغلاق", { dlg = "" }) {
            scope.launch { app.handle(app.c.repo.closeMonth(sel, app.uid()), "تم إغلاق الشهر") }; dlg = "" }
        if (adjId != null) AlertDialog(onDismissRequest = { adjId = null }, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text("رسم / خصم استثنائي") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("المبلغ (سالب للخصم، مثل -5000)", adjDelta, { adjDelta = it }); Field("السبب (مطلوب)", adjReason, { adjReason = it }) } },
            confirmButton = { TextButton(onClick = { val d = signedMoney(adjDelta); val id = adjId
                if (d == null || d == 0L || id == null) app.say("أدخل مبلغاً صحيحاً") else scope.launch { app.handle(app.c.repo.adjustInvoice(id, d, adjReason, app.uid()), "تم التعديل") }
                adjId = null }) { Text("حفظ", color = t.primary) } },
            dismissButton = { TextButton(onClick = { adjId = null }) { Text("تراجع", color = t.sub) } })
    }
}

// ───────────── الديون والمتابعة ─────────────
@Composable
fun DebtsScreen() {
    val app = LocalApp.current; val t = LocalTok.current
    var q by remember { mutableStateOf("") }; var ym by remember { mutableStateOf("") }; var amps by remember { mutableStateOf("") }
    var mode by remember { mutableIntStateOf(0) }; var byOldest by remember { mutableStateOf(false) }; var incGrace by remember { mutableStateOf(false) }
    if (!app.can(Perm.DEBTS)) { Screen("الديون") { Empty("لا تملك صلاحية عرض الديون") }; return }
    Screen("الديون والمتأخرات", actions = { if (app.can(Perm.REMIND)) IconButton(onClick = { app.push(Route.FollowUp) }) { Icon(Icons.Filled.Send, "متابعة جماعية", tint = Color.White) } }) {
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("بحث بالاسم أو الهاتف", q, { q = it })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("الشهر (اختياري)", ym, { ym = Fmt.normDigits(it) }, Modifier.weight(1f)); Field("الأمبيرات", amps, { amps = it }, Modifier.weight(1f), number = true)
            }
            Chips(listOf("0" to "الكل", "1" to "لم يسدد إطلاقاً", "2" to "سدد جزءاً"), mode.toString()) { mode = it.toInt() }
            Chips(listOf("0" to "الأعلى دَيناً", "1" to "الأقدم تأخيراً"), if (byOldest) "1" else "0") { byOldest = it == "1" }
            Chips(listOf("0" to "المتأخر فقط (بعد فترة التسديد)", "1" to "مع ما هو ضمن الفترة"), if (incGrace) "1" else "0") { incGrace = it == "1" }
            if (ym.isNotBlank() && !ymOk(ym)) Text("صيغة الشهر 2026-11", color = t.bad)
            else SpecTable(Reports.debts(q.trim(), ym, Fmt.normDigits(amps).toIntOrNull(), mode, byOldest, incGrace), listOf(150, 110, 80, 80, 110, 90, 130, 110, 110), Modifier.weight(1f), "debts",
                listOf(q, ym, amps, mode, byOldest, incGrace), onRowClick = { r -> r.id?.let { app.push(Route.SubDetail(it)) } },
                colorFor = { i, r -> if (i == 8 || i == 4) t.bad else if (i == 5) (if ((r.cells[5].toIntOrNull() ?: 0) > 30) t.bad else t.warn) else null })
        }
    }
}

@Composable
fun FollowUpScreen() {
    val app = LocalApp.current; val t = LocalTok.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val list by load { ReportEngine.run(app.c.db, Reports.debts("", "", null, 0, true), 5000, 0, false).rows }
    var idx by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("") }
    val cur = list?.getOrNull(idx)
    val sub by load(cur?.id) { cur?.id?.let { app.c.db.subscribers().get(it) } }
    val det by load(cur?.id) { cur?.id?.let { app.c.db.invoices().details(it) } ?: emptyList() }
    LaunchedEffect(sub, det) { val s = sub; if (s != null) msg = reminderText(app, s, det ?: emptyList()) }
    Screen("متابعة جماعية للمتأخرين", onBack = { app.pop() }) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (list == null) Empty("جاري التحميل") else if (cur == null) Empty("انتهت القائمة") else {
                Text("${idx + 1} من ${list!!.size}", color = t.sub)
                Card2(Modifier.fillMaxWidth()) { Info("المشترك", cur.cells[0]); Info("الهاتف", cur.cells[1]); Info("الدين", cur.cells[4], t.bad); Info("أيام التأخير", cur.cells[5]) }
                Field("نص الرسالة (راجعه قبل الإرسال)", msg, { msg = it }, singleLine = false)
                BigButton("فتح واتساب", Color(0xFF25D366), icon = Icons.Filled.Send) { val s = sub; if (s != null) scope.launch { openWhatsApp(app, ctx, s, det ?: emptyList(), msg) } }
                BigButton("التالي", t.primary) { idx++ }
                Text("لا يوجد إرسال تلقائي: تضغط إرسال بنفسك داخل واتساب. يُسجَّل «تم فتح التذكير» فقط.", color = t.sub, fontSize = 12.sp)
            }
        }
    }
}

// ───────────── المصاريف والوقود والصيانة ─────────────
@Composable
fun ExpensesScreen() {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope()
    var kind by remember { mutableStateOf("GENERAL") }
    var q by remember { mutableStateOf("") }; var from by remember { mutableStateOf(currentYm()) }; var to by remember { mutableStateOf(currentYm()) }
    var adding by remember { mutableStateOf(false) }; var voidId by remember { mutableStateOf<String?>(null) }
    val perm = when (kind) { "FUEL" -> Perm.FUEL; "MAINTENANCE" -> Perm.MAINT; else -> Perm.EXPENSES }
    val widths = when (kind) { "FUEL" -> listOf(100, 90, 80, 90, 100, 110, 90, 70); "MAINTENANCE" -> listOf(100, 110, 170, 100, 110, 110, 70); else -> listOf(100, 110, 100, 120, 90, 170, 70) }
    Screen("الوقود والمصاريف والصيانة", onBack = { app.pop() }, actions = {
        if (app.can(perm)) IconButton(onClick = { adding = true }) { Icon(Icons.Filled.Add, "إضافة", tint = Color.White) } }) {
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Chips(listOf("GENERAL" to "مصاريف عامة", "FUEL" to "الوقود", "MAINTENANCE" to "الصيانة"), kind) { kind = it }
            Field("بحث", q, { q = it })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("من شهر", from, { from = Fmt.normDigits(it) }, Modifier.weight(1f)); Field("إلى شهر", to, { to = Fmt.normDigits(it) }, Modifier.weight(1f))
            }
            if (ymOk(from) && ymOk(to)) {
                if (kind == "FUEL") {
                    val daily by load(from, to) { ReportEngine.run(app.c.db, Reports.fuelConsumptionDaily(from, to), 400, 0, true) }
                    daily?.let { Text("استهلاك الفترة: ${it.totals?.getOrNull(2) ?: "0"} د.ع كلفة وقود", color = t.sub, fontSize = 12.sp) }
                }
                SpecTable(Reports.expenses(kind, q.trim(), from, to), widths, Modifier.weight(1f), "expenses-$kind", listOf(kind, q, from, to),
                    onRowClick = { r -> if (app.can(perm)) voidId = r.id },
                    colorFor = { i, r -> if (r.cells.last() == "ملغى" && i == r.cells.size - 1) t.bad else null })
                Text("اضغط على صف لإلغاء المصروف بقيد عكسي.", color = t.sub, fontSize = 12.sp)
            } else Text("صيغة الشهر 2026-11", color = t.bad)
        }
        if (adding) ExpenseForm(kind, { adding = false })
        if (voidId != null) ReasonDialog("إلغاء المصروف", "إلغاء", true, { voidId = null }) { r ->
            val id = voidId; voidId = null
            if (id != null) scope.launch { app.handle(app.c.repo.voidExpense(id, r, app.uid()), "تم الإلغاء بقيد عكسي") } }
    }
}

@Composable
private fun ExpenseForm(kind: String, onClose: () -> Unit) {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope(); val ctx = LocalContext.current
    val cats = app.c.settings.get("expense_categories").split(',').filter { it.isNotBlank() }
    val methods = app.c.settings.get("pay_methods", "نقداً").split(',').filter { it.isNotBlank() }
    var cat by remember { mutableStateOf(when (kind) { "FUEL" -> "وقود"; "MAINTENANCE" -> "صيانة"; else -> cats.firstOrNull() ?: "أخرى" }) }
    var amount by remember { mutableStateOf("") }; var date by remember { mutableStateOf(Fmt.today().toString()) }
    var payee by remember { mutableStateOf("") }; var method by remember { mutableStateOf(methods.firstOrNull() ?: "نقداً") }
    var desc by remember { mutableStateOf("") }; var notes by remember { mutableStateOf("") }
    var fuelType by remember { mutableStateOf("ديزل") }; var liters by remember { mutableStateOf("") }; var ppl by remember { mutableStateOf("") }
    var supplier by remember { mutableStateOf("") }; var voucher by remember { mutableStateOf("") }
    var next by remember { mutableStateOf("") }; var tech by remember { mutableStateOf("") }
    var image by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    val pick = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { u ->
        if (u != null) image = com.generator.accounts.output.ImageUtil.save(ctx, u, "exp-" + java.util.UUID.randomUUID() + ".jpg") }
    AlertDialog(onDismissRequest = onClose, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text,
        title = { Text(when (kind) { "FUEL" -> "شراء وقود"; "MAINTENANCE" -> "صيانة"; else -> "مصروف عام" }) },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (kind == "GENERAL") { Text("الفئة", fontSize = 12.sp, color = t.sub); Chips(cats.map { it to it }, cat) { cat = it } }
            if (kind == "FUEL") { Field("نوع الوقود", fuelType, { fuelType = it }); Field("الكمية (لتر)", liters, { liters = it }, number = true); Field("سعر اللتر", ppl, { ppl = it }, number = true)
                Field("المورد", supplier, { supplier = it }); Field("رقم الوصل", voucher, { voucher = it }) }
            else Field("المبلغ (د.ع)", amount, { amount = it }, number = true)
            Field("التاريخ (yyyy-MM-dd)", date, { date = Fmt.normDigits(it) })
            if (kind != "FUEL") Field("المستلم / الجهة", payee, { payee = it })
            if (kind == "MAINTENANCE") { Field("اسم الفني أو الورشة", tech, { tech = it }); Field("موعد الصيانة القادمة (yyyy-MM-dd)", next, { next = Fmt.normDigits(it) }) }
            Text("طريقة الدفع", fontSize = 12.sp, color = t.sub); Chips(methods.map { it to it }, method) { method = it }
            Field("الوصف", desc, { desc = it }); Field("ملاحظات", notes, { notes = it })
            OutlinedButton(onClick = { pick.launch("image/*") }) { Text(if (image == null) "صورة فاتورة (اختياري)" else "تغيير الصورة") }
        } },
        confirmButton = { TextButton(enabled = !busy, onClick = {
            val d = runCatching { java.time.LocalDate.parse(date) }.getOrNull()
            val nx = if (next.isBlank()) null else runCatching { java.time.LocalDate.parse(next) }.getOrNull()
            if (d == null || (next.isNotBlank() && nx == null)) { app.say("تحقق من صيغة التاريخ"); return@TextButton }
            val input = ExpenseInput(kind, cat, Fmt.parseMoney(amount) ?: 0, d.toEpochDay(), payee, method, desc, notes, image,
                if (kind == "FUEL") fuelType else null, Fmt.parseLitersMilli(liters) ?: 0, Fmt.parseMoney(ppl) ?: 0,
                supplier.ifBlank { null }, voucher.ifBlank { null }, nx?.toEpochDay(), tech.ifBlank { null })
            busy = true
            scope.launch { val r = app.c.repo.addExpense(input, app.uid()); busy = false; app.handle(r, "تم التسجيل") { onClose() } }
        }) { Text("حفظ", color = t.primary) } },
        dismissButton = { TextButton(onClick = onClose) { Text("تراجع", color = t.sub) } })
}

// ───────────── العمال والرواتب ─────────────
@Composable
fun WorkersScreen() {
    val app = LocalApp.current; var q by remember { mutableStateOf("") }; var adding by remember { mutableStateOf(false) }
    if (!app.can(Perm.WORKERS)) { Screen("العمال") { Empty("لا تملك الصلاحية") }; return }
    Screen("العمال والرواتب", onBack = { app.pop() }, actions = { IconButton(onClick = { adding = true }) { Icon(Icons.Filled.PersonAdd, "إضافة", tint = Color.White) } }) {
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("بحث", q, { q = it })
            SpecTable(Reports.workers(q.trim()), listOf(150, 110, 110, 90, 100, 80), Modifier.weight(1f), "workers", q, onRowClick = { r -> r.id?.let { app.push(Route.WorkerDetail(it)) } })
        }
        if (adding) WorkerForm(null) { adding = false }
    }
}

@Composable
private fun WorkerForm(existing: Worker?, onClose: () -> Unit) {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(existing?.name ?: "") }; var phone by remember { mutableStateOf(existing?.phone ?: "") }
    var addr by remember { mutableStateOf(existing?.address ?: "") }; var job by remember { mutableStateOf(existing?.job ?: "") }
    var start by remember { mutableStateOf(existing?.let { Fmt.date(it.startEpochDay) } ?: Fmt.today().toString()) }
    var pay by remember { mutableStateOf(existing?.payType ?: "MONTHLY") }; var rate by remember { mutableStateOf(existing?.rateIqd?.toString() ?: "") }
    var status by remember { mutableStateOf(existing?.status ?: "ACTIVE") }; var notes by remember { mutableStateOf(existing?.notes ?: "") }
    AlertDialog(onDismissRequest = onClose, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text(if (existing == null) "عامل جديد" else "تعديل عامل") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("الاسم", name, { name = it }); Field("الهاتف", phone, { phone = it }, phone = true); Field("العنوان", addr, { addr = it }); Field("الوظيفة", job, { job = it })
            Field("تاريخ البدء", start, { start = Fmt.normDigits(it) })
            Chips(listOf("MONTHLY" to "راتب شهري", "DAILY" to "أجر يومي", "HOURLY" to "بالساعة"), pay) { pay = it }
            Field("الراتب / الأجر (د.ع)", rate, { rate = it }, number = true)
            Chips(listOf("ACTIVE" to "فعال", "STOPPED" to "متوقف"), status) { status = it }
            Field("ملاحظات", notes, { notes = it }) } },
        confirmButton = { TextButton(onClick = {
            val d = runCatching { java.time.LocalDate.parse(start) }.getOrNull() ?: run { app.say("تاريخ غير صالح"); return@TextButton }
            scope.launch { app.handle(app.c.repo.saveWorker(existing?.id, name, phone, addr, job, d.toEpochDay(), pay, Fmt.parseMoney(rate) ?: 0, status, notes, app.uid()), "تم الحفظ") { onClose() } }
        }) { Text("حفظ", color = t.primary) } }, dismissButton = { TextButton(onClick = onClose) { Text("تراجع", color = t.sub) } })
}

@Composable
fun WorkerDetailScreen(id: String) {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope(); val ctx = LocalContext.current
    val w by load(id) { app.c.db.workers().get(id) }
    val bal by load(id) { app.c.repo.advanceBalance(id) }
    var dlg by remember { mutableStateOf("") }; var slipId by remember { mutableStateOf<String?>(null) }
    var advAmt by remember { mutableStateOf("") }; var advNote by remember { mutableStateOf("") }
    var ym by remember { mutableStateOf(currentYm()) }; var units by remember { mutableStateOf("") }; var bonus by remember { mutableStateOf("") }
    var ded by remember { mutableStateOf("") }; var advDed by remember { mutableStateOf("") }
    val slip by load(slipId) { slipId?.let { app.c.db.slips().get(it) } }
    val worker = w
    Screen(worker?.name ?: "العامل", onBack = { app.pop() }, actions = { IconButton(onClick = { dlg = "edit" }) { Icon(Icons.Filled.Edit, "تعديل", tint = Color.White) } }) {
        if (worker == null) return@Screen
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Card2(Modifier.fillMaxWidth()) {
                Info("الوظيفة", worker.job); Info("طريقة الأجر", when (worker.payType) { "MONTHLY" -> "شهري"; "DAILY" -> "يومي"; else -> "بالساعة" }); Info("الأجر", Fmt.iqd(worker.rateIqd))
                Info("رصيد السلف المتبقي", Fmt.iqd(bal ?: 0), if ((bal ?: 0) > 0) t.warn else t.good)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("سلفة", t.warn, Modifier.weight(1f)) { advAmt = ""; advNote = ""; dlg = "adv" }
                if (app.can(Perm.PAYROLL)) BigButton("كشف راتب", t.primary, Modifier.weight(1f)) { units = ""; bonus = ""; ded = ""; advDed = ""; dlg = "slip" }
            }
            SpecTable(Reports.slips(id), listOf(90, 90, 80, 90, 90, 100, 80), Modifier.weight(1f), "slips-${worker.name}", id, onRowClick = { r -> if (app.can(Perm.PAYROLL)) slipId = r.id })
        }
        if (dlg == "edit") WorkerForm(worker) { dlg = "" }
        if (dlg == "adv") AlertDialog(onDismissRequest = { dlg = "" }, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text("تسجيل سلفة") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Field("المبلغ", advAmt, { advAmt = it }, number = true); Field("ملاحظة", advNote, { advNote = it }) } },
            confirmButton = { TextButton(onClick = { scope.launch { app.handle(app.c.repo.addAdvance(id, Fmt.parseMoney(advAmt) ?: 0, Fmt.today().toEpochDay(), advNote, app.uid()), "سُجّلت السلفة وخرجت من الصندوق") }; dlg = "" }) { Text("حفظ", color = t.primary) } },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("تراجع", color = t.sub) } })
        if (dlg == "slip") AlertDialog(onDismissRequest = { dlg = "" }, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text("كشف راتب") },
            text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("الشهر", ym, { ym = Fmt.normDigits(it) })
                if (worker.payType != "MONTHLY") Field(if (worker.payType == "DAILY") "عدد الأيام" else "عدد الساعات", units, { units = it }, number = true)
                Field("مكافآت", bonus, { bonus = it }, number = true); Field("استقطاعات", ded, { ded = it }, number = true)
                Field("خصم سلفة (المتبقي ${Fmt.money(bal ?: 0)})", advDed, { advDed = it }, number = true)
                Text("مبلغ خصم السلفة تحدده أنت في كل راتب ولا يتجاوز المتبقي.", fontSize = 12.sp, color = t.sub) } },
            confirmButton = { TextButton(onClick = { scope.launch { app.handle(app.c.repo.createSlip(id, ym, Fmt.parseMoney(units) ?: 0, Fmt.parseMoney(bonus) ?: 0, Fmt.parseMoney(ded) ?: 0, Fmt.parseMoney(advDed) ?: 0, app.uid()), "أُنشئ الكشف (مسودة)") }; dlg = "" }) { Text("إنشاء", color = t.primary) } },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("تراجع", color = t.sub) } })
        val sp = slip
        if (slipId != null && sp != null) AlertDialog(onDismissRequest = { slipId = null }, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text("كشف ${sp.periodYm}") },
            text = { Column {
                Info("الأساسي", Fmt.iqd(sp.basicIqd)); Info("مكافآت", Fmt.iqd(sp.bonusIqd)); Info("استقطاعات", Fmt.iqd(sp.deductionsIqd)); Info("خصم سلفة", Fmt.iqd(sp.advanceDeductionIqd))
                Info("الصافي", Fmt.iqd(sp.netIqd), t.good); Info("الحالة", sp.status)
            } },
            confirmButton = { Row {
                if (sp.status == "DRAFT") TextButton(onClick = { scope.launch { app.handle(app.c.repo.approveSlip(sp.id, app.uid()), "تم الاعتماد") }; slipId = null }) { Text("اعتماد", color = t.primary) }
                if (sp.status == "APPROVED") TextButton(onClick = { scope.launch { app.handle(app.c.repo.paySlip(sp.id, app.uid()), "تم الصرف وسُجّل في الصندوق") }; slipId = null }) { Text("صرف", color = t.good) }
                if (sp.status != "VOID") TextButton(onClick = {
                    val rows = listOf("العامل" to worker.name, "الشهر" to sp.periodYm, "الأساسي" to Fmt.iqd(sp.basicIqd), "مكافآت" to Fmt.iqd(sp.bonusIqd),
                        "استقطاعات" to Fmt.iqd(sp.deductionsIqd), "خصم سلفة" to Fmt.iqd(sp.advanceDeductionIqd), "الصافي" to Fmt.iqd(sp.netIqd)).map { TableRow(null, listOf(it.first, it.second)) }
                    Exporter.share(ctx, Exporter.pdfTable(ctx, "slip-${worker.name}-${sp.periodYm}", "قسيمة راتب", app.c.settings.get("gen_name"), listOf("البند", "القيمة"), rows, null), "application/pdf")
                }) { Text("PDF") }
            } },
            dismissButton = { Row {
                if (sp.status == "DRAFT" || sp.status == "APPROVED") TextButton(onClick = { dlg = "voidslip" }) { Text("إلغاء", color = t.bad) }
                TextButton(onClick = { slipId = null }) { Text("إغلاق", color = t.sub) } } })
        if (dlg == "voidslip" && sp != null) ReasonDialog("إلغاء كشف الراتب", "إلغاء", true, { dlg = "" }) { r ->
            scope.launch { app.handle(app.c.repo.voidSlip(sp.id, r, app.uid()), "تم الإلغاء") }; dlg = ""; slipId = null }
    }
}

// ───────────── الصندوق ─────────────
@Composable
fun CashScreen() {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope()
    if (!app.can(Perm.CASH)) { Screen("الصندوق") { Empty("لا تملك الصلاحية") }; return }
    val balance by app.c.db.cash().balance().collectAsState(0L)
    var from by remember { mutableStateOf(currentYm()) }; var to by remember { mutableStateOf(currentYm()) }; var q by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf("") }; var amt by remember { mutableStateOf("") }; var reason by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("أخرى") }
    val closings by load { ReportEngine.run(app.c.db, ReportSpec("إغلاقات الصندوق", listOf("التاريخ", "رصيد النظام", "النقد الفعلي", "الفرق", "السبب"),
        "SELECT id AS _id, strftime('%Y-%m-%d %H:%M', closedAt/1000+10800,'unixepoch') AS d, systemBalanceIqd AS s, actualBalanceIqd AS a, differenceIqd AS f, COALESCE(reason,'') AS r FROM cash_closings",
        emptyList(), setOf(1, 2, 3), emptySet(), true, "d DESC"), 20, 0, false) }
    Screen("الصندوق", onBack = { app.pop() }) {
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Card2(Modifier.fillMaxWidth()) { Text("رصيد الصندوق الحالي", color = t.sub); Text(Fmt.iqd(balance), color = if (balance >= 0) t.good else t.bad, fontSize = 26.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold) }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                BigButton("إيراد", t.good, Modifier.weight(1f)) { amt = ""; reason = ""; dlg = "IN" }
                BigButton("صرف", t.warn, Modifier.weight(1f)) { amt = ""; reason = ""; dlg = "OUT" }
                BigButton("إغلاق", t.primary, Modifier.weight(1f)) { amt = ""; reason = ""; dlg = "close" }
            }
            Field("بحث", q, { q = it })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Field("من", from, { from = Fmt.normDigits(it) }, Modifier.weight(1f)); Field("إلى", to, { to = Fmt.normDigits(it) }, Modifier.weight(1f)) }
            if (ymOk(from) && ymOk(to)) SpecTable(Reports.cash(q.trim(), from, to), listOf(130, 220, 120, 100, 100), Modifier.weight(1f), "cashbook", listOf(q, from, to),
                colorFor = { i, r -> if (i == 3 && r.cells[3] != "0") t.good else if (i == 4 && r.cells[4] != "0") t.bad else null })
            closings?.let { c -> if (c.rows.isNotEmpty()) Text("آخر إغلاق: ${c.rows.first().cells[0]} — الفرق ${c.rows.first().cells[3]}", color = t.sub, fontSize = 12.sp) }
        }
        if (dlg == "IN" || dlg == "OUT") AlertDialog(onDismissRequest = { dlg = "" }, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text(if (dlg == "IN") "قيد إيراد يدوي" else "قيد صرف يدوي") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Field("المبلغ", amt, { amt = it }, number = true); Field("السبب (مطلوب)", reason, { reason = it }) } },
            confirmButton = { TextButton(onClick = { val k = dlg; scope.launch { app.handle(app.c.repo.manualCash(k, Fmt.parseMoney(amt) ?: 0, cat, reason, app.uid()), "تم القيد") }; dlg = "" }) { Text("حفظ", color = t.primary) } },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("تراجع", color = t.sub) } })
        if (dlg == "close") {
            val actual = Fmt.parseMoney(amt); val diff = if (actual != null) actual - balance else null
            AlertDialog(onDismissRequest = { dlg = "" }, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text("إغلاق الصندوق") },
                text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Info("رصيد النظام", Fmt.iqd(balance)); Field("النقد الفعلي في الصندوق", amt, { amt = it }, number = true)
                    if (diff != null) Info("الفرق", Fmt.iqd(diff), if (diff == 0L) t.good else t.bad)
                    if (diff != null && diff != 0L) Field("سبب الفرق (إلزامي)", reason, { reason = it }) } },
                confirmButton = { TextButton(enabled = actual != null, onClick = { scope.launch { app.handle(app.c.repo.closeCash(actual ?: 0, reason, app.uid()), "تم إغلاق الصندوق") }; dlg = "" }) { Text("إغلاق", color = t.primary) } },
                dismissButton = { TextButton(onClick = { dlg = "" }) { Text("تراجع", color = t.sub) } })
        }
    }
}
