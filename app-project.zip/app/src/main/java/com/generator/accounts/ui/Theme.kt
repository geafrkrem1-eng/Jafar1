package com.generator.accounts.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

data class ThemePrefs(
    val palette: String = "royal", val dark: Boolean = false, val radius: Int = 18,
    val fontScale: Float = 1f, val primaryHex: String = "", val accentHex: String = ""
)

class Palette(val id: String, val label: String, val dark: Color, val primary: Color, val secondary: Color, val accent: Color, val forceDark: Boolean = false)

val Palettes = listOf(
    Palette("royal", "Royal Blue", Color(0xFF082F49), Color(0xFF0369A1), Color(0xFF00CED1), Color(0xFFD4AF37)),
    Palette("turquoise", "Turquoise", Color(0xFF0B3C49), Color(0xFF0891B2), Color(0xFF00CED1), Color(0xFF38BDF8)),
    Palette("emerald", "Emerald", Color(0xFF064E3B), Color(0xFF059669), Color(0xFF34D399), Color(0xFFD4AF37)),
    Palette("purple", "Royal Purple", Color(0xFF2E1065), Color(0xFF7C3AED), Color(0xFF8B5CF6), Color(0xFFD4AF37)),
    Palette("midnight", "Midnight", Color(0xFF0B1220), Color(0xFF1D4ED8), Color(0xFF38BDF8), Color(0xFFD4AF37), forceDark = true)
)

/** ألوان صريحة لكل مكوّن (لا اعتماد على ألوان النظام) لتفادي قلب الألوان في MIUI. */
class Tokens(
    val dark: Color, val primary: Color, val secondary: Color, val accent: Color,
    val bg: Color, val card: Color, val altRow: Color, val text: Color, val sub: Color, val line: Color,
    val good: Color = Color(0xFF10B981), val warn: Color = Color(0xFFF59E0B), val bad: Color = Color(0xFFEF4444),
    val purple: Color = Color(0xFF8B5CF6), val radius: Int, val isDark: Boolean
)

val LocalTok = staticCompositionLocalOf<Tokens> { error("no theme") }

private fun hex(s: String): Color? = runCatching {
    val t = s.trim().removePrefix("#"); if (t.length != 6) null else Color(("FF$t").toLong(16))
}.getOrNull()

@Composable
fun AppTheme(prefs: ThemePrefs, content: @Composable () -> Unit) {
    val pal = Palettes.firstOrNull { it.id == prefs.palette } ?: Palettes[0]
    val dark = prefs.dark || pal.forceDark
    val primary = hex(prefs.primaryHex) ?: pal.primary
    val accent = hex(prefs.accentHex) ?: pal.accent
    val t = if (dark) Tokens(pal.dark, primary, pal.secondary, accent, Color(0xFF0B1220), Color(0xFF14243A), Color(0xFF1A2E48),
        Color(0xFFE8EEF4), Color(0xFF9DB0C3), Color(0xFF2B4361), radius = prefs.radius, isDark = true)
    else Tokens(pal.dark, primary, pal.secondary, accent, Color(0xFFF4F8FB), Color.White, Color(0xFFEAF2F8),
        Color(0xFF0F2A3D), Color(0xFF5B7285), Color(0xFFD3DFE8), radius = prefs.radius, isDark = false)
    val scheme = if (dark) darkColorScheme(primary = t.primary, onPrimary = Color.White, secondary = t.secondary, tertiary = t.accent,
        background = t.bg, onBackground = t.text, surface = t.card, onSurface = t.text, surfaceVariant = t.altRow,
        onSurfaceVariant = t.sub, outline = t.line, error = t.bad)
    else lightColorScheme(primary = t.primary, onPrimary = Color.White, secondary = t.secondary, tertiary = t.accent,
        background = t.bg, onBackground = t.text, surface = t.card, onSurface = t.text, surfaceVariant = t.altRow,
        onSurfaceVariant = t.sub, outline = t.line, error = t.bad)
    val d = LocalDensity.current
    val r = prefs.radius.dp
    MaterialTheme(colorScheme = scheme, shapes = Shapes(small = RoundedCornerShape(r / 2), medium = RoundedCornerShape(r), large = RoundedCornerShape(r * 1.3f))) {
        CompositionLocalProvider(LocalTok provides t, LocalDensity provides Density(d.density, d.fontScale * prefs.fontScale)) {
            content()
        }
    }
}
