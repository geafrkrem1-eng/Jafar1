package com.generator.accounts.data

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * كل تعديل على المخطط = Migration حقيقي هنا + رفع رقم الإصدار + ملف schema في app/schemas.
 * 1 → 2: الدورات التقويمية (أعمدة الفواتير)، البوردات (جدول + عمود المشترك). لا يُحذف شيء.
 * الفواتير القديمة تبقى بتواريخ استحقاقها القديمة بلا فترة تسديد (graceEnd = dueEpochDay).
 */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE subscribers ADD COLUMN boardId TEXT")
        for (c in listOf("cycleStartEpochDay INTEGER", "cycleEndEpochDay INTEGER", "cycleDays INTEGER", "daysCharged INTEGER",
            "fullAmount INTEGER", "activationEpochDay INTEGER", "graceEndEpochDay INTEGER", "isProrated INTEGER"))
            db.execSQL("ALTER TABLE invoices ADD COLUMN $c NOT NULL DEFAULT 0")
        // COALESCE يحمي من أي قيمة شهر غير صالحة فلا ينهار الترحيل
        db.execSQL("""UPDATE invoices SET
            cycleStartEpochDay = COALESCE(CAST(strftime('%s', periodYm || '-01') / 86400 AS INTEGER), 0),
            cycleEndEpochDay = COALESCE(CAST(strftime('%s', periodYm || '-01', '+1 month') / 86400 AS INTEGER), 0),
            fullAmount = baseAmount,
            activationEpochDay = COALESCE(CAST(strftime('%s', periodYm || '-01') / 86400 AS INTEGER), 0),
            graceEndEpochDay = dueEpochDay,
            isProrated = CASE WHEN firstMonthNote LIKE '%نسبي%' THEN 1 ELSE 0 END""")
        db.execSQL("UPDATE invoices SET cycleDays = cycleEndEpochDay - cycleStartEpochDay, daysCharged = cycleEndEpochDay - cycleStartEpochDay")
        db.execSQL("""CREATE TABLE IF NOT EXISTS `boards` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `sortOrder` INTEGER NOT NULL,
            `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, `createdBy` TEXT NOT NULL, `updatedBy` TEXT NOT NULL,
            `createdDeviceId` TEXT NOT NULL, `updatedDeviceId` TEXT NOT NULL, `isDeleted` INTEGER NOT NULL, PRIMARY KEY(`id`))""")
    }
}

object Migrations {
    val ALL: Array<Migration> = arrayOf(MIGRATION_1_2)
}
