package com.generator.accounts.data

import androidx.room.migration.Migration

/**
 * كل تعديل على المخطط = Migration حقيقي هنا + رفع رقم الإصدار + ملف schema في app/schemas.
 * لا يوجد تعديل بعد الإصدار 1 حتى الآن.
 */
object Migrations {
    val ALL: Array<Migration> = emptyArray()
}
