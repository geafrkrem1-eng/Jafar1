package com.generator.accounts.output

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import com.generator.accounts.core.Fmt
import java.io.File

/** بيانات كشف الحساب (مستند مستقل عن وصل القبض). */
data class StatementData(
    val genName: String, val manager: String, val phone: String, val address: String, val logo: Bitmap?,
    val subName: String, val subCode: String, val amps: Int, val board: String,
    val printedBy: String, val printedAt: String,
    val headers: List<String>, val rows: List<List<String>>,
    val totalDue: Long, val totalPaid: Long, val remaining: Long, val lateAmount: Long, val settlement: String
)

/** نسخة مختصرة (حرارية 58/80mm) وللمعاينة قبل الطباعة. */
object StatementRenderer {
    private fun lay(text: String, size: Float, bold: Boolean, center: Boolean, w: Int, color: Int = Color.BLACK): StaticLayout {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; isFakeBoldText = bold; this.color = color }
        return StaticLayout.Builder.obtain(text, 0, text.length, p, w)
            .setAlignment(if (center) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.RTL).setLineSpacing(0f, 1.1f).build()
    }

    fun draw(canvas: Canvas?, d: StatementData, w: Int): Int {
        val pad = (w * 0.04f).toInt(); val inner = w - 2 * pad; val base = w / 24f
        var y = pad.toFloat()
        fun put(t: String, size: Float = base, bold: Boolean = false, center: Boolean = false, color: Int = Color.BLACK) {
            if (t.isBlank()) return
            val l = lay(t, size, bold, center, inner, color)
            canvas?.let { it.save(); it.translate(pad.toFloat(), y); l.draw(it); it.restore() }
            y += l.height + base * 0.25f
        }
        fun rule() { canvas?.drawLine(pad.toFloat(), y, (w - pad).toFloat(), y, Paint().apply { color = Color.BLACK; strokeWidth = 1.5f }); y += base * 0.5f }
        canvas?.drawColor(Color.WHITE)
        d.logo?.let { lg -> val h = base * 3f; val ww = h * lg.width / lg.height
            canvas?.drawBitmap(lg, null, RectF((w - ww) / 2, y, (w + ww) / 2, y + h), Paint(Paint.FILTER_BITMAP_FLAG)); y += h + base * 0.3f }
        put(d.genName, base * 1.3f, true, true)
        if (d.manager.isNotBlank()) put("المدير: ${d.manager}", base * 0.9f, false, true)
        put(d.phone, base * 0.85f, false, true); put(d.address, base * 0.85f, false, true)
        rule()
        put("كشف حساب", base * 1.15f, true, true)
        put("المشترك: ${d.subName} (${d.subCode})"); put("الأمبيرات: ${d.amps}")
        if (d.board.isNotBlank()) put("البورد: ${d.board}")
        rule()
        for (r in d.rows) {
            put("${r[0].take(10)}  ${r[1]}", base * 0.9f, true)
            val parts = ArrayList<String>()
            if (r[2].isNotBlank()) parts += "مدين ${r[2]}"; if (r[3].isNotBlank()) parts += "دائن ${r[3]}"; parts += "الرصيد ${r[4]}"
            put(parts.joinToString("   "), base * 0.9f)
        }
        rule()
        put("إجمالي المستحق: ${Fmt.iqd(d.totalDue)}"); put("إجمالي المسدد: ${Fmt.iqd(d.totalPaid)}")
        put("المتبقي: ${Fmt.iqd(d.remaining)}", bold = true)
        if (d.lateAmount > 0) put("منه متأخر: ${Fmt.iqd(d.lateAmount)}", color = Color.RED)
        put("حالة التسديد: ${d.settlement}", bold = true)
        rule()
        put("طُبع بواسطة: ${d.printedBy}", base * 0.85f); put(d.printedAt, base * 0.85f)
        return (y + pad).toInt()
    }

    fun render(d: StatementData, w: Int): Bitmap {
        val h = draw(null, d, w)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        draw(Canvas(bmp), d, w); return bmp
    }
}

/** كشف حساب A4: ترويسة المولدة والمشترك، جدول (تاريخ | بيان | مدين | دائن | رصيد) من اليمين، ثم ملخص وختم الطباعة. */
object StatementPdf {
    fun create(ctx: Context, d: StatementData): File {
        val pw = 595; val ph = 842; val m = 32f
        val widths = floatArrayOf(92f, 215f, 70f, 70f, 84f)
        val txt = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f; color = Color.BLACK }
        val bold = TextPaint(txt).apply { isFakeBoldText = true }
        val white = TextPaint(bold).apply { color = Color.WHITE }
        val big = TextPaint(bold).apply { textSize = 17f; color = Color.parseColor("#082F49") }
        val fill = Paint().apply { color = Color.parseColor("#082F49") }
        val alt = Paint().apply { color = Color.parseColor("#EEF4F8") }
        val line = Paint().apply { color = Color.parseColor("#C9D6DF"); strokeWidth = 0.6f }
        val doc = PdfDocument(); var no = 0
        var page: PdfDocument.Page? = null; var c: Canvas? = null; var y = 0f
        fun right(s: String, yy: Float, p: TextPaint, rEdge: Float = pw - m) { c!!.drawText(s, rEdge - p.measureText(s), yy, p) }
        fun cell(s: String, col: Int, yy: Float, p: TextPaint) {
            var edge = pw - m; for (i in 0 until col) edge -= widths[i]
            val n = p.breakText(s, true, widths[col] - 8, null)
            val shown = if (n < s.length) s.take(maxOf(0, n - 1)) + "…" else s
            c!!.drawText(shown, edge - 4 - p.measureText(shown), yy, p)
        }
        fun header() {
            c!!.drawRect(m, y, pw - m, y + 22f, fill)
            d.headers.forEachIndexed { i, h -> cell(h, i, y + 15f, white) }; y += 22f
        }
        fun newPage() {
            page?.let { doc.finishPage(it) }; no++
            page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, no).create()); c = page!!.canvas; y = m
            if (no == 1) {
                d.logo?.let { lg -> val h = 46f; val ww = h * lg.width / lg.height
                    c!!.drawBitmap(lg, null, RectF(m, y, m + ww, y + h), Paint(Paint.FILTER_BITMAP_FLAG)) }
                right(d.genName, y + 16f, big); y += 34f
                if (d.manager.isNotBlank()) { right("المدير: ${d.manager}", y, txt); y += 14f }
                if (d.phone.isNotBlank()) { right("الهاتف: ${d.phone}", y, txt); y += 14f }
                if (d.address.isNotBlank()) { right(d.address, y, txt); y += 14f }
                y += 6f; c!!.drawLine(m, y, pw - m, y, line); y += 18f
                right("كشف حساب", y, big); y += 20f
                right("المشترك: ${d.subName}   (${d.subCode})   —   الأمبيرات: ${d.amps}" + if (d.board.isNotBlank()) "   —   البورد: ${d.board}" else "", y, txt); y += 18f
            } else { right("كشف حساب: ${d.subName} (تابع)", y + 10f, bold); y += 24f }
            header()
        }
        newPage()
        d.rows.forEachIndexed { idx, r ->
            if (y + 22f > ph - 150f) newPage()
            if (idx % 2 == 1) c!!.drawRect(m, y, pw - m, y + 22f, alt)
            r.forEachIndexed { i, s -> cell(s, i, y + 15f, txt) }
            c!!.drawLine(m, y + 22f, pw - m, y + 22f, line); y += 22f
        }
        if (y + 120f > ph - m) newPage()
        y += 16f
        right("إجمالي المستحق: ${Fmt.iqd(d.totalDue)}", y, txt); y += 15f
        right("إجمالي المسدد: ${Fmt.iqd(d.totalPaid)}", y, txt); y += 15f
        right("المتبقي: ${Fmt.iqd(d.remaining)}", y, bold); y += 15f
        if (d.lateAmount > 0) { right("منه متأخر: ${Fmt.iqd(d.lateAmount)}", y, TextPaint(bold).apply { color = Color.RED }); y += 15f }
        right("حالة التسديد: ${d.settlement}", y, bold); y += 26f
        right("طُبع بواسطة: ${d.printedBy}  —  ${d.printedAt}", y, txt)
        page?.let { doc.finishPage(it) }
        val f = File(File(ctx.cacheDir, "exports").apply { mkdirs() }, "statement-${d.subCode}.pdf")
        f.outputStream().use { doc.writeTo(it) }; doc.close(); return f
    }
}
