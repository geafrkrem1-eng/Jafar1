package com.generator.accounts.core

import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** معاملة الشهر الأول للمشترك الجديد: FULL (افتراضي) / PRORATED / FREE. أي خيار غير الكامل يُوثَّق في الفاتورة. */
object FirstMonth {
    fun apply(base: Long, mode: String, start: LocalDate, due: LocalDate, cycleEnd: LocalDate): Pair<Long, String?> = when (mode) {
        "FREE" -> 0L to "الشهر الأول مجاني"
        "PRORATED" -> {
            val len = ChronoUnit.DAYS.between(due, cycleEnd) + 1
            val rem = (ChronoUnit.DAYS.between(start, cycleEnd) + 1).coerceIn(0, len)
            if (rem == len) base to null else (base * rem / len) to "الشهر الأول نسبي: $rem من $len يوماً"
        }
        else -> base to null
    }
}
