package com.generator.accounts.ui

import android.Manifest
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.generator.accounts.Container
import com.generator.accounts.core.Cycles
import com.generator.accounts.core.Fmt
import com.generator.accounts.data.Receipt
import com.generator.accounts.data.Reports
import com.generator.accounts.output.ReceiptData
import com.generator.accounts.output.StatementData
import com.generator.accounts.output.ThermalPrinter
import kotlinx.coroutines.launch
import java.io.File
import java.time.LocalDate

private fun logoOf(c: Container): Bitmap? = File(c.ctx.filesDir, "logo.png").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }
private fun addressOf(c: Container): String = listOf("gen_region", "gen_street", "gen_area").map { c.settings.get(it) }.filter { it.isNotBlank() }.joinToString("، ")

/** بيانات الوصل من القاعدة (القيم وقت القبض). copy = إعادة طباعة: «نسخة» دون أي حركة مالية جديدة. */
suspend fun buildReceiptData(c: Container, id: String, copy: Boolean = false): Pair<Receipt, ReceiptData>? {
    val r = c.db.receipts().get(id) ?: return null
    val s = c.db.subscribers().get(r.subscriberId) ?: return null
    val lines = c.db.allocations().linesFor(id).map { "${it.periodYm}: ${Fmt.money(it.amount)}" + if (it.paidUpTo < it.total) " (جزئي)" else "" }
    val staff = c.db.users().get(r.meta.createdBy)?.name ?: ""
    val st = c.settings
    return r to ReceiptData(st.get("gen_name", "نظام إدارة المولدة"), addressOf(c), st.get("gen_phone"), logoOf(c), r.serialNo,
        Fmt.dateTime(r.paidAtMillis), s.fullName, s.code, s.amps, lines.joinToString("، "), r.amountIqd, r.method,
        r.balanceBeforeIqd, r.balanceAfterIqd, staff, st.get("receipt_footer"), r.status == "CANCELLED", r.cancelReason,
        manager = st.get("gen_owner"), monthLines = lines, settlement = Cycles.settlement(r.amountIqd, r.balanceAfterIqd),
        isCopy = copy, copyStamp = if (copy) Fmt.dateTime(System.currentTimeMillis()) else "")
}

/** كشف الحساب: الاشتراكات (مع ملاحظة النسبي) والدفعات والإلغاءات برصيد تراكمي، وملخص بالمتأخر. */
suspend fun buildStatementData(c: Container, sid: String, printedBy: String): StatementData? {
    val s = c.db.subscribers().get(sid) ?: return null
    val t = Reports.statement(c.db, sid)
    val det = c.db.invoices().details(sid)
    val today = Fmt.today()
    val total = det.sumOf { it.total }; val paid = det.sumOf { it.paid }; val rem = total - paid
    val late = det.filter { Cycles.status(it.total - it.paid, LocalDate.ofEpochDay(it.graceEndEpochDay), today) == Cycles.Status.LATE }.sumOf { it.total - it.paid }
    val st = c.settings
    val board = s.boardId?.let { c.db.boards().get(it)?.name } ?: ""
    return StatementData(st.get("gen_name", "نظام إدارة المولدة"), st.get("gen_owner"), st.get("gen_phone"), addressOf(c), logoOf(c),
        s.fullName, s.code, s.amps, board, printedBy, Fmt.dateTime(System.currentTimeMillis()),
        t.headers, t.rows.map { it.cells }, total, paid, rem, late, Cycles.settlement(paid, rem))
}

fun currentYm(): String = Fmt.ym(Fmt.today())

/** يعيد دالة طباعة حرارية: تطلب صلاحية البلوتوث عند الحاجة ثم ترسل الصورة. النجاح = أُرسل للطابعة (لا يضمن خروج الورق). */
@Composable
fun rememberThermalPrint(): (build: (Int) -> Bitmap, after: (() -> Unit)?) -> Unit {
    val app = LocalApp.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<Pair<(Int) -> Bitmap, (() -> Unit)?>?>(null) }
    fun go(build: (Int) -> Bitmap, after: (() -> Unit)?) {
        val addr = app.c.settings.get("printer_address")
        if (addr.isBlank()) { app.say("اختر الطابعة أولاً: المزيد > الطابعة الحرارية"); return }
        val w = if (app.c.settings.get("printer_width", "58") == "80") 576 else 384
        scope.launch {
            val e = ThermalPrinter.print(ctx, addr, build(w), w)
            if (e == null) { after?.invoke(); app.say("أُرسل إلى الطابعة (تأكد من خروج الورق)") } else app.say(e)
        }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val p = pending; pending = null
        if (ok && p != null) go(p.first, p.second) else if (!ok) app.say("لا توجد صلاحية البلوتوث")
    }
    return { build, after ->
        if (Build.VERSION.SDK_INT >= 31 && ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            pending = build to after; perm.launch(Manifest.permission.BLUETOOTH_CONNECT)
        } else go(build, after)
    }
}
