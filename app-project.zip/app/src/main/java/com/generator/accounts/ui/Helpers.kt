package com.generator.accounts.ui

import android.graphics.BitmapFactory
import com.generator.accounts.Container
import com.generator.accounts.core.Fmt
import com.generator.accounts.data.Receipt
import com.generator.accounts.output.ReceiptData
import java.io.File

/** يبني بيانات السند من القاعدة لإعادة الطباعة/المعاينة دائماً بالقيم المحفوظة وقت القبض. */
suspend fun buildReceiptData(c: Container, id: String): Pair<Receipt, ReceiptData>? {
    val r = c.db.receipts().get(id) ?: return null
    val s = c.db.subscribers().get(r.subscriberId) ?: return null
    val months = c.db.allocations().monthsFor(id).joinToString("، ")
    val staff = c.db.users().get(r.meta.createdBy)?.name ?: ""
    val logo = File(c.ctx.filesDir, "logo.png").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }
    val st = c.settings
    val addr = listOf(st.get("gen_region"), st.get("gen_street"), st.get("gen_area")).filter { it.isNotBlank() }.joinToString("، ")
    return r to ReceiptData(st.get("gen_name", "نظام إدارة المولدة"), addr, st.get("gen_phone"), logo, r.serialNo,
        Fmt.dateTime(r.paidAtMillis), s.fullName, s.code, s.amps, months, r.amountIqd, r.method, r.balanceBeforeIqd, r.balanceAfterIqd,
        staff, st.get("receipt_footer"), r.status == "CANCELLED", r.cancelReason)
}

fun String.ymNow(): String = Fmt.today().let { "%04d-%02d".format(it.year, it.monthValue) }
fun currentYm(): String = Fmt.today().let { "%04d-%02d".format(it.year, it.monthValue) }
