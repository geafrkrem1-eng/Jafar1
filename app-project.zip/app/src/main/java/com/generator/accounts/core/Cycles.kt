package com.generator.accounts.core

import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit

/**
 * الدورات التقويمية والاشتراك المسبق:
 * الدورة تبدأ يوم 1 وتنتهي «قبل» يوم 1 من الشهر التالي (النهاية حصرية).
 * الاستحقاق من يوم 1، وفترة التسديد أول N يوماً (افتراضي 5). بعدها يصير المتبقي «متأخراً».
 */
object Cycles {
    enum class Status { PAID, IN_GRACE, LATE }

    fun start(ym: YearMonth): LocalDate = ym.atDay(1)
    fun endExclusive(ym: YearMonth): LocalDate = ym.plusMonths(1).atDay(1)
    fun days(ym: YearMonth): Int = ym.lengthOfMonth()                // 28/29/30/31 فعلياً

    /** آخر يوم في فترة التسديد (محسوب). graceDays=5 ⇒ اليوم الخامس. */
    fun graceEnd(ym: YearMonth, graceDays: Int): LocalDate = start(ym).plusDays((maxOf(graceDays, 1) - 1).toLong())

    /** أيام المحاسبة من تاريخ التفعيل (محسوب) حتى نهاية الدورة (غير محسوبة). */
    fun daysFrom(ym: YearMonth, activation: LocalDate): Int =
        ChronoUnit.DAYS.between(activation, endExclusive(ym)).toInt().coerceIn(0, days(ym))

    /** الاشتراك النسبي بأعداد صحيحة مع تقريب لأقرب دينار (نصف لأعلى): كامل × أيام ÷ أيام الدورة. */
    fun prorate(full: Long, days: Int, cycleDays: Int): Long = (full * days * 2 + cycleDays) / (2L * cycleDays)

    fun lateDays(graceEnd: LocalDate, today: LocalDate): Long = maxOf(0L, ChronoUnit.DAYS.between(graceEnd, today))

    fun status(outstanding: Long, graceEnd: LocalDate, today: LocalDate): Status = when {
        outstanding <= 0 -> Status.PAID
        today.isAfter(graceEnd) -> Status.LATE
        else -> Status.IN_GRACE
    }

    /** حالة التسديد المعروضة في الوصل وكشف الحساب. */
    fun settlement(paid: Long, remaining: Long): String = when {
        remaining <= 0 -> "مسدد"
        paid > 0 -> "مسدد جزئياً"
        else -> "غير مسدد"
    }
}
