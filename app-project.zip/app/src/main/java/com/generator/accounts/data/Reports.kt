package com.generator.accounts.data

import com.generator.accounts.core.Fmt
import java.time.LocalDate
import java.time.YearMonth

data class TableRow(val id: String?, val cells: List<String>)
data class TableData(val headers: List<String>, val rows: List<TableRow>, val totals: List<String>?, val hasMore: Boolean)

/**
 * مواصفة جدول: SQL بأسماء أعمدة بسيطة. إن hasId فالعمود الأول (_id) مخفي ويُستخدم لفتح التفاصيل.
 * moneyCols/sumCols بفهارس الأعمدة المعروضة (بدون _id). totalExprs لاستبدال SUM الافتراضي.
 */
class ReportSpec(
    val title: String, val headers: List<String>, val sql: String, val args: List<String> = emptyList(),
    val moneyCols: Set<Int> = emptySet(), val sumCols: Set<Int> = emptySet(),
    val hasId: Boolean = false, val orderBy: String = "", val totalExprs: Map<Int, String> = emptyMap()
)

object ReportEngine {
    /** يُستدعى من خيط الخلفية فقط. */
    fun run(db: AppDatabase, spec: ReportSpec, limit: Int, offset: Int, withTotals: Boolean): TableData {
        val sdb = db.openHelper.readableDatabase
        val order = if (spec.orderBy.isBlank()) "" else " ORDER BY ${spec.orderBy}"
        val rows = ArrayList<TableRow>()
        var names = emptyList<String>()
        sdb.query("SELECT * FROM (${spec.sql})$order LIMIT ${limit + 1} OFFSET $offset", spec.args.toTypedArray()).use { c ->
            names = c.columnNames.toList()
            val start = if (spec.hasId) 1 else 0
            while (c.moveToNext() && rows.size <= limit) {
                val cells = (start until c.columnCount).map { i ->
                    val shown = i - start
                    if (c.isNull(i)) "" else if (shown in spec.moneyCols) Fmt.money(c.getLong(i)) else c.getString(i) ?: ""
                }
                rows += TableRow(if (spec.hasId) c.getString(0) else null, cells)
            }
        }
        val hasMore = rows.size > limit
        val shown = if (hasMore) rows.take(limit) else rows
        var totals: List<String>? = null
        if (withTotals && spec.sumCols.isNotEmpty()) {
            val start = if (spec.hasId) 1 else 0
            val exprs = spec.sumCols.sorted().map { col ->
                spec.totalExprs[col] ?: "COALESCE(SUM(\"${names.getOrElse(col + start) { "x" }}\"),0)"
            }
            sdb.query("SELECT ${exprs.joinToString(",")} FROM (${spec.sql})", spec.args.toTypedArray()).use { c ->
                if (c.moveToFirst()) {
                    val sorted = spec.sumCols.sorted()
                    totals = spec.headers.indices.map { i ->
                        val k = sorted.indexOf(i)
                        if (k >= 0) Fmt.money(c.getLong(k)) else if (i == 0) "الإجمالي" else ""
                    }
                }
            }
        }
        return TableData(spec.headers, shown, totals, hasMore)
    }

    fun scalar(db: AppDatabase, sql: String, vararg args: String): Long =
        db.openHelper.readableDatabase.query(sql, arrayOf(*args)).use { if (it.moveToFirst()) it.getLong(0) else 0L }
}

/** كل تقارير الجداول. التواريخ تُحوَّل في SQL إلى توقيت بغداد (UTC+3 ثابت). */
object Reports {
    private const val DT = "strftime('%Y-%m-%d %H:%M', @COL@/1000 + 10800, 'unixepoch')"
    private fun dt(col: String) = DT.replace("@COL@", col)
    private fun day(col: String) = "date($col * 86400, 'unixepoch')"
    private const val NOW_DAY = "((CAST(strftime('%s','now') AS INTEGER) + 10800) / 86400)"
    private fun like(q: String, vararg cols: String) =
        if (q.isBlank()) "" else " AND (" + cols.joinToString(" OR ") { "$it LIKE '%' || ? || '%'" } + ")"
    private fun qa(q: String, n: Int) = if (q.isBlank()) emptyList() else List(n) { q }
    fun startMs(ym: String): Long = YearMonth.parse(ym).atDay(1).atStartOfDay(Fmt.zone).toInstant().toEpochMilli()
    fun startDay(ym: String): Long = YearMonth.parse(ym).atDay(1).toEpochDay()
    fun endDay(ym: String): Long = YearMonth.parse(ym).atEndOfMonth().toEpochDay()
    fun endMs(ym: String): Long = YearMonth.parse(ym).plusMonths(1).atDay(1).atStartOfDay(Fmt.zone).toInstant().toEpochMilli() - 1

    private const val INV_PAID = "COALESCE((SELECT SUM(a.amountIqd) FROM receipt_allocations a WHERE a.invoiceId=i.id),0)"

    /**
     * الديون والمتأخرات: «متأخر» = بعد نهاية فترة التسديد (graceEnd) وفيه رصيد. أيام التأخير تُعدّ من اليوم التالي لنهاية الفترة.
     * includeGrace = true يضيف ما هو ضمن فترة التسديد. الدين لا يختفي أبداً حتى التسديد.
     */
    fun debts(q: String, ym: String, amps: Int?, mode: Int, byOldest: Boolean, includeGrace: Boolean = false): ReportSpec {
        val ymF = if (ym.isBlank()) "" else " AND i.periodYm = ?"
        val ampF = if (amps == null) "" else " AND s.amps = ?"
        val modeF = when (mode) { 1 -> " AND paidTotal = 0"; 2 -> " AND paidTotal > 0"; else -> "" }
        val out = "((i.baseAmount+i.adjustmentAmount) - $INV_PAID)"
        val cond = "($out > 0" + (if (includeGrace) "" else " AND $NOW_DAY > i.graceEndEpochDay") + ")"
        val sql = """SELECT _id, name, phone, amps, months, debt, MAX(0, $NOW_DAY - oldestGrace) AS lateDays,
            lastPay, paidTotal, debt AS remaining FROM (
            SELECT s.id AS _id, s.fullName AS name, s.phone AS phone, s.amps AS amps,
             SUM(CASE WHEN $cond THEN 1 ELSE 0 END) AS months,
             SUM(CASE WHEN $cond THEN $out ELSE 0 END) AS debt,
             MIN(CASE WHEN $cond THEN i.graceEndEpochDay END) AS oldestGrace,
             SUM($INV_PAID) AS paidTotal,
             (SELECT ${dt("MAX(r.paidAtMillis)")} FROM receipts r WHERE r.subscriberId = s.id AND r.status='ACTIVE') AS lastPay
            FROM subscribers s JOIN invoices i ON i.subscriberId = s.id AND i.isDeleted = 0
            WHERE s.isDeleted = 0 $ymF $ampF ${like(q, "s.fullName", "s.phone", "s.code")}
            GROUP BY s.id) WHERE debt > 0 $modeF"""
        val args = ArrayList<String>()
        if (ym.isNotBlank()) args += ym
        if (amps != null) args += amps.toString()
        args += qa(q, 3)
        return ReportSpec(if (includeGrace) "الديون والمستحقات" else "الديون والمتأخرات",
            listOf("الاسم", "الهاتف", "الأمبيرات", "أشهر", "إجمالي الدين", "أيام التأخير", "آخر تسديد", "إجمالي المسدد", "المتبقي"),
            sql, args, setOf(4, 7, 8), setOf(4, 7, 8), true,
            if (byOldest) "lateDays DESC" else "debt DESC")
    }

    fun priceLog() = ReportSpec("سجل تغييرات الأسعار",
        listOf("التاريخ", "الشهر", "السعر القديم", "السعر الجديد", "النتيجة", "المنفذ"),
        """SELECT a.id AS _id, ${dt("a.at")} AS at, a.entityId AS ym, a.beforeJson AS oldp, a.afterJson AS newp,
            COALESCE(a.reason,'') AS res, COALESCE(u.name,'') AS who
            FROM audit_log a LEFT JOIN app_users u ON u.id = a.userId WHERE a.entityType = 'PriceChange'""",
        emptyList(), setOf(2, 3), emptySet(), true, "at DESC")

    fun receipts(q: String, fromYm: String, toYm: String) = ReportSpec("سجل السندات",
        listOf("الرقم", "المشترك", "المبلغ", "طريقة الدفع", "التاريخ", "الحالة"),
        """SELECT r.id AS _id, r.serialNo AS serial, s.fullName AS name, r.amountIqd AS amount, r.method AS method,
            ${dt("r.paidAtMillis")} AS at, CASE r.status WHEN 'ACTIVE' THEN 'نافذ' ELSE 'ملغى' END AS st
            FROM receipts r JOIN subscribers s ON s.id = r.subscriberId
            WHERE r.paidAtMillis BETWEEN ? AND ? ${like(q, "s.fullName", "r.serialNo", "s.phone")}""",
        listOf(startMs(fromYm).toString(), endMs(toYm).toString()) + qa(q, 3),
        setOf(2), setOf(2), true, "at DESC",
        mapOf(2 to "COALESCE(SUM(CASE WHEN st='نافذ' THEN amount ELSE 0 END),0)"))

    fun expenses(kind: String, q: String, fromYm: String, toYm: String) = ReportSpec(
        when (kind) { "FUEL" -> "الوقود"; "MAINTENANCE" -> "الصيانة"; else -> "المصاريف العامة" },
        when (kind) {
            "FUEL" -> listOf("التاريخ", "النوع", "اللترات", "سعر اللتر", "الإجمالي", "المورد", "رقم الوصل", "الحالة")
            "MAINTENANCE" -> listOf("التاريخ", "الفئة", "الوصف", "الكلفة", "الفني", "الصيانة القادمة", "الحالة")
            else -> listOf("التاريخ", "الفئة", "المبلغ", "المستلم", "طريقة الدفع", "الوصف", "الحالة")
        },
        when (kind) {
            "FUEL" -> "SELECT e.id AS _id, ${day("e.epochDay")} AS d, COALESCE(e.fuelType,'') AS ft, e.litersMilli/1000.0 AS lit, e.pricePerLiterIqd AS pr, e.amountIqd AS amt, COALESCE(e.supplier,'') AS sup, COALESCE(e.voucherNo,'') AS v, CASE e.status WHEN 'ACTIVE' THEN 'نافذ' ELSE 'ملغى' END AS st"
            "MAINTENANCE" -> "SELECT e.id AS _id, ${day("e.epochDay")} AS d, e.category AS cat, e.description AS ds, e.amountIqd AS amt, COALESCE(e.technician,'') AS tech, COALESCE(${day("e.nextDueEpochDay")},'') AS nx, CASE e.status WHEN 'ACTIVE' THEN 'نافذ' ELSE 'ملغى' END AS st"
            else -> "SELECT e.id AS _id, ${day("e.epochDay")} AS d, e.category AS cat, e.amountIqd AS amt, e.payee AS pe, e.method AS me, e.description AS ds, CASE e.status WHEN 'ACTIVE' THEN 'نافذ' ELSE 'ملغى' END AS st"
        } + " FROM expenses e WHERE e.kind = ? AND e.epochDay BETWEEN ? AND ? ${like(q, "e.description", "e.payee", "e.category")}",
        listOf(kind, startDay(fromYm).toString(), endDay(toYm).toString()) + qa(q, 3),
        when (kind) { "FUEL" -> setOf(3, 4); "MAINTENANCE" -> setOf(3); else -> setOf(2) },
        when (kind) { "FUEL" -> setOf(4); "MAINTENANCE" -> setOf(3); else -> setOf(2) },
        true, "d DESC",
        mapOf((when (kind) { "FUEL" -> 4; "MAINTENANCE" -> 3; else -> 2 }) to "COALESCE(SUM(CASE WHEN st='نافذ' THEN amt ELSE 0 END),0)"))

    fun cash(q: String, fromYm: String, toYm: String) = ReportSpec("حركة الصندوق",
        listOf("التاريخ", "الوصف", "الفئة", "وارد", "صادر"),
        """SELECT c.id AS _id, ${dt("c.occurredAt")} AS at, c.description AS ds, c.category AS cat,
            CASE WHEN c.kind='IN' THEN c.amountIqd ELSE 0 END AS inn, CASE WHEN c.kind='OUT' THEN c.amountIqd ELSE 0 END AS outt
            FROM cash_entries c WHERE c.isDeleted=0 AND c.occurredAt BETWEEN ? AND ? ${like(q, "c.description", "c.category")}""",
        listOf(startMs(fromYm).toString(), endMs(toYm).toString()) + qa(q, 2),
        setOf(3, 4), setOf(3, 4), true, "at DESC")

    fun workers(q: String) = ReportSpec("العمال",
        listOf("الاسم", "الوظيفة", "الهاتف", "طريقة الأجر", "الأجر", "الحالة"),
        """SELECT w.id AS _id, w.name AS n, w.job AS j, w.phone AS p,
            CASE w.payType WHEN 'MONTHLY' THEN 'شهري' WHEN 'DAILY' THEN 'يومي' ELSE 'بالساعة' END AS pt,
            w.rateIqd AS rate, CASE w.status WHEN 'ACTIVE' THEN 'فعال' ELSE 'متوقف' END AS st
            FROM workers w WHERE w.isDeleted=0 ${like(q, "w.name", "w.phone", "w.job")}""",
        qa(q, 3), setOf(4), emptySet(), true, "n ASC")

    fun slips(workerId: String) = ReportSpec("كشوف الرواتب",
        listOf("الشهر", "الأساسي", "مكافأة", "استقطاعات", "خصم سلفة", "الصافي", "الحالة"),
        """SELECT p.id AS _id, p.periodYm AS ym, p.basicIqd AS b, p.bonusIqd AS bo, p.deductionsIqd AS d, p.advanceDeductionIqd AS a, p.netIqd AS n,
            CASE p.status WHEN 'DRAFT' THEN 'مسودة' WHEN 'APPROVED' THEN 'معتمد' WHEN 'PAID' THEN 'مصروف' ELSE 'ملغى' END AS st
            FROM payroll_slips p WHERE p.workerId = ?""",
        listOf(workerId), setOf(1, 2, 3, 4, 5), emptySet(), true, "ym DESC")

    fun payroll(fromYm: String, toYm: String) = ReportSpec("تقرير الرواتب",
        listOf("الشهر", "العامل", "الأساسي", "مكافأة", "استقطاعات", "خصم سلفة", "الصافي", "الحالة"),
        """SELECT p.id AS _id, p.periodYm AS ym, w.name AS n, p.basicIqd AS b, p.bonusIqd AS bo, p.deductionsIqd AS d, p.advanceDeductionIqd AS a, p.netIqd AS net,
            CASE p.status WHEN 'DRAFT' THEN 'مسودة' WHEN 'APPROVED' THEN 'معتمد' WHEN 'PAID' THEN 'مصروف' ELSE 'ملغى' END AS st
            FROM payroll_slips p JOIN workers w ON w.id = p.workerId WHERE p.periodYm BETWEEN ? AND ? AND p.status <> 'VOID'""",
        listOf(fromYm, toYm), setOf(2, 3, 4, 5, 6), setOf(2, 3, 4, 5, 6), true, "ym DESC")

    fun monthlySubscriptions(ym: String, q: String) = ReportSpec("الاشتراكات الشهرية $ym",
        listOf("المشترك", "الأمبيرات", "السعر", "الاشتراك", "التعديلات", "المسدد", "المتبقي", "الاستحقاق"),
        """SELECT s.id || '|' || i.id AS _id, s.fullName AS n, i.amps AS a, i.ampPriceIqd AS pr, i.baseAmount AS base, i.adjustmentAmount AS adj,
            $INV_PAID AS paid, (i.baseAmount + i.adjustmentAmount - $INV_PAID) AS rem, ${day("i.dueEpochDay")} AS due
            FROM invoices i JOIN subscribers s ON s.id = i.subscriberId WHERE i.periodYm = ? AND i.isDeleted=0 ${like(q, "s.fullName", "s.phone", "s.code")}""",
        listOf(ym) + qa(q, 3), setOf(2, 3, 4, 5, 6), setOf(3, 4, 5, 6), true, "n ASC")

    /** الإيرادات (المحصّل) والمصروفات التشغيلية وصافي النتيجة. السلف ليست مصروفاً؛ الراتب يُحتسب صافيه + خصم السلفة. */
    fun incomeExpense(fromYm: String, toYm: String): ReportSpec {
        val months = ArrayList<String>(); var m = YearMonth.parse(fromYm); val end = YearMonth.parse(toYm)
        while (!m.isAfter(end)) { months += m.toString(); m = m.plusMonths(1) }
        val unions = months.joinToString(" UNION ALL ") { "SELECT '$it' AS ym" }
        fun cashM(cat: String) = "(SELECT COALESCE(SUM(CASE WHEN c.kind='IN' THEN c.amountIqd ELSE -c.amountIqd END),0) FROM cash_entries c WHERE $cat AND strftime('%Y-%m', c.occurredAt/1000+10800,'unixepoch') = m.ym)"
        return ReportSpec("الإيرادات والمصروفات وصافي النتيجة التشغيلية",
            listOf("الشهر", "الإيرادات المحصّلة", "مصاريف عامة", "وقود", "صيانة", "رواتب", "إجمالي المصروفات", "صافي النتيجة"),
            """SELECT ym, rev, gen, fuel, maint, pay, (gen+fuel+maint+pay) AS totexp, (rev - gen - fuel - maint - pay) AS net FROM (
              SELECT m.ym AS ym,
               ${cashM("c.category IN ('SUBSCRIBER_RECEIPT','RECEIPT_REVERSAL')")} AS rev,
               (SELECT COALESCE(SUM(CASE WHEN e.status='ACTIVE' THEN e.amountIqd ELSE 0 END),0) FROM expenses e WHERE e.kind='GENERAL' AND strftime('%Y-%m', e.epochDay*86400,'unixepoch') = m.ym) AS gen,
               (SELECT COALESCE(SUM(CASE WHEN e.status='ACTIVE' THEN e.amountIqd ELSE 0 END),0) FROM expenses e WHERE e.kind='FUEL' AND strftime('%Y-%m', e.epochDay*86400,'unixepoch') = m.ym) AS fuel,
               (SELECT COALESCE(SUM(CASE WHEN e.status='ACTIVE' THEN e.amountIqd ELSE 0 END),0) FROM expenses e WHERE e.kind='MAINTENANCE' AND strftime('%Y-%m', e.epochDay*86400,'unixepoch') = m.ym) AS maint,
               (SELECT COALESCE(SUM(p.netIqd + p.advanceDeductionIqd),0) FROM payroll_slips p WHERE p.status='PAID' AND p.periodYm = m.ym) AS pay
              FROM ($unions) m)""",
            emptyList(), setOf(1, 2, 3, 4, 5, 6, 7), setOf(1, 2, 3, 4, 5, 6, 7), false, "ym ASC")
    }

    fun subscribersAll(q: String, ym: String, status: String = "", board: String = "") = ReportSpec("المشتركون",
        listOf("رمز", "الاسم", "الهاتف", "الأمبيرات", "الاشتراك", "البورد", "الدين السابق", "المسدد", "المتبقي", "الحالة"),
        "SELECT id AS _id, code, fullName, phone, amps, monthlyFeeIqd, COALESCE((SELECT b.name FROM boards b WHERE b.id = boardId),'') AS board, prevDebt, paidThisMonth, remaining, CASE status WHEN 'ACTIVE' THEN 'فعال' WHEN 'PAUSED' THEN 'متوقف' ELSE 'ملغى' END AS st FROM ($SUB_INNER)"
            .replace(":ym", "?").replace(":q", "?").replace(":status", "?").replace(":board", "?"),
        listOf(ym, ym, q, q, q, q, status, status, board, board, board), setOf(4, 6, 7, 8), setOf(3, 4, 6, 7, 8), true, "fullName ASC")

    fun fuelConsumptionDaily(fromYm: String, toYm: String) = ReportSpec("استهلاك الوقود اليومي",
        listOf("التاريخ", "اللترات", "الكلفة", "متوسط سعر اللتر"),
        """SELECT date(e.epochDay*86400,'unixepoch') AS d, SUM(e.litersMilli)/1000.0 AS lit, SUM(e.amountIqd) AS cost,
           CASE WHEN SUM(e.litersMilli)>0 THEN SUM(e.amountIqd)*1000/SUM(e.litersMilli) ELSE 0 END AS avgp
           FROM expenses e WHERE e.kind='FUEL' AND e.status='ACTIVE' AND e.epochDay BETWEEN ? AND ? GROUP BY e.epochDay""",
        listOf(startDay(fromYm).toString(), endDay(toYm).toString()),
        setOf(2, 3), setOf(2), false, "d DESC")

    /** كشف حساب مشترك من الفواتير والسندات (الإلغاء يظهر كقيد عكسي). الرصيد التراكمي يُحسب هنا. */
    suspend fun statement(db: AppDatabase, sid: String): TableData {
        data class E(val at: Long, val text: String, val debit: Long, val credit: Long)
        val list = ArrayList<E>()
        for (i in db.invoices().forSubscriber(sid)) {
            val total = i.baseAmount + i.adjustmentAmount
            list += E(LocalDate.ofEpochDay(i.dueEpochDay).atStartOfDay(Fmt.zone).toInstant().toEpochMilli(),
                "اشتراك ${i.periodYm}" + (i.firstMonthNote?.let { " ($it)" } ?: ""), total, 0)
        }
        for (r in db.receipts().forSubscriber(sid)) {
            list += E(r.paidAtMillis, "سند قبض ${r.serialNo}", 0, r.amountIqd)
            if (r.status == "CANCELLED") list += E(r.cancelledAt ?: r.paidAtMillis, "إلغاء سند ${r.serialNo}: ${r.cancelReason ?: ""}", r.amountIqd, 0)
        }
        var bal = 0L
        val rows = list.sortedBy { it.at }.map { e ->
            bal += e.debit - e.credit
            TableRow(null, listOf(Fmt.dateTime(e.at), e.text, if (e.debit > 0) Fmt.money(e.debit) else "", if (e.credit > 0) Fmt.money(e.credit) else "", Fmt.money(bal)))
        }
        val totals = listOf("الإجمالي", "", Fmt.money(list.sumOf { it.debit }), Fmt.money(list.sumOf { it.credit }), Fmt.money(bal))
        return TableData(listOf("التاريخ", "البيان", "مدين", "دائن", "الرصيد"), rows, totals, false)
    }
}

data class Kpis(
    val activeSubs: Long, val totalAmps: Long, val billed: Long, val collected: Long, val outstanding: Long,
    val expenses: Long, val fuel: Long, val cash: Long, val monthly: List<Triple<String, Long, Long>>,
    val expenseByCat: List<Pair<String, Long>>, val lateDebt: Long = 0, val graceDue: Long = 0
)

object Stats {
    fun load(db: AppDatabase, ym: String): Kpis {
        fun s(sql: String, vararg a: String) = ReportEngine.scalar(db, sql, *a)
        val monthExp = "(SELECT COALESCE(SUM(amountIqd),0) FROM expenses WHERE status='ACTIVE' AND kind=? AND strftime('%Y-%m', epochDay*86400,'unixepoch') = ?)"
        fun expOf(m: String) = s("SELECT ${monthExp.replace("kind=?", "kind='GENERAL'")} + ${monthExp.replace("kind=?", "kind='FUEL'")} + ${monthExp.replace("kind=?", "kind='MAINTENANCE'")} + (SELECT COALESCE(SUM(netIqd+advanceDeductionIqd),0) FROM payroll_slips WHERE status='PAID' AND periodYm=?)", m, m, m, m)
        fun colOf(m: String) = s("SELECT COALESCE(SUM(CASE WHEN kind='IN' THEN amountIqd ELSE -amountIqd END),0) FROM cash_entries WHERE category IN ('SUBSCRIBER_RECEIPT','RECEIPT_REVERSAL') AND strftime('%Y-%m', occurredAt/1000+10800,'unixepoch') = ?", m)
        val cur = YearMonth.parse(ym)
        val monthly = (5 downTo 0).map { k -> val m = cur.minusMonths(k.toLong()).toString(); Triple(m, colOf(m), expOf(m)) }
        val cats = ArrayList<Pair<String, Long>>()
        db.openHelper.readableDatabase.query(
            "SELECT category, SUM(amountIqd) FROM expenses WHERE status='ACTIVE' AND strftime('%Y-%m', epochDay*86400,'unixepoch') = ? GROUP BY category ORDER BY 2 DESC LIMIT 6", arrayOf(ym)
        ).use { while (it.moveToNext()) cats += it.getString(0) to it.getLong(1) }
        val outstanding = s("SELECT COALESCE(SUM(i.baseAmount+i.adjustmentAmount),0) - COALESCE((SELECT SUM(a.amountIqd) FROM receipt_allocations a),0) FROM invoices i WHERE i.isDeleted=0")
        val late = s("SELECT COALESCE(SUM(t.o),0) FROM (SELECT ((i.baseAmount+i.adjustmentAmount) - COALESCE((SELECT SUM(a.amountIqd) FROM receipt_allocations a WHERE a.invoiceId=i.id),0)) AS o, i.graceEndEpochDay AS g FROM invoices i WHERE i.isDeleted=0) t WHERE t.o > 0 AND t.g < ((CAST(strftime('%s','now') AS INTEGER) + 10800) / 86400)")
        return Kpis(
            s("SELECT COUNT(*) FROM subscribers WHERE isDeleted=0 AND status='ACTIVE'"),
            s("SELECT COALESCE(SUM(amps),0) FROM subscribers WHERE isDeleted=0 AND status='ACTIVE'"),
            s("SELECT COALESCE(SUM(baseAmount+adjustmentAmount),0) FROM invoices WHERE periodYm=? AND isDeleted=0", ym),
            colOf(ym),
            outstanding,
            expOf(ym),
            s("SELECT COALESCE(SUM(amountIqd),0) FROM expenses WHERE status='ACTIVE' AND kind='FUEL' AND strftime('%Y-%m', epochDay*86400,'unixepoch') = ?", ym),
            s("SELECT COALESCE(SUM(CASE WHEN kind='IN' THEN amountIqd ELSE -amountIqd END),0) FROM cash_entries WHERE isDeleted=0"),
            monthly, cats,
            late, maxOf(0L, outstanding - late)
        )
    }

    /** تنبيهات الصيانة القادمة (خلال 7 أيام أو متأخرة). */
    fun maintenanceDue(db: AppDatabase): List<Pair<String, Long>> {
        val out = ArrayList<Pair<String, Long>>()
        db.openHelper.readableDatabase.query(
            "SELECT description, nextDueEpochDay FROM expenses WHERE kind='MAINTENANCE' AND status='ACTIVE' AND nextDueEpochDay IS NOT NULL AND nextDueEpochDay <= ? ORDER BY nextDueEpochDay",
            arrayOf((Fmt.today().toEpochDay() + 7).toString())
        ).use { while (it.moveToNext()) out += it.getString(0) to it.getLong(1) }
        return out
    }
}
