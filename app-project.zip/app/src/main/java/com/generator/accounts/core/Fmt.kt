package com.generator.accounts.core

import java.text.NumberFormat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** التنسيق: IQD بلا كسور، تواريخ ميلادية بأرقام لاتينية، توقيت Asia/Baghdad. */
object Fmt {
    val zone: ZoneId = ZoneId.of("Asia/Baghdad")
    private val dt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm", Locale.US).withZone(zone)
    fun money(v: Long): String = NumberFormat.getIntegerInstance(Locale.US).format(v)
    fun iqd(v: Long): String = money(v) + " د.ع"
    fun date(epochDay: Long): String = LocalDate.ofEpochDay(epochDay).toString()
    fun dateTime(ms: Long): String = dt.format(Instant.ofEpochMilli(ms))
    fun today(): LocalDate = LocalDate.now(zone)
    fun year(ms: Long): Int = Instant.ofEpochMilli(ms).atZone(zone).year
    fun normDigits(s: String): String = buildString {
        for (c in s) append(when (c) { in '\u0660'..'\u0669' -> '0' + (c - '\u0660'); in '\u06F0'..'\u06F9' -> '0' + (c - '\u06F0'); else -> c })
    }
    /** يحوّل نص المستخدم إلى مبلغ Long (يتجاهل الفواصل والمسافات). null إن لم يكن رقماً صالحاً. */
    fun parseMoney(s: String): Long? {
        val d = normDigits(s).filter { it.isDigit() }
        return if (d.isEmpty() || d.length > 13) null else d.toLongOrNull()
    }
    /** كمية اللترات × 1000 بلا Double: "12.5" → 12500 */
    fun parseLitersMilli(s: String): Long? {
        val n = normDigits(s).replace(',', '.').trim()
        val bd = n.toBigDecimalOrNull() ?: return null
        if (bd.signum() <= 0) return null
        return bd.movePointRight(3).toBigInteger().toLong()
    }
    fun liters(milli: Long): String = java.math.BigDecimal(milli).movePointLeft(3).stripTrailingZeros().toPlainString()
}
