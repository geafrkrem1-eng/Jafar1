package com.generator.accounts.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.generator.accounts.core.*
import com.generator.accounts.data.*
import com.generator.accounts.output.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.system.exitProcess

// ───────────── التقارير (12) ─────────────
@Composable
fun ReportsScreen() {
    val app = LocalApp.current; val t = LocalTok.current; val ctx = LocalContext.current
    if (!app.can(Perm.REPORTS)) { Screen("التقارير") { Empty("لا تملك الصلاحية") }; return }
    var kind by remember { mutableStateOf("subs") }
    var q by remember { mutableStateOf("") }
    var from by remember { mutableStateOf(currentYm()) }; var to by remember { mutableStateOf(currentYm()) }
    var subId by remember { mutableStateOf<String?>(null) }
    var rBoard by remember { mutableStateOf("") }
    val boardsR by load { app.c.db.boards().all() }
    val names = listOf("subs" to "المشتركين", "monthly" to "الاشتراكات الشهرية", "collect" to "التحصيل", "debts" to "الديون والمتأخرات",
        "inex" to "الإيرادات والمصروفات", "net" to "صافي الربح التشغيلي", "fuel" to "الوقود والاستهلاك", "maint" to "الصيانة",
        "payroll" to "الرواتب", "cash" to "الصندوق", "stmt" to "كشف حساب مشترك", "full" to "تقرير شامل شهري/سنوي")
    val okRange = runCatching { java.time.YearMonth.parse(from); java.time.YearMonth.parse(to) }.isSuccess
    fun retitle(s: ReportSpec, title: String) = ReportSpec(title, s.headers, s.sql, s.args, s.moneyCols, s.sumCols, s.hasId, s.orderBy, s.totalExprs)
    val found by load(q, kind) { if (kind == "stmt" && q.isNotBlank()) app.c.db.subscribers().quickSearch(q.trim()) else emptyList() }
    val stmt by load(subId, kind) { if (kind == "stmt" && subId != null) Reports.statement(app.c.db, subId!!) else null }
    Screen("التقارير", onBack = { app.pop() }) {
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Chips(names, kind) { kind = it; subId = null }
            if (kind == "subs") Chips(listOf("" to "كل البوردات", "-" to "بدون بورد") + (boardsR ?: emptyList()).map { it.id to it.name }, rBoard) { rBoard = it }
            if (kind in listOf("subs", "monthly", "collect", "debts", "fuel", "maint", "cash", "stmt")) Field(if (kind == "stmt") "ابحث عن مشترك" else "بحث / تصفية (اسم، فئة...)", q, { q = it })
            if (kind !in listOf("subs", "debts", "stmt")) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("من شهر", from, { from = Fmt.normDigits(it) }, Modifier.weight(1f)); Field(if (kind == "monthly") "الشهر" else "إلى شهر", to, { to = Fmt.normDigits(it) }, Modifier.weight(1f))
            }
            if (kind == "full") Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { from = currentYm(); to = currentYm() }) { Text("شهري") }
                OutlinedButton(onClick = { val y = Fmt.today().year; from = "$y-01"; to = "$y-12" }) { Text("سنوي") }
            }
            val title = names.first { it.first == kind }.second
            val spec: ReportSpec? = if (!okRange && kind !in listOf("subs", "debts", "stmt")) null else when (kind) {
                "subs" -> retitle(Reports.subscribersAll(q.trim(), currentYm(), "", rBoard), title)
                "monthly" -> Reports.monthlySubscriptions(to, q.trim())
                "collect" -> retitle(Reports.receipts(q.trim(), from, to), title)
                "debts" -> Reports.debts(q.trim(), "", null, 0, false)
                "inex", "net", "full" -> retitle(Reports.incomeExpense(from, to), title)
                "fuel" -> Reports.expenses("FUEL", q.trim(), from, to)
                "maint" -> Reports.expenses("MAINTENANCE", q.trim(), from, to)
                "payroll" -> Reports.payroll(from, to)
                "cash" -> Reports.cash(q.trim(), from, to)
                else -> null
            }
            if (kind == "stmt") {
                if (subId == null) (found ?: emptyList()).forEach { s -> Card2(Modifier.fillMaxWidth(), onClick = { subId = s.id; q = "" }) { Text("${s.fullName} (${s.code})", color = t.text) } }
                else stmt?.let { st ->
                    DataTable(st.headers, st.rows, st.totals, listOf(140, 190, 90, 90, 100), Modifier.weight(1f))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { Exporter.share(ctx, Exporter.csv(ctx, "statement", st.headers, st.rows, st.totals), "text/csv") }) { Text("CSV") }
                        OutlinedButton(onClick = { Exporter.share(ctx, Exporter.pdfTable(ctx, "statement", "كشف حساب مشترك", app.c.settings.get("gen_name") + " - " + Exporter.stamp(), st.headers, st.rows, st.totals), "application/pdf") }) { Text("PDF") }
                    }
                }
            } else if (spec != null) {
                val w = spec.headers.indices.map { if (it == 0) 150 else 110 }
                SpecTable(spec, w, Modifier.weight(1f), "report-$kind", listOf(kind, q, from, to, rBoard))
            } else Text("صيغة الشهر 2026-11", color = t.bad)
            if (kind in listOf("inex", "net", "full")) Text("الإيرادات = المحصّل النقدي من المشتركين. السلف ليست مصروفاً؛ الراتب يُحتسب بصافيه + خصم السلفة. لا تُحتسب التحويلات الداخلية مرتين.", color = t.sub, fontSize = 11.sp)
        }
    }
}

// ───────────── المستخدمون ─────────────
@Composable
fun UsersScreen() {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope()
    if (!app.can(Perm.USERS)) { Screen("المستخدمون") { Empty("لا تملك الصلاحية") }; return }
    val users by load { app.c.db.users().all() }
    var editing by remember { mutableStateOf<AppUser?>(null) }; var adding by remember { mutableStateOf(false) }
    Screen("المستخدمون والصلاحيات", onBack = { app.pop() }, actions = { IconButton(onClick = { adding = true }) { Icon(Icons.Filled.PersonAdd, "إضافة", tint = Color.White) } }) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            (users ?: emptyList()).forEach { u ->
                Card2(Modifier.fillMaxWidth(), onClick = { editing = u }) { Row {
                    Text(u.name, color = t.text, modifier = Modifier.weight(1f)); Text(when (u.role) { "ADMIN" -> "مدير"; "ACCOUNTANT" -> "محاسب"; else -> "موظف" } + if (!u.active) " (موقوف)" else "", color = t.sub) } }
            }
        }
        if (adding || editing != null) UserForm(editing, onClose = { adding = false; editing = null })
    }
}

@Composable
private fun UserForm(u: AppUser?, onClose: () -> Unit) {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(u?.name ?: "") }; var role by remember { mutableStateOf(u?.role ?: "STAFF") }
    var pin by remember { mutableStateOf("") }; var active by remember { mutableStateOf(u?.active ?: true) }
    var perms by remember { mutableStateOf(u?.let { Perm.effective(it.role, it.permissionsCsv) } ?: Perm.staffDefault) }
    AlertDialog(onDismissRequest = onClose, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text(if (u == null) "مستخدم جديد" else "تعديل مستخدم") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Field("الاسم", name, { name = it })
            Chips(listOf("ADMIN" to "مدير", "ACCOUNTANT" to "محاسب", "STAFF" to "موظف"), role) { role = it
                perms = when (it) { "ADMIN" -> Perm.all; "ACCOUNTANT" -> Perm.accountant; else -> perms } }
            Field(if (u == null) "PIN (4-8 أرقام)" else "PIN جديد (اتركه فارغاً دون تغيير)", pin, { pin = it }, password = true)
            Row(verticalAlignment = Alignment.CenterVertically) { Switch(active, { active = it }); Spacer(Modifier.width(8.dp)); Text("فعّال") }
            if (role != "ADMIN") { Text("الصلاحيات", color = t.sub, fontSize = 12.sp)
                Perm.labels.forEach { (k, label) -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(k in perms, { on -> perms = if (on) perms + k else perms - k }); Text(label, fontSize = 13.sp) } } }
        } },
        confirmButton = { TextButton(onClick = { scope.launch {
            val r = if (u == null) app.c.repo.createUser(name, role, pin, if (role == "ADMIN") Perm.all else perms, app.uid()).let { x -> if (x is com.generator.accounts.finance.FinResult.Ok) com.generator.accounts.finance.FinResult.Ok(Unit) else x as com.generator.accounts.finance.FinResult.Err }
                    else app.c.repo.updateUser(u.id, name, role, if (role == "ADMIN") Perm.all else perms, active, pin.ifEmpty { null }, app.uid())
            app.handle(r, "تم الحفظ") { onClose() } } }) { Text("حفظ", color = t.primary) } },
        dismissButton = { TextButton(onClick = onClose) { Text("تراجع", color = t.sub) } })
}

// ───────────── الإعدادات ─────────────
@Composable
fun SettingsScreen() {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope(); val ctx = LocalContext.current
    if (!app.can(Perm.SETTINGS)) { Screen("الإعدادات") { Empty("لا تملك الصلاحية") }; return }
    val st = app.c.settings
    val keys = listOf("gen_name" to "اسم المولدة", "gen_owner" to "اسم المالك / المدير", "gen_region" to "المنطقة", "gen_street" to "الشارع", "gen_area" to "المحلة",
        "gen_phone" to "هاتف المولدة", "gen_power" to "القدرة التشغيلية (اختياري)", "gen_tech" to "معلومات فنية (اختياري)", "gen_hours" to "ساعات التشغيل اليومية",
        "gen_days" to "أيام التشغيل", "gen_start" to "تاريخ بدء العمل", "gen_notes" to "ملاحظات", "receipt_footer" to "السطر الختامي للسندات",
        "device_code" to "رمز الجهاز للسندات (حرف أو أكثر)", "app_title" to "اسم التطبيق المعروض",
        "grace_days" to "أيام فترة التسديد من أول الدورة (افتراضي 5)", "new_grace_days" to "فترة تسديد المشترك الجديد بالأيام (افتراضي 1)")
    val draft = remember { mutableStateMapOf<String, String>().also { m -> keys.forEach { (k, _) -> m[k] = st.get(k) } } }
    var price by remember { mutableStateOf(st.get("amp_price", "10000")) }
    var mode by remember { mutableStateOf(st.get("first_month_mode", "FULL")) }
    var lock by remember { mutableStateOf(st.get("lock_minutes", "5")) }
    var tpl by remember { mutableStateOf(st.get("wa_template")) }
    var methods by remember { mutableStateOf(st.get("pay_methods")) }
    var cats by remember { mutableStateOf(st.get("expense_categories")) }
    var tp by remember { mutableStateOf(app.prefs()) }
    DisposableEffect(Unit) { onDispose { app.themePreview = null } }
    LaunchedEffect(tp) { app.themePreview = tp }       // معاينة مباشرة قبل الحفظ
    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch { val p = withContext(Dispatchers.IO) { ImageUtil.save(ctx, uri, "logo.png", 512) }
            if (p != null) { withContext(Dispatchers.IO) { File(p).copyTo(File(ctx.filesDir, "logo.png"), true) }; st.set("logo_v", System.currentTimeMillis().toString()); app.say("تم تغيير الشعار") } else app.say("تعذّر قراءة الصورة") } }
    Screen("الإعدادات", onBack = { app.pop() }) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle("هوية المولدة")
            OutlinedButton(onClick = { pickLogo.launch("image/*") }) { Text("تغيير الشعار من المعرض") }
            keys.forEach { (k, label) -> Field(label, draft[k] ?: "", { draft[k] = it }) }
            SectionTitle("الأسعار والاشتراكات")
            Field("سعر الأمبير الموحّد (للأشهر القادمة فقط)", price, { price = it }, number = true)
            Text("تغيير السعر لا يغيّر الفواتير والأشهر المعتمدة سابقاً.", color = t.sub, fontSize = 12.sp)
            OutlinedButton(onClick = { app.push(Route.PriceChange) }) { Text("تغيير سعر الأمبير لأشهر محددة + السجل") }
            Text("الشهر الأول للمشترك الجديد", color = t.text)
            Chips(listOf("FULL" to "كامل", "PRORATED" to "نسبي", "FREE" to "مجاني"), mode) { mode = it }
            SectionTitle("الأمان والرسائل")
            Field("القفل التلقائي بعد خمول (دقائق، 0 = معطّل)", lock, { lock = it }, number = true)
            Field("طرق الدفع (مفصولة بفاصلة)", methods, { methods = it })
            Field("فئات المصاريف (مفصولة بفاصلة)", cats, { cats = it })
            Field("قالب رسالة واتساب ({name} {amount} {amps} {months} {due} {gen})", tpl, { tpl = it }, singleLine = false)
            SectionTitle("المظهر (معاينة مباشرة)")
            Chips(Palettes.map { it.id to it.label }, tp.palette) { tp = tp.copy(palette = it) }
            Row(verticalAlignment = Alignment.CenterVertically) { Switch(tp.dark, { tp = tp.copy(dark = it) }); Spacer(Modifier.width(8.dp)); Text("الوضع الداكن", color = t.text) }
            Text("استدارة البطاقات: ${tp.radius}", color = t.sub); Slider(tp.radius.toFloat(), { tp = tp.copy(radius = it.toInt()) }, valueRange = 4f..30f)
            Text("حجم النصوص: ${String.format(java.util.Locale.US, "%.2f", tp.fontScale)}", color = t.sub); Slider(tp.fontScale, { tp = tp.copy(fontScale = (it * 20).toInt() / 20f) }, valueRange = 0.85f..1.3f)
            Field("لون أساسي مخصص (#RRGGBB، اختياري)", tp.primaryHex, { tp = tp.copy(primaryHex = it) })
            Field("لون التمييز المخصص (#RRGGBB، اختياري)", tp.accentHex, { tp = tp.copy(accentHex = it) })
            BigButton("حفظ الإعدادات", t.primary) {
                val code = (draft["device_code"] ?: "").trim().uppercase()
                if (code.isEmpty() || code.length > 3 || !code.all { it.isLetter() }) { app.say("رمز الجهاز: من 1 إلى 3 أحرف"); return@BigButton }
                val g1 = Fmt.parseMoney(draft["grace_days"] ?: "")?.toInt(); val g2 = Fmt.parseMoney(draft["new_grace_days"] ?: "")?.toInt()
                if (g1 == null || g1 !in 1..28 || g2 == null || g2 !in 1..28) { app.say("أيام فترة التسديد: رقم من 1 إلى 28"); return@BigButton }
                val p = Fmt.parseMoney(price)
                if (p == null || p <= 0) { app.say("سعر الأمبير غير صالح"); return@BigButton }
                scope.launch {
                    keys.forEach { (k, _) -> st.set(k, if (k == "device_code") code else (draft[k] ?: "").trim()) }
                    st.set("amp_price", p.toString()); st.set("first_month_mode", mode); st.set("lock_minutes", (Fmt.parseMoney(lock) ?: 5).toString())
                    st.set("wa_template", tpl); st.set("pay_methods", methods); st.set("expense_categories", cats)
                    st.set("theme_palette", tp.palette); st.set("theme_dark", if (tp.dark) "1" else "0"); st.set("theme_radius", tp.radius.toString())
                    st.set("theme_font", tp.fontScale.toString()); st.set("theme_primary", tp.primaryHex); st.set("theme_accent", tp.accentHex)
                    app.themePreview = null; app.say("تم حفظ الإعدادات")
                }
            }
        }
    }
}

// ───────────── النسخ الاحتياطي ─────────────
@Composable
fun BackupScreenUi() {
    val app = LocalApp.current; val t = LocalTok.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    if (!app.can(Perm.BACKUP)) { Screen("النسخ الاحتياطي") { Empty("لا تملك الصلاحية") }; return }
    val last = app.c.settings.getLong("last_backup", 0)
    var restoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var step by remember { mutableIntStateOf(0) }; var done by remember { mutableStateOf(false) }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch { val ok = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openOutputStream(uri)!!.use { Backup.write(app.c, it) } }.isSuccess }
            if (ok) { app.c.settings.set("last_backup", System.currentTimeMillis().toString()); app.say("تم حفظ النسخة") } else app.say("فشل حفظ النسخة") } }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) { restoreUri = uri; step = 1 } }
    Screen("النسخ الاحتياطي والاستعادة", onBack = { app.pop() }) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Card2(Modifier.fillMaxWidth()) { Info("آخر نسخة", if (last == 0L) "لا توجد" else Fmt.dateTime(last), if (last == 0L || System.currentTimeMillis() - last > 3 * 86_400_000L) t.bad else t.good) }
            BigButton("حفظ نسخة في مكان تختاره (مثل Download)", t.primary, icon = Icons.Filled.CloudUpload) { save.launch("generator-backup-" + Fmt.today() + ".zip") }
            BigButton("مشاركة نسخة (واتساب وغيره)", t.secondary, icon = Icons.Filled.Share) {
                scope.launch { val f = withContext(Dispatchers.IO) { File(ctx.cacheDir, "exports").apply { mkdirs() }.let { File(it, "generator-backup-${Fmt.today()}.zip") }.also { x -> x.outputStream().use { Backup.write(app.c, it) } } }
                    app.c.settings.set("last_backup", System.currentTimeMillis().toString()); Exporter.share(ctx, f, "application/zip") } }
            BigButton("استعادة من ملف", t.bad, icon = Icons.Filled.Download) { open.launch(arrayOf("*/*")) }
            Text("النسخة تلقائية يومياً عند فتح التطبيق (في مجلد التطبيق، آخر 10 نسخ). لنقل البيانات لجهاز آخر: خذ ملف النسخة وافتحه بالاستعادة هناك. الاستعادة تأخذ نسخة أمان من بياناتك الحالية أولاً.", color = t.sub, fontSize = 12.sp)
        }
        if (step == 1) ConfirmDialog("استعادة نسخة", "ستُستبدل كل البيانات الحالية بمحتوى الملف. هل أنت متأكد؟", "متابعة", { step = 0 }) { step = 2 }
        if (step == 2) ConfirmDialog("تأكيد أخير", "تأكيد نهائي: سيُحفظ نسخة أمان من بياناتك الحالية تلقائياً ثم تتم الاستعادة.", "استعادة الآن", { step = 0 }) {
            step = 0; val uri = restoreUri
            if (uri != null) scope.launch {
                val err = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openInputStream(uri)!!.use { Backup.restore(app.c, it) } }.getOrElse { "تعذّر قراءة الملف" } }
                if (err == null) done = true else app.say(err)
            }
        }
        if (done) AlertDialog(onDismissRequest = {}, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text("تمت الاستعادة") },
            text = { Text("سيُغلق التطبيق الآن. افتحه من جديد لترى البيانات المستعادة.") },
            confirmButton = { TextButton(onClick = { exitProcess(0) }) { Text("إغلاق التطبيق", color = t.primary) } })
    }
}

// ───────────── الطابعة الحرارية ─────────────
@Composable
fun PrinterScreenUi() {
    val app = LocalApp.current; val t = LocalTok.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    if (!app.can(Perm.SETTINGS)) { Screen("الطابعة") { Empty("لا تملك الصلاحية") }; return }
    var devs by remember { mutableStateOf(ThermalPrinter.bonded(ctx)) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { devs = ThermalPrinter.bonded(ctx) }
    LaunchedEffect(Unit) { if (Build.VERSION.SDK_INT >= 31 && ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED) perm.launch(Manifest.permission.BLUETOOTH_CONNECT) }
    val width = app.c.settings.get("printer_width", "58")
    Screen("إعدادات الطابعة الحرارية", onBack = { app.pop() }) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("عرض الورق", color = t.text)
            Chips(listOf("58" to "58 mm", "80" to "80 mm"), width) { w -> scope.launch { app.c.settings.set("printer_width", w) } }
            Text("الطابعة المختارة: " + app.c.settings.get("printer_name", "لا شيء"), color = t.text)
            Text("اقترن بالطابعة أولاً من إعدادات بلوتوث الهاتف، ثم اخترها هنا.", color = t.sub, fontSize = 12.sp)
            devs.forEach { d -> Card2(Modifier.fillMaxWidth(), onClick = { scope.launch { app.c.settings.set("printer_address", d.address); app.c.settings.set("printer_name", d.name); app.say("تم اختيار ${d.name}") } }) {
                Text(d.name, color = t.text); Text(d.address, color = t.sub, fontSize = 11.sp) } }
            if (devs.isEmpty()) Empty("لا توجد أجهزة مقترنة")
            BigButton("طباعة صفحة اختبار", t.primary, icon = Icons.Filled.Print) {
                val addr = app.c.settings.get("printer_address")
                if (addr.isBlank()) { app.say("اختر طابعة أولاً"); return@BigButton }
                val px = if (width == "80") 576 else 384
                val sample = ReceiptData("صفحة اختبار الطباعة", "", "", null, "TEST", Fmt.dateTime(System.currentTimeMillis()), "اختبار", "0", 1, "-", 12345, "نقداً", 12345, 0, app.userName(), "هذه صفحة اختبار وليست سنداً", false, null)
                scope.launch { val e = ThermalPrinter.print(ctx, addr, ReceiptRenderer.render(sample, px), px); app.say(e ?: "أُرسلت صفحة الاختبار") }
            }
            Text("الدعم عام (ESC/POS عبر Bluetooth والسند يُطبع كصورة لضمان العربية). لا نضمن التوافق مع موديل محدد قبل تجربته على جهازك.", color = t.sub, fontSize = 12.sp)
        }
    }
}
