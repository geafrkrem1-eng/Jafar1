package com.generator.accounts.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.generator.accounts.core.Fmt
import com.generator.accounts.core.Perm
import com.generator.accounts.data.Kpis
import com.generator.accounts.data.Stats
import java.io.File

@Composable
fun HomeScreen() {
    val app = LocalApp.current; val t = LocalTok.current
    val ym = remember { currentYm() }
    val k by load { Stats.load(app.c.db, ym) }
    val maint by load { Stats.maintenanceDue(app.c.db) }
    val logo = remember(app.c.settings.get("logo_v")) { File(app.c.ctx.filesDir, "logo.png").takeIf { it.exists() }?.let { android.graphics.BitmapFactory.decodeFile(it.path) } }
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(0.3f, 1f, infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "a")
    val spin by rememberInfiniteTransition(label = "s").animateFloat(0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "r")
    val lastBackup = app.c.settings.getLong("last_backup", 0)
    val backupStale = lastBackup == 0L || System.currentTimeMillis() - lastBackup > 3 * 86_400_000L

    Column(Modifier.fillMaxSize().background(t.bg).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(t.dark, t.primary))).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            if (logo != null) Image(logo.asImageBitmap(), null, Modifier.size(44.dp).clip(CircleShape)) else IconBadge(Icons.Filled.Bolt, t.accent, 44)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(app.c.settings.get("gen_name", "نظام إدارة المولدة"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).alpha(pulse).clip(CircleShape).background(t.good)); Spacer(Modifier.width(6.dp))
                    Text("يعمل دون إنترنت  •  ${Fmt.today()}", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                }
            }
            if (app.can(Perm.SETTINGS)) IconButton(onClick = { app.push(Route.Settings) }) {
                Icon(Icons.Filled.Settings, "الإعدادات", tint = t.accent, modifier = Modifier.size(30.dp).rotate(spin))
            }
        }
        val kp = k
        if (kp == null) Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        else Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // البطاقة الرئيسية: تحصيل الشهر
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(t.radius.dp)).background(Brush.linearGradient(listOf(t.dark, t.primary, t.secondary))).padding(18.dp)) {
                Column {
                    Text("تحصيل شهر $ym", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                    Text(Fmt.iqd(kp.collected), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
                    val frac = if (kp.billed > 0) (kp.collected.toFloat() / kp.billed).coerceIn(0f, 1f) else 0f
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { frac }, Modifier.fillMaxWidth().height(8.dp).clip(CircleShape), color = t.accent, trackColor = Color.White.copy(alpha = 0.3f))
                    Spacer(Modifier.height(6.dp))
                    Text("من مستحق الشهر ${Fmt.iqd(kp.billed)}", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Kpi("المشتركون الفعالون", kp.activeSubs.toString(), Icons.Filled.People, t.primary, Modifier.weight(1f))
                Kpi("إجمالي الأمبيرات", kp.totalAmps.toString(), Icons.Filled.Bolt, t.warn, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Kpi("الديون المتراكمة", Fmt.money(kp.outstanding), Icons.Filled.Schedule, t.bad, Modifier.weight(1f))
                Kpi("رصيد الصندوق", Fmt.money(kp.cash), Icons.Filled.AccountBalanceWallet, t.good, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Kpi("مصاريف الشهر", Fmt.money(kp.expenses), Icons.Filled.Payments, t.purple, Modifier.weight(1f))
                Kpi("مصروف الوقود", Fmt.money(kp.fuel), Icons.Filled.LocalGasStation, t.secondary, Modifier.weight(1f))
            }
            Kpi("صافي النتيجة التشغيلية للشهر", Fmt.iqd(kp.collected - kp.expenses), Icons.Filled.BarChart,
                if (kp.collected - kp.expenses >= 0) t.good else t.bad, Modifier.fillMaxWidth())

            // اختصارات سريعة
            SectionTitle("اختصارات سريعة")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                if (app.can(Perm.COLLECT)) Shortcut("قبض", Icons.Filled.Payments, t.good, Modifier.weight(1f)) { app.push(Route.Collect()) }
                if (app.can(Perm.SUB_ADD)) Shortcut("مشترك", Icons.Filled.PersonAdd, t.primary, Modifier.weight(1f)) { app.push(Route.SubForm(null)) }
                if (app.can(Perm.EXPENSES)) Shortcut("مصروف", Icons.Filled.LocalGasStation, t.warn, Modifier.weight(1f)) { app.push(Route.Expenses) }
                if (app.can(Perm.REPORTS)) Shortcut("تقارير", Icons.Filled.BarChart, t.purple, Modifier.weight(1f)) { app.push(Route.Reports) }
            }

            SectionTitle("التحصيل والمصروفات (آخر 6 أشهر)")
            Card2(Modifier.fillMaxWidth()) {
                GroupedBars(kp.monthly.map { it.first.takeLast(2) to listOf(it.second, it.third) }, listOf(t.good, t.bad))
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Legend("المحصّل", t.good); Legend("المصروفات", t.bad)
                }
            }
            if (kp.expenseByCat.isNotEmpty()) {
                SectionTitle("المصاريف حسب الفئة")
                Card2(Modifier.fillMaxWidth()) {
                    val mx = kp.expenseByCat.maxOf { it.second }.coerceAtLeast(1)
                    kp.expenseByCat.forEach { (cat, v) ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
                            Text(cat, color = t.text, fontSize = 12.sp, modifier = Modifier.width(80.dp), maxLines = 1)
                            Box(Modifier.weight(1f).height(10.dp).clip(CircleShape).background(t.altRow)) {
                                Box(Modifier.fillMaxWidth(v.toFloat() / mx).fillMaxHeight().clip(CircleShape).background(Brush.horizontalGradient(listOf(t.primary, t.secondary))))
                            }
                            Text(Fmt.money(v), color = t.sub, fontSize = 11.sp, modifier = Modifier.padding(start = 6.dp))
                        }
                    }
                }
            }

            SectionTitle("التنبيهات")
            var any = false
            if (kp.outstanding > 0 && app.can(Perm.DEBTS)) { any = true; Alert(Icons.Filled.Warning, t.bad, "ديون متراكمة بقيمة ${Fmt.iqd(kp.outstanding)}") { app.root(Route.Debts) } }
            maint?.forEach { (d, day) -> any = true; Alert(Icons.Filled.Build, t.warn, "صيانة: $d — الموعد ${Fmt.date(day)}") { if (app.can(Perm.MAINT)) app.push(Route.Expenses) } }
            if (backupStale) { any = true; Alert(Icons.Filled.CloudUpload, t.warn, if (lastBackup == 0L) "لا توجد نسخة احتياطية بعد" else "مرّت أكثر من 3 أيام على آخر نسخة احتياطية") { if (app.can(Perm.BACKUP)) app.push(Route.BackupScreen) } }
            if (!any) Text("لا توجد تنبيهات", color = t.sub)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable private fun Legend(text: String, c: Color) { Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(10.dp).clip(CircleShape).background(c)); Spacer(Modifier.width(6.dp)); Text(text, fontSize = 12.sp, color = LocalTok.current.sub) } }

@Composable private fun Shortcut(label: String, icon: ImageVector, c: Color, m: Modifier, onClick: () -> Unit) {
    Card2(m, onClick = onClick) { Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        IconBadge(icon, c, 42); Spacer(Modifier.height(6.dp)); Text(label, fontSize = 12.sp, color = LocalTok.current.text) } }
}

@Composable private fun Alert(icon: ImageVector, c: Color, text: String, onClick: () -> Unit) {
    Card2(Modifier.fillMaxWidth(), onClick = onClick) { Row(verticalAlignment = Alignment.CenterVertically) {
        IconBadge(icon, c, 34); Spacer(Modifier.width(10.dp)); Text(text, color = LocalTok.current.text, fontSize = 13.sp) } }
}

/** رسم أعمدة مجمّعة بسيط (بلا مكتبات). */
@Composable
fun GroupedBars(groups: List<Pair<String, List<Long>>>, colors: List<Color>) {
    val t = LocalTok.current
    val mx = (groups.maxOfOrNull { g -> g.second.maxOrNull() ?: 0L } ?: 0L).coerceAtLeast(1L)
    Canvas(Modifier.fillMaxWidth().height(130.dp)) {
        val gw = size.width / groups.size
        groups.forEachIndexed { gi, g ->
            val bw = gw / (g.second.size + 1.5f)
            g.second.forEachIndexed { bi, v ->
                val h = (size.height - 8f) * (v.toFloat() / mx)
                drawRoundRect(colors[bi], Offset(gi * gw + bw * (bi + 0.5f) + gw * 0.05f, size.height - h), Size(bw, h.coerceAtLeast(2f)), CornerRadius(6f, 6f))
            }
        }
    }
    Row(Modifier.fillMaxWidth()) { groups.forEach { Text(it.first, Modifier.weight(1f), fontSize = 11.sp, color = t.sub, textAlign = androidx.compose.ui.text.style.TextAlign.Center) } }
}
