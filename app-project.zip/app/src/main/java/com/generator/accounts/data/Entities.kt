package com.generator.accounts.data

import androidx.room.ColumnInfo
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** حقول موحّدة لكل سجل (جاهزة للمزامنة مستقبلاً). الحذف منطقي فقط. */
data class Meta(
    val createdAt: Long, val updatedAt: Long,
    val createdBy: String, val updatedBy: String,
    val createdDeviceId: String, val updatedDeviceId: String,
    val isDeleted: Boolean = false
)

@Entity(tableName = "subscribers", indices = [Index("code", unique = true), Index("fullName"), Index("phone")])
data class Subscriber(
    @PrimaryKey val id: String, val code: String, val fullName: String, val phone: String,
    val address: String, val landmark: String, val amps: Int,
    val ampPriceIqd: Long, val monthlyFeeIqd: Long,      // لقطة للعرض (آخر سعر/اشتراك مُنشأ)
    val exceptionPriceIqd: Long,                          // 0 = يتبع السعر الموحّد، >0 = استثناء موثّق
    val startEpochDay: Long, val billingDay: Int,         // 1..31
    val status: String,                                   // ACTIVE / PAUSED / CANCELLED
    val notes: String, val photoPath: String?,
    val boardId: String?,                                 // البورد (مجموعة المشتركين) أو null
    @Embedded val meta: Meta
)

@Entity(tableName = "months", indices = [Index("ym", unique = true)])
data class MonthRecord(
    @PrimaryKey val id: String, val ym: String, val ampPriceIqd: Long,
    val status: String,                                   // OPEN / CLOSED
    val closedAt: Long?, @Embedded val meta: Meta
)

@Entity(tableName = "invoices", indices = [Index(value = ["subscriberId", "periodYm"], unique = true), Index("dueEpochDay"), Index("periodYm")])
data class Invoice(
    @PrimaryKey val id: String, val subscriberId: String,
    val periodYm: String, val amps: Int, val ampPriceIqd: Long,   // السعر مثبّت تاريخياً
    val baseAmount: Long, val adjustmentAmount: Long, val adjustmentReason: String?,
    val dueEpochDay: Long, val firstMonthNote: String?,
    // حقول الدورة والاشتراك المسبق (الإصدار 2)
    @ColumnInfo(defaultValue = "0") val cycleStartEpochDay: Long,
    @ColumnInfo(defaultValue = "0") val cycleEndEpochDay: Long,       // حصرية
    @ColumnInfo(defaultValue = "0") val cycleDays: Int,
    @ColumnInfo(defaultValue = "0") val daysCharged: Int,
    @ColumnInfo(defaultValue = "0") val fullAmount: Long,
    @ColumnInfo(defaultValue = "0") val activationEpochDay: Long,
    @ColumnInfo(defaultValue = "0") val graceEndEpochDay: Long,       // آخر يوم لفترة التسديد
    @ColumnInfo(defaultValue = "0") val isProrated: Boolean,
    @Embedded val meta: Meta
)

@Entity(tableName = "boards")
data class Board(
    @PrimaryKey val id: String, val name: String, val sortOrder: Int, @Embedded val meta: Meta
)

@Entity(tableName = "receipts", indices = [
    Index(value = ["deviceCode", "year", "seq"], unique = true),
    Index(value = ["idempotencyKey"], unique = true), Index("subscriberId"), Index("paidAtMillis")])
data class Receipt(
    @PrimaryKey val id: String, val serialNo: String,
    val deviceCode: String, val year: Int, val seq: Int,
    val subscriberId: String, val amountIqd: Long, val paidAtMillis: Long,
    val method: String, val note: String?, val idempotencyKey: String,
    val balanceBeforeIqd: Long, val balanceAfterIqd: Long,
    val status: String,                                   // ACTIVE / CANCELLED
    val cancelReason: String?, val cancelledAt: Long?, val cancelledBy: String?,
    val printStatus: String,                              // NOT_PRINTED / SENT_TO_PRINTER
    @Embedded val meta: Meta
)

/** المبلغ سالب في قيد الإلغاء العكسي، فيُحسب الرصيد بالجمع دون أرقام منفصلة. */
@Entity(tableName = "receipt_allocations", indices = [Index("invoiceId"), Index("receiptId")])
data class ReceiptAllocation(
    @PrimaryKey val id: String, val receiptId: String, val invoiceId: String,
    val amountIqd: Long, val isReversal: Boolean, @Embedded val meta: Meta
)

@Entity(tableName = "cash_entries", indices = [
    Index(value = ["sourceType", "sourceId", "isReversal"], unique = true), Index("occurredAt")])
data class CashEntry(
    @PrimaryKey val id: String, val kind: String,         // IN / OUT
    val amountIqd: Long, val category: String,
    val sourceType: String, val sourceId: String,
    val isReversal: Boolean, val occurredAt: Long, val description: String,
    @Embedded val meta: Meta
)

@Entity(tableName = "expenses", indices = [Index("kind"), Index("epochDay")])
data class Expense(
    @PrimaryKey val id: String, val kind: String,         // GENERAL / FUEL / MAINTENANCE
    val category: String, val amountIqd: Long, val epochDay: Long,
    val payee: String, val method: String, val description: String, val notes: String,
    val imagePath: String?,
    val fuelType: String?, val litersMilli: Long, val pricePerLiterIqd: Long,
    val supplier: String?, val voucherNo: String?,
    val nextDueEpochDay: Long?, val technician: String?,
    val status: String, val voidReason: String?,          // ACTIVE / VOID
    @Embedded val meta: Meta
)

@Entity(tableName = "workers")
data class Worker(
    @PrimaryKey val id: String, val name: String, val phone: String, val address: String,
    val job: String, val startEpochDay: Long,
    val payType: String,                                  // MONTHLY / DAILY / HOURLY
    val rateIqd: Long, val status: String, val notes: String,
    @Embedded val meta: Meta
)

@Entity(tableName = "advances", indices = [Index("workerId")])
data class Advance(
    @PrimaryKey val id: String, val workerId: String, val amountIqd: Long,
    val epochDay: Long, val note: String, @Embedded val meta: Meta
)

@Entity(tableName = "payroll_slips", indices = [Index(value = ["workerId", "periodYm"], unique = true)])
data class PayrollSlip(
    @PrimaryKey val id: String, val workerId: String, val periodYm: String,
    val units: Long, val basicIqd: Long, val bonusIqd: Long, val deductionsIqd: Long,
    val advanceDeductionIqd: Long, val netIqd: Long,
    val status: String,                                   // DRAFT / APPROVED / PAID / VOID
    val paidAt: Long?, val voidReason: String?, @Embedded val meta: Meta
)

@Entity(tableName = "cash_closings")
data class CashClosing(
    @PrimaryKey val id: String, val closedAt: Long, val systemBalanceIqd: Long,
    val actualBalanceIqd: Long, val differenceIqd: Long, val reason: String?,
    val userId: String, @Embedded val meta: Meta
)

@Entity(tableName = "reminder_logs", indices = [Index("subscriberId")])
data class ReminderLog(
    @PrimaryKey val id: String, val subscriberId: String, val openedAt: Long,
    val message: String, val userId: String
)

@Entity(tableName = "audit_log", indices = [Index("entityId"), Index("at")])
data class AuditLog(
    @PrimaryKey val id: String, val entityType: String, val entityId: String, val action: String,
    val beforeJson: String?, val afterJson: String?, val reason: String?,
    val userId: String, val deviceId: String, val at: Long
)

@Entity(tableName = "app_users")
data class AppUser(
    @PrimaryKey val id: String, val name: String, val role: String,
    val pinHash: String, val pinSalt: String, val permissionsCsv: String, val active: Boolean,
    @Embedded val meta: Meta
)

@Entity(tableName = "app_settings")
data class AppSetting(@PrimaryKey val key: String, val value: String)
