package com.generator.accounts.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.generator.accounts.core.Fmt
import com.generator.accounts.data.*
import com.generator.accounts.output.Exporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** جدول عام مبني على ReportSpec: تحميل تدريجي، فرز بالعنوان، إجمالي، وتصدير PDF/CSV بالترتيب نفسه. */
@Composable
fun SpecTable(
    spec: ReportSpec, widths: List<Int>, modifier: Modifier, exportName: String, key: Any? = null,
    onRowClick: ((TableRow) -> Unit)? = null, colorFor: (Int, TableRow) -> Color? = { _, _ -> null }
) {
    val app = LocalApp.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var limit by remember(key) { mutableIntStateOf(100) }
    var sortCol by remember(key) { mutableIntStateOf(-1) }
    var desc by remember(key) { mutableStateOf(false) }
    val data by load(key, limit) { runCatching { ReportEngine.run(app.c.db, spec, limit, 0, true) }.getOrElse { TableData(spec.headers, emptyList(), null, false) } }
    val d = data
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (d == null) Text("جاري التحميل...") else {
            val rows = if (sortCol < 0) d.rows else d.rows.sortedWith { a, b ->
                val x = a.cells.getOrElse(sortCol) { "" }; val y = b.cells.getOrElse(sortCol) { "" }
                val nx = x.replace(",", "").toDoubleOrNull(); val ny = y.replace(",", "").toDoubleOrNull()
                val c = if (nx != null && ny != null) nx.compareTo(ny) else x.compareTo(y)
                if (desc) -c else c
            }
            DataTable(d.headers, rows, d.totals, widths, Modifier.weight(1f), sortCol, desc,
                onSort = { c -> if (c == sortCol) desc = !desc else { sortCol = c; desc = false } },
                onRowClick = onRowClick, colorFor = colorFor, hasMore = d.hasMore, onLoadMore = { limit += 100 })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { scope.launch {
                    val full = withContext(Dispatchers.IO) { ReportEngine.run(app.c.db, spec, 200_000, 0, true) }
                    Exporter.share(ctx, Exporter.csv(ctx, exportName, full.headers, full.rows, full.totals), "text/csv") } }) { Text("تصدير CSV") }
                OutlinedButton(onClick = { scope.launch {
                    val full = withContext(Dispatchers.IO) { ReportEngine.run(app.c.db, spec, 200_000, 0, true) }
                    Exporter.share(ctx, Exporter.pdfTable(ctx, exportName, spec.title, app.c.settings.get("gen_name") + " - " + Exporter.stamp(), full.headers, full.rows, full.totals), "application/pdf") } }) { Text("تصدير PDF") }
            }
        }
    }
}
