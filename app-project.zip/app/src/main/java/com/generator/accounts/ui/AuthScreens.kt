package com.generator.accounts.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.generator.accounts.core.Perm
import com.generator.accounts.core.PinHasher
import com.generator.accounts.data.AppUser
import com.generator.accounts.finance.FinResult
import kotlinx.coroutines.launch
import java.util.Base64

@Composable
fun SetupScreen(onDone: (AppUser) -> Unit) {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope()
    var gen by remember { mutableStateOf("") }; var owner by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }; var pin2 by remember { mutableStateOf("") }
    Screen("الإعداد الأول") {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { IconBadge(Icons.Filled.Bolt, t.accent, 52); Spacer(Modifier.width(12.dp))
                Text("أهلاً بك. أنشئ حساب المدير لبدء العمل.", color = t.text, fontSize = 16.sp) }
            Field("اسم المولدة", gen, { gen = it })
            Field("اسم المدير", owner, { owner = it })
            Field("رمز PIN (4 إلى 8 أرقام)", pin, { pin = it }, password = true)
            Field("تأكيد الرمز", pin2, { pin2 = it }, password = true)
            Text("احفظ الرمز جيداً. لا يمكن استرجاعه، ويمكن للمدير إعادة تعيينه لغيره فقط.", color = t.sub, fontSize = 12.sp)
            BigButton("إنشاء وبدء", t.primary, enabled = gen.isNotBlank() && owner.isNotBlank() && pin.isNotEmpty()) {
                if (pin != pin2) { app.say("الرمزان غير متطابقين"); return@BigButton }
                scope.launch {
                    app.c.settings.set("gen_name", gen.trim()); app.c.settings.set("gen_owner", owner.trim())
                    when (val r = app.c.repo.createUser(owner, "ADMIN", pin, Perm.all, "setup")) {
                        is FinResult.Err -> app.say(r.message)
                        is FinResult.Ok -> app.c.db.users().get(r.value)?.let(onDone)
                    }
                }
            }
        }
    }
}

@Composable
fun LoginScreen(onLogin: (AppUser) -> Unit) {
    val app = LocalApp.current; val t = LocalTok.current
    val users by load { app.c.db.users().all().filter { it.active } }
    var sel by remember { mutableStateOf<String?>(null) }
    var pin by remember { mutableStateOf("") }
    var fails by remember { mutableIntStateOf(0) }
    var lockedUntil by remember { mutableLongStateOf(0L) }
    val list = users ?: emptyList()
    val cur = list.firstOrNull { it.id == sel } ?: list.firstOrNull()
    Screen(app.c.settings.get("gen_name", "نظام إدارة المولدة")) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("اختر المستخدم وأدخل الرمز", color = t.text, fontSize = 16.sp)
            Chips(list.map { it.id to it.name }, cur?.id ?: "", { sel = it; pin = "" })
            Field("PIN", pin, { pin = it }, password = true)
            BigButton("دخول", t.primary, enabled = cur != null && pin.isNotEmpty()) {
                val u = cur ?: return@BigButton
                if (System.currentTimeMillis() < lockedUntil) { app.say("محاولات كثيرة. انتظر قليلاً"); return@BigButton }
                val ok = PinHasher.verify(pin.toCharArray(), Base64.getDecoder().decode(u.pinSalt), u.pinHash)
                if (ok) { fails = 0; pin = ""; onLogin(u) } else {
                    fails++; pin = ""
                    if (fails >= 5) { lockedUntil = System.currentTimeMillis() + 30_000; fails = 0; app.say("تم القفل 30 ثانية") } else app.say("الرمز غير صحيح")
                }
            }
        }
    }
}
