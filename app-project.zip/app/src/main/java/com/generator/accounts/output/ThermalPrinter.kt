package com.generator.accounts.output

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.UUID

/**
 * طباعة ESC/POS عامة عبر Bluetooth (SPP). السند يُرسل كصورة نقطية (GS v 0).
 * لا نضمن التوافق مع موديل محدد قبل تجربته. «نجاح» الإرسال لا يعني بالضرورة خروج الورق فعلاً.
 */
object ThermalPrinter {
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    data class Dev(val name: String, val address: String)

    @SuppressLint("MissingPermission")
    fun bonded(ctx: Context): List<Dev> = try {
        val ad: BluetoothAdapter? = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        ad?.bondedDevices?.map { Dev(it.name ?: it.address, it.address) } ?: emptyList()
    } catch (e: SecurityException) { emptyList() }

    fun toEscPos(src: Bitmap, widthPx: Int, density: Int = 1): ByteArray {
        val bmp = if (src.width != widthPx) Bitmap.createScaledBitmap(src, widthPx, src.height * widthPx / src.width, true) else src
        val bytesPerRow = (widthPx + 7) / 8
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x1B, 0x40))                                  // ESC @ تهيئة
        var y = 0
        while (y < bmp.height) {
            val rows = minOf(200, bmp.height - y)
            out.write(byteArrayOf(0x1D, 0x76, 0x30, 0x00, (bytesPerRow and 0xFF).toByte(), (bytesPerRow shr 8).toByte(), (rows and 0xFF).toByte(), (rows shr 8).toByte()))
            for (r in 0 until rows) for (bx in 0 until bytesPerRow) {
                var b = 0
                for (bit in 0 until 8) {
                    val x = bx * 8 + bit
                    if (x < widthPx) {
                        val px = bmp.getPixel(x, y + r)
                        val lum = (Color.red(px) * 299 + Color.green(px) * 587 + Color.blue(px) * 114) / 1000
                        if (lum < 140) b = b or (0x80 shr bit)
                    }
                }
                out.write(b)
            }
            y += rows
        }
        out.write(byteArrayOf(0x0A, 0x0A, 0x0A, 0x1D, 0x56, 0x42, 0x00))    // تغذية + قص جزئي (يتجاهله ما لا يدعمه)
        return out.toByteArray()
    }

    /** يعيد null عند الإرسال بنجاح، أو رسالة خطأ واضحة. */
    @SuppressLint("MissingPermission")
    suspend fun print(ctx: Context, address: String, bmp: Bitmap, widthPx: Int): String? = withContext(Dispatchers.IO) {
        try {
            val ad = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                ?: return@withContext "البلوتوث غير متوفر في هذا الجهاز"
            if (!ad.isEnabled) return@withContext "البلوتوث مغلق. شغّله ثم أعد المحاولة"
            val dev = ad.getRemoteDevice(address)
            ad.cancelDiscovery()
            val sock = dev.createRfcommSocketToServiceRecord(SPP)
            sock.connect()
            try { sock.outputStream.apply { write(toEscPos(bmp, widthPx)); flush() }; Thread.sleep(600) } finally { sock.close() }
            null
        } catch (e: SecurityException) { "لا توجد صلاحية البلوتوث. اسمح بها من إعدادات التطبيق"
        } catch (e: Exception) { "تعذّر الاتصال بالطابعة أو الإرسال: ${e.message}" }
    }
}
