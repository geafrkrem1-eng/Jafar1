package com.generator.accounts

import android.app.Application
import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import com.generator.accounts.data.*
import com.generator.accounts.finance.FinanceRepository
import java.util.UUID

class SettingsStore(private val dao: SettingDao) {
    val map = mutableStateMapOf<String, String>()    // مراقَب من Compose
    suspend fun load() { dao.all().forEach { map[it.key] = it.value } }
    fun get(k: String, def: String = ""): String = map[k] ?: def
    fun getLong(k: String, def: Long = 0): Long = map[k]?.toLongOrNull() ?: def
    suspend fun set(k: String, v: String) { dao.put(AppSetting(k, v)); map[k] = v }
}

class Container(val ctx: Context) {
    val db: AppDatabase = AppDatabase.build(ctx)
    val settings = SettingsStore(db.settings())
    val repo = FinanceRepository(db, { settings.get("device_id", "unknown") }, { settings.get("device_code", "A") },
        policyProvider = { com.generator.accounts.finance.Policy(settings.getLong("grace_days", 5).toInt().coerceIn(1, 31), settings.getLong("new_grace_days", 1).toInt().coerceIn(1, 31)) })

    suspend fun init() {
        settings.load()
        if (settings.get("device_id").isEmpty()) settings.set("device_id", UUID.randomUUID().toString())
        if (settings.get("device_code").isEmpty()) settings.set("device_code", "A")
        if (settings.get("expense_categories").isEmpty())
            settings.set("expense_categories", "وقود,زيت محرك,فلاتر,صيانة,قطع غيار,أجور عمال,أجور نقل,كهرباء وخدمات,إيجار,طارئة,أخرى")
        if (settings.get("pay_methods").isEmpty()) settings.set("pay_methods", "نقداً,تحويل")
        if (settings.get("first_month_mode").isEmpty()) settings.set("first_month_mode", "FULL")
        if (settings.get("grace_days").isEmpty()) settings.set("grace_days", "5")
        if (settings.get("new_grace_days").isEmpty()) settings.set("new_grace_days", "1")
        // التحديث 2: الاشتراك النسبي للمشترك الجديد هو الافتراضي (يبقى كامل/مجاني متاحين من الإعدادات)
        if (settings.get("proration_v2").isEmpty()) { settings.set("first_month_mode", "PRORATED"); settings.set("proration_v2", "1") }
        if (settings.get("amp_price").isEmpty()) settings.set("amp_price", "10000")
        if (settings.get("lock_minutes").isEmpty()) settings.set("lock_minutes", "5")
        if (settings.get("receipt_footer").isEmpty()) settings.set("receipt_footer", "شكراً لتعاملكم معنا")
        if (settings.get("wa_template").isEmpty()) settings.set("wa_template",
            "السلام عليكم {name}\nنذكّركم بوجود مبلغ مستحق قدره {amount} دينار عن {amps} أمبير للأشهر: {months}.\nتاريخ الاستحقاق: {due}.\nمع الشكر، {gen}")
    }
}

class App : Application() {
    lateinit var container: Container
    override fun onCreate() { super.onCreate(); container = Container(applicationContext) }
}
