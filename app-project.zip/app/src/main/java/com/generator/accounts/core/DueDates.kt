package com.generator.accounts.core

import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit

/**
 * حساب تاريخ الاستحقاق حسب يوم بدء كل مشترك (القسم 6-ب).
 * إن كان اليوم غير موجود في الشهر (31 في شهر 30 يوماً، 29/30/31 في شباط) يُعتمد آخر يوم في الشهر.
 */
object DueDates {
    fun dueDate(month: YearMonth, billingDay: Int): LocalDate {
        require(billingDay in 1..31) { "billingDay must be 1..31" }
        return month.atDay(minOf(billingDay, month.lengthOfMonth()))
    }

    /** نهاية دورة الاشتراك = اليوم السابق لاستحقاق الشهر التالي. */
    fun cycleEnd(month: YearMonth, billingDay: Int): LocalDate =
        dueDate(month.plusMonths(1), billingDay).minusDays(1)

    /** أيام التأخير: صفر قبل الاستحقاق أو يوم الاستحقاق نفسه. */
    fun daysOverdue(due: LocalDate, today: LocalDate): Long =
        maxOf(0L, ChronoUnit.DAYS.between(due, today))
}
