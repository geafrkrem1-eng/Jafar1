package com.generator.accounts.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.generator.accounts.core.*
import com.generator.accounts.data.*
import com.generator.accounts.finance.FinResult
import com.generator.accounts.finance.SubscriberInput
import com.generator.accounts.output.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URLEncoder
import java.time.LocalDate
import java.util.UUID

private val SUB_HEADERS = listOf("الاسم", "م", "رمز الاشتراك", "الهاتف", "الأمبيرات", "الاشتراك الشهري", "البورد", "الدين السابق", "المسدد", "المتبقي", "الحالة")
private val SUB_WIDTHS = listOf(150, 44, 80, 110, 80, 110, 100, 100, 100, 100, 80)
private fun statusAr(s: String) = when (s) { "ACTIVE" -> "فعال"; "PAUSED" -> "متوقف مؤقتاً"; else -> "ملغى" }

@Composable
private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    val t = LocalTok.current
    var v by remember { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text(title) },
        text = { Field("اسم البورد", v, { v = it }) },
        confirmButton = { TextButton(enabled = v.isNotBlank(), onClick = { onOk(v.trim()) }) { Text("حفظ", color = t.primary) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("تراجع", color = t.sub) } })
}

@Composable
private fun MoveDialog(boards: List<Board>, count: Long, onDismiss: () -> Unit, onOk: (String?) -> Unit) {
    val t = LocalTok.current
    var target by remember { mutableStateOf("-") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text("نقل $count مشترك") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("إلى أي بورد؟ (لا تتأثر حساباتهم ولا ديونهم)", fontSize = 13.sp, color = t.sub)
            Chips(listOf("-" to "بدون بورد") + boards.map { it.id to it.name }, target) { target = it } } },
        confirmButton = { TextButton(enabled = count > 0, onClick = { onOk(if (target == "-") null else target) }) { Text("نقل", color = t.primary) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("تراجع", color = t.sub) } })
}

@Composable
fun SubscribersScreen() {
    val app = LocalApp.current; val t = LocalTok.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var onlyDebt by remember { mutableStateOf(false) }
    var sort by remember { mutableIntStateOf(0) }
    var desc by remember { mutableStateOf(false) }
    var limit by remember { mutableIntStateOf(50) }
    var dlg by remember { mutableStateOf("") }
    val board = app.boardFilter
    val ym = remember { currentYm() }
    val pageSize = 50
    val boards by load { app.c.db.boards().all() }
    val counts by load { app.c.db.subscribers().boardCounts() }
    // البحث والفرز والتصفية والبورد من قاعدة البيانات مع تحميل تدريجي
    val rowsS = load(q, status, board, sort, desc, limit) {
        app.c.db.subscribers().rows(ym, q.trim(), status, board, sort, if (desc) 1 else 0, limit + 1, 0)
    }
    val totS = load(q, status, board) { app.c.db.subscribers().totals(ym, q.trim(), status, board) }
    val bl = boards ?: emptyList()
    val bmap = bl.associate { it.id to it.name }
    val all = rowsS.value ?: emptyList()
    val shown = (if (all.size > limit) all.take(limit) else all).filter { !onlyDebt || it.remaining > 0 }
    val hasMore = all.size > limit
    fun toRow(r: SubscriberRow, i: Int) = TableRow(r.id, listOf(r.fullName, (i + 1).toString(), r.code, r.phone, r.amps.toString(),
        Fmt.money(r.monthlyFeeIqd), bmap[r.boardId] ?: "-", Fmt.money(r.prevDebt), Fmt.money(r.paidThisMonth), Fmt.money(r.remaining), statusAr(r.status)))
    val rows = shown.mapIndexed { i, r -> toRow(r, i) }
    val tot = totS.value
    val totals = tot?.let { listOf("الإجمالي (${it.cnt})", "", "", "", it.amps.toString(), Fmt.money(it.fee), "", Fmt.money(it.prev), Fmt.money(it.paid), Fmt.money(it.remaining), "") }
    // أعمدة الفرز في SQL: 0 اسم، 1 رمز، 2 أمبير، 3 اشتراك، 5 دين سابق، 6 مسدد، 7 متبقي، 8 حالة
    val sortMap = mapOf(0 to 0, 2 to 1, 4 to 2, 5 to 3, 7 to 5, 8 to 6, 9 to 7, 10 to 8)
    val cnt = counts ?: emptyList()
    val opts = buildList {
        add("" to "الكل (${cnt.sumOf { it.cnt }})")
        bl.forEach { b -> add(b.id to "${b.name} (${cnt.firstOrNull { it.boardId == b.id }?.cnt ?: 0})") }
        add("-" to "بدون بورد (${cnt.firstOrNull { it.boardId == null }?.cnt ?: 0})")
    }
    val canEdit = app.can(Perm.SUB_EDIT)

    Screen("المشتركون", actions = {
        if (app.can(Perm.SUB_ADD)) IconButton(onClick = { app.push(Route.SubForm(null)) }) { Icon(Icons.Filled.PersonAdd, "إضافة", tint = Color.White) }
        IconButton(onClick = { Exporter.share(ctx, Exporter.csv(ctx, "subscribers", SUB_HEADERS, rows, totals), "text/csv") }) { Icon(Icons.Filled.Share, "CSV", tint = Color.White) }
        IconButton(onClick = { Exporter.share(ctx, Exporter.pdfTable(ctx, "subscribers", "المشتركون", app.c.settings.get("gen_name") + " - " + Exporter.stamp(), SUB_HEADERS, rows, totals), "application/pdf") }) { Icon(Icons.Filled.Print, "PDF", tint = Color.White) }
    }) {
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Chips(opts, board) { app.boardFilter = it; limit = pageSize }
            if (canEdit) Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { dlg = "new" }) { Text("+ بورد") }
                if (board.length > 1) { TextButton(onClick = { dlg = "rename" }) { Text("تعديل الاسم") }; TextButton(onClick = { dlg = "delete" }) { Text("حذف", color = t.bad) } }
                TextButton(onClick = { dlg = "move" }) { Text("نقل القائمة") }
            }
            tot?.let { Text("${it.cnt} مشترك • ${it.amps} أمبير • اشتراكات ${Fmt.money(it.fee)} • ديون ${Fmt.money(it.remaining)}", color = t.sub, fontSize = 12.sp) }
            Field("بحث بالاسم أو الهاتف أو الرمز (ضمن البورد المحدد)", q, { q = it; limit = pageSize })
            Chips(listOf("" to "الكل", "ACTIVE" to "فعال", "PAUSED" to "متوقف", "CANCELLED" to "ملغى"), status) { status = it; limit = pageSize }
            Chips(listOf("0" to "الجميع", "1" to "من عليه متبقي"), if (onlyDebt) "1" else "0") { onlyDebt = it == "1" }
            DataTable(SUB_HEADERS, rows, totals, SUB_WIDTHS, Modifier.weight(1f), sortCol = sortMap.entries.firstOrNull { it.value == sort }?.key ?: 0, sortDesc = desc,
                onSort = { col -> val s = sortMap[col]; if (s != null) { if (s == sort) desc = !desc else { sort = s; desc = false }; limit = pageSize } },
                onRowClick = { r -> r.id?.let { app.push(Route.SubDetail(it)) } },
                colorFor = { i, r -> when (i) {
                    9 -> if ((Fmt.parseMoney(r.cells[9]) ?: 0) > 0) t.bad else t.good
                    10 -> when (r.cells[10]) { "فعال" -> t.good; "متوقف مؤقتاً" -> t.warn; else -> t.bad }
                    else -> null } },
                hasMore = hasMore, onLoadMore = { limit += pageSize })
        }
        if (dlg == "new") NameDialog("بورد جديد", "", { dlg = "" }) { n -> scope.launch { app.handle(app.c.repo.createBoard(n, app.uid()), "تم إنشاء البورد") }; dlg = "" }
        if (dlg == "rename") NameDialog("تعديل اسم البورد", bmap[board] ?: "", { dlg = "" }) { n -> scope.launch { app.handle(app.c.repo.renameBoard(board, n, app.uid()), "تم تعديل الاسم") }; dlg = "" }
        if (dlg == "delete") ConfirmDialog("حذف البورد «${bmap[board] ?: ""}»", "سيُنقل مشتركوه إلى «بدون بورد» دون أي مساس بحساباتهم أو ديونهم.", "حذف", { dlg = "" }) {
            val b = board; dlg = ""
            scope.launch { app.handle(app.c.repo.deleteBoard(b, app.uid()), "تم حذف البورد") { app.boardFilter = "" } } }
        if (dlg == "move") MoveDialog(bl, tot?.cnt?.toLong() ?: 0L, { dlg = "" }) { target ->
            dlg = ""
            scope.launch {
                val ids = withContext(Dispatchers.IO) { app.c.db.subscribers().idsFor(ym, q.trim(), status, board) }
                app.handle(app.c.repo.moveSubscribers(ids, target, app.uid()), "تم نقل ${ids.size} مشترك")
            }
        }
    }
}

@Composable
fun SubFormScreen(id: String?) {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope(); val ctx = LocalContext.current
    val existing by load(id) { id?.let { app.c.db.subscribers().get(it) } }
    val boards by load { app.c.db.boards().all() }
    var loaded by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }; var landmark by remember { mutableStateOf("") }
    var amps by remember { mutableStateOf("") }; var notes by remember { mutableStateOf("") }
    var startDate by remember { mutableStateOf(Fmt.today().toString()) }
    var boardSel by remember { mutableStateOf(if (id == null && app.boardFilter.length > 1) app.boardFilter else "-") }
    var photo by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(existing) {
        val s = existing
        if (s != null && !loaded) { loaded = true; name = s.fullName; phone = s.phone; address = s.address; landmark = s.landmark
            amps = s.amps.toString(); notes = s.notes; startDate = Fmt.date(s.startEpochDay); photo = s.photoPath; boardSel = s.boardId ?: "-" }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) photo = ImageUtil.save(ctx, uri, "sub-" + UUID.randomUUID() + ".jpg")
    }
    Screen(if (id == null) "مشترك جديد" else "تعديل مشترك", onBack = { app.pop() }) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Field("الاسم الكامل", name, { name = it })
            Field("الهاتف", phone, { phone = it }, phone = true)
            Field("العنوان", address, { address = it })
            Field("أقرب نقطة دالة", landmark, { landmark = it })
            Field("عدد الأمبيرات", amps, { amps = it }, number = true)
            if (id == null) {
                Field("تاريخ تفعيل الاشتراك (yyyy-MM-dd)", startDate, { startDate = Fmt.normDigits(it) })
                Text("إن فُعّل داخل الشهر يُحسب اشتراكه نسبياً للأيام المتبقية (يوم التفعيل محسوب) ويصير كاملاً من الدورة التالية.", color = t.sub, fontSize = 12.sp)
            }
            Text("البورد", color = t.sub, fontSize = 12.sp)
            Chips(listOf("-" to "بدون بورد") + (boards ?: emptyList()).map { it.id to it.name }, boardSel) { boardSel = it }
            Field("ملاحظات", notes, { notes = it }, singleLine = false)
            OutlinedButton(onClick = { pick.launch("image/*") }) { Text(if (photo == null) "إضافة صورة (اختياري)" else "تغيير الصورة") }
            BigButton("حفظ", t.primary, enabled = !busy && name.isNotBlank() && amps.isNotBlank()) {
                val a = Fmt.normDigits(amps).toIntOrNull()
                val sd = runCatching { LocalDate.parse(startDate) }.getOrNull()
                if (a == null || sd == null) { app.say("تحقق من الأمبيرات والتاريخ"); return@BigButton }
                busy = true
                val input = SubscriberInput(name, phone, address, landmark, a, sd.toEpochDay(), sd.dayOfMonth, notes, photo, if (boardSel == "-") null else boardSel)
                scope.launch {
                    if (id == null) {
                        val mode = app.c.settings.get("first_month_mode", "PRORATED"); val price = app.c.settings.getLong("amp_price", 10000)
                        val r = app.c.repo.addSubscriber(input, app.uid(), mode, price)
                        // إن لم تكن هناك دورات بعد، تُنشأ دورة الشهر الحالي الآن ويُحتسب اشتراكه
                        if (r is FinResult.Ok) app.c.repo.ensureCycles(Fmt.today(), app.uid(), mode, price)
                        app.handle(r, "تمت إضافة المشترك") { app.pop() }
                    } else app.handle(app.c.repo.updateSubscriber(id, input, app.uid()), "تم الحفظ") { app.pop() }
                    busy = false
                }
            }
        }
    }
}

@Composable
fun SubDetailScreen(id: String) {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope(); val ctx = LocalContext.current
    val sub by load(id) { app.c.db.subscribers().get(id) }
    val inv by load(id) { app.c.db.invoices().details(id) }
    val stmt by load(id) { Reports.statement(app.c.db, id) }
    val receipts by load(id) { app.c.db.receipts().forSubscriber(id).take(10) }
    val boards by load { app.c.db.boards().all() }
    var dialog by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    val print = rememberThermalPrint()
    val s = sub
    Screen(s?.fullName ?: "المشترك", onBack = { app.pop() }, actions = {
        if (app.can(Perm.SUB_EDIT)) IconButton(onClick = { app.push(Route.SubForm(id)) }) { Icon(Icons.Filled.Edit, "تعديل", tint = Color.White) }
    }) {
        if (s == null) return@Screen
        val details = inv ?: emptyList()
        val total = details.sumOf { it.total }; val paid = details.sumOf { it.paid }; val rem = total - paid
        val today = Fmt.today()
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Card2(Modifier.fillMaxWidth()) {
                Info("رمز الاشتراك", s.code); Info("الهاتف", s.phone); Info("العنوان", s.address + if (s.landmark.isNotBlank()) " - ${s.landmark}" else "")
                Info("الأمبيرات", s.amps.toString()); Info("الاشتراك الشهري (آخر دورة)", Fmt.iqd(s.monthlyFeeIqd))
                Info("تاريخ التفعيل", Fmt.date(s.startEpochDay))
                Info("البورد", (boards ?: emptyList()).firstOrNull { it.id == s.boardId }?.name ?: "بدون بورد")
                Info("الحالة", statusAr(s.status), when (s.status) { "ACTIVE" -> t.good; "PAUSED" -> t.warn; else -> t.bad })
                if (s.exceptionPriceIqd > 0) Info("سعر استثنائي للأمبير", Fmt.iqd(s.exceptionPriceIqd), t.warn)
            }
            Card2(Modifier.fillMaxWidth()) {
                Info("إجمالي المستحق", Fmt.iqd(total)); Info("إجمالي المسدد", Fmt.iqd(paid), t.good)
                Info("المتبقي", Fmt.iqd(rem), if (rem > 0) t.bad else t.good)
                Info("حالة التسديد", Cycles.settlement(paid, rem))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (app.can(Perm.COLLECT)) BigButton("قبض", t.good, Modifier.weight(1f), icon = Icons.Filled.Payments) { app.push(Route.Collect(id)) }
                if (app.can(Perm.REMIND) && rem > 0) BigButton("تذكير", Color(0xFF25D366), Modifier.weight(1f), icon = Icons.Filled.Send) {
                    scope.launch { openWhatsApp(app, ctx, s, details) }
                }
            }
            if (app.can(Perm.SUB_EDIT)) {
                SectionTitle("نقل إلى بورد")
                Chips(listOf("-" to "بدون بورد") + (boards ?: emptyList()).map { it.id to it.name }, s.boardId ?: "-") { b ->
                    scope.launch { app.handle(app.c.repo.moveSubscribers(listOf(id), if (b == "-") null else b, app.uid()), "تم النقل (حساباته لم تتغير)") } }
                SectionTitle("إدارة الاشتراك")
                Chips(buildList {
                    if (s.status == "ACTIVE") add("pause" to "إيقاف مؤقت") else add("react" to "إعادة تفعيل")
                    if (s.status != "CANCELLED") add("cancel" to "إلغاء الاشتراك")
                    add("price" to "سعر استثنائي")
                }, "") { k ->
                    when (k) {
                        "pause" -> scope.launch { app.handle(app.c.repo.setSubscriberStatus(id, "PAUSED", null, app.uid()), "تم الإيقاف") }
                        "react" -> scope.launch { app.handle(app.c.repo.setSubscriberStatus(id, "ACTIVE", null, app.uid()), "تمت إعادة التفعيل (نسبي لبقية الدورة إن لزم)") }
                        else -> { priceText = ""; dialog = k }
                    }
                }
            }
            SectionTitle("اشتراكات الدورات")
            details.forEach { d ->
                val r = d.total - d.paid
                val ge = LocalDate.ofEpochDay(d.graceEndEpochDay)
                val st = Cycles.status(r, ge, today)
                val (stText, stColor) = when (st) {
                    Cycles.Status.PAID -> "مسدد" to t.good
                    Cycles.Status.IN_GRACE -> "ضمن فترة التسديد حتى ${Fmt.date(d.graceEndEpochDay)}" to t.warn
                    Cycles.Status.LATE -> "متأخر ${Cycles.lateDays(ge, today)} يوم" to t.bad
                }
                Card2(Modifier.fillMaxWidth()) { Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(d.periodYm, color = t.text, fontWeight = FontWeight.Bold)
                        if (!d.note.isNullOrBlank()) Text(d.note, color = t.warn, fontSize = 12.sp)
                        Text(stText, color = stColor, fontSize = 12.sp)
                    }
                    Column { Text(Fmt.money(d.total), color = t.text, fontSize = 13.sp); Text(Fmt.money(r), color = if (r > 0) t.bad else t.good, fontSize = 13.sp) }
                } }
            }
            if (details.isEmpty()) Empty("لا توجد اشتراكات بعد. تُنشأ الدورات تلقائياً.")
            SectionTitle("آخر السندات")
            (receipts ?: emptyList()).forEach { r ->
                Card2(Modifier.fillMaxWidth(), onClick = { app.push(Route.ReceiptView(r.id)) }) { Row {
                    Text(r.serialNo + if (r.status == "CANCELLED") " (ملغى)" else "", color = if (r.status == "CANCELLED") t.bad else t.text, modifier = Modifier.weight(1f))
                    Text(Fmt.iqd(r.amountIqd), color = t.text) } }
            }
            SectionTitle("كشف الحساب")
            stmt?.let { st ->
                DataTable(st.headers, st.rows, st.totals, listOf(140, 190, 90, 90, 100), Modifier.height(300.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { Exporter.share(ctx, Exporter.csv(ctx, "statement-${s.code}", st.headers, st.rows, st.totals), "text/csv") }) { Text("CSV") }
                    OutlinedButton(onClick = { scope.launch {
                        val d = withContext(Dispatchers.IO) { buildStatementData(app.c, id, app.userName()) }
                        if (d != null) Exporter.share(ctx, StatementPdf.create(ctx, d), "application/pdf") } }) { Text("PDF") }
                    OutlinedButton(onClick = { scope.launch {
                        val d = withContext(Dispatchers.IO) { buildStatementData(app.c, id, app.userName()) }
                        if (d != null) preview = StatementRenderer.render(d, 576) } }) { Text("معاينة / طباعة") }
                }
            }
        }
        if (dialog == "cancel") ReasonDialog("إلغاء الاشتراك (يبقى السجل المالي)", "إلغاء الاشتراك", true, { dialog = "" }) { r ->
            scope.launch { app.handle(app.c.repo.setSubscriberStatus(id, "CANCELLED", r, app.uid()), "تم إلغاء الاشتراك") }; dialog = "" }
        if (dialog == "price") ExceptionPriceDialog(priceText, { priceText = it }, { dialog = "" }) { price, reason ->
            scope.launch { app.handle(app.c.repo.setExceptionPrice(id, price, reason, app.uid()), "تم حفظ السعر الاستثنائي للأشهر القادمة") }; dialog = "" }
        preview?.let { bmp ->
            AlertDialog(onDismissRequest = { preview = null }, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text("معاينة كشف الحساب") },
                text = { Column(Modifier.verticalScroll(rememberScrollState())) { Image(bmp.asImageBitmap(), "معاينة", Modifier.fillMaxWidth()) } },
                confirmButton = { TextButton(onClick = {
                    scope.launch {
                        val d = withContext(Dispatchers.IO) { buildStatementData(app.c, id, app.userName()) }
                        if (d != null) print({ w -> StatementRenderer.render(d, w) }, null)
                    }
                }) { Text("طباعة حرارية", color = t.primary) } },
                dismissButton = { TextButton(onClick = { preview = null }) { Text("إغلاق", color = t.sub) } })
        }
    }
}

@Composable
private fun ExceptionPriceDialog(v: String, onChange: (String) -> Unit, onDismiss: () -> Unit, onOk: (Long, String) -> Unit) {
    val t = LocalTok.current
    var reason by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text("سعر أمبير استثنائي") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("سعر الأمبير (0 = إلغاء الاستثناء)", v, onChange, number = true); Field("السبب (مطلوب)", reason, { reason = it }) } },
        confirmButton = { TextButton(onClick = { onOk(Fmt.parseMoney(v) ?: 0, reason) }) { Text("حفظ", color = t.primary) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("تراجع", color = t.sub) } })
}

/** يبني رسالة واتساب من القالب ويفتح المحادثة. يسجَّل «تم فتح التذكير» فقط؛ لا نجزم بوصول الرسالة. */
suspend fun openWhatsApp(app: AppState, ctx: android.content.Context, s: Subscriber, details: List<InvoiceDetail>, textOverride: String? = null) {
    val intl = PhoneFormat.toInternational(s.phone)
    if (intl == null) { app.say("رقم الهاتف غير صالح لواتساب"); return }
    val msg = textOverride ?: reminderText(app, s, details)
    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$intl?text=" + URLEncoder.encode(msg, "UTF-8"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    withContext(Dispatchers.IO) {
        app.c.db.reminders().insert(ReminderLog(UUID.randomUUID().toString(), s.id, System.currentTimeMillis(), msg, app.uid()))
    }
    app.say("تم فتح التذكير (الإرسال بيدك)")
}

fun reminderText(app: AppState, s: Subscriber, details: List<InvoiceDetail>): String {
    val open = details.filter { it.total > it.paid }
    return app.c.settings.get("wa_template")
        .replace("{name}", s.fullName).replace("{amount}", Fmt.money(open.sumOf { it.total - it.paid })).replace("{amps}", s.amps.toString())
        .replace("{months}", open.joinToString("، ") { it.periodYm }).replace("{due}", open.minOfOrNull { it.dueEpochDay }?.let { Fmt.date(it) } ?: "-")
        .replace("{graceEnd}", open.minOfOrNull { it.graceEndEpochDay }?.let { Fmt.date(it) } ?: "-")
        .replace("{gen}", app.c.settings.get("gen_name"))
}
