package com.generator.accounts.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.generator.accounts.core.*
import com.generator.accounts.data.*
import com.generator.accounts.finance.SubscriberInput
import com.generator.accounts.output.Exporter
import kotlinx.coroutines.launch
import java.net.URLEncoder
import java.util.UUID

private val SUB_HEADERS = listOf("الاسم", "م", "رمز الاشتراك", "الهاتف", "الأمبيرات", "الاشتراك الشهري", "يوم الاستحقاق", "الدين السابق", "المسدد", "المتبقي", "الحالة")
private val SUB_WIDTHS = listOf(150, 44, 80, 110, 80, 110, 90, 100, 100, 100, 80)
private fun statusAr(s: String) = when (s) { "ACTIVE" -> "فعال"; "PAUSED" -> "متوقف مؤقتاً"; else -> "ملغى" }

@Composable
fun SubscribersScreen() {
    val app = LocalApp.current; val t = LocalTok.current; val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var onlyDebt by remember { mutableStateOf(false) }
    var sort by remember { mutableIntStateOf(0) }
    var desc by remember { mutableStateOf(false) }
    var limit by remember { mutableIntStateOf(50) }
    val ym = remember { currentYm() }
    val pageSize = 50
    // البحث والفرز والتصفية من قاعدة البيانات مع تحميل تدريجي
    val rowsS = load(q, status, sort, desc, limit) {
        app.c.db.subscribers().rows(ym, q.trim(), status, sort, if (desc) 1 else 0, limit + 1, 0)
    }
    val totS = load(q, status) { app.c.db.subscribers().totals(ym, q.trim(), status) }
    val all = rowsS.value ?: emptyList()
    val shown = (if (all.size > limit) all.take(limit) else all).filter { !onlyDebt || it.remaining > 0 }
    val hasMore = all.size > limit
    // يوافق ترتيب الأعمدة المعروضة: الاسم أولاً (ثابت) ثم م ثم رمز...
    fun toRow(r: SubscriberRow, i: Int) = TableRow(r.id, listOf(r.fullName, (i + 1).toString(), r.code, r.phone, r.amps.toString(),
        Fmt.money(r.monthlyFeeIqd), r.billingDay.toString(), Fmt.money(r.prevDebt), Fmt.money(r.paidThisMonth), Fmt.money(r.remaining), statusAr(r.status)))
    val rows = shown.mapIndexed { i, r -> toRow(r, i) }
    val tot = totS.value
    val totals = tot?.let { listOf("الإجمالي (${it.cnt})", "", "", "", it.amps.toString(), Fmt.money(it.fee), "", Fmt.money(it.prev), Fmt.money(it.paid), Fmt.money(it.remaining), "") }
    // أعمدة الفرز في SQL: 0 اسم، 1 رمز، 2 أمبير، 3 اشتراك، 4 يوم، 5 دين سابق، 6 مسدد، 7 متبقي، 8 حالة
    val sortMap = mapOf(0 to 0, 2 to 1, 4 to 2, 5 to 3, 6 to 4, 7 to 5, 8 to 6, 9 to 7, 10 to 8)

    Screen("المشتركون", actions = {
        if (app.can(Perm.SUB_ADD)) IconButton(onClick = { app.push(Route.SubForm(null)) }) { Icon(Icons.Filled.PersonAdd, "إضافة", tint = Color.White) }
        IconButton(onClick = {
            Exporter.share(ctx, Exporter.csv(ctx, "subscribers", SUB_HEADERS, rows, totals), "text/csv") }) { Icon(Icons.Filled.Share, "CSV", tint = Color.White) }
        IconButton(onClick = {
            Exporter.share(ctx, Exporter.pdfTable(ctx, "subscribers", "المشتركون", app.c.settings.get("gen_name") + " - " + Exporter.stamp(), SUB_HEADERS, rows, totals), "application/pdf") }) { Icon(Icons.Filled.Print, "PDF", tint = Color.White) }
    }) {
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("بحث بالاسم أو الهاتف أو الرمز", q, { q = it; limit = pageSize })
            Chips(listOf("" to "الكل", "ACTIVE" to "فعال", "PAUSED" to "متوقف", "CANCELLED" to "ملغى"), status) { status = it; limit = pageSize }
            Chips(listOf("0" to "الجميع", "1" to "من عليه متبقي"), if (onlyDebt) "1" else "0") { onlyDebt = it == "1" }
            DataTable(SUB_HEADERS, rows, totals, SUB_WIDTHS, Modifier.weight(1f), sortCol = sortMap.entries.firstOrNull { it.value == sort }?.key ?: 0, sortDesc = desc,
                onSort = { col -> val s = sortMap[col]; if (s != null) { if (s == sort) desc = !desc else { sort = s; desc = false }; limit = pageSize } },
                onRowClick = { r -> r.id?.let { app.push(Route.SubDetail(it)) } },
                colorFor = { i, r -> when (i) {
                    9 -> if ((Fmt.parseMoney(r.cells[9]) ?: 0) > 0) t.bad else t.good
                    10 -> when (r.cells[10]) { "فعال" -> t.good; "متوقف مؤقتاً" -> t.warn; else -> t.bad }
                    else -> null } },
                hasMore = hasMore, onLoadMore = { limit += pageSize })
        }
    }
}

@Composable
fun SubFormScreen(id: String?) {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope(); val ctx = LocalContext.current
    val existing by load(id) { id?.let { app.c.db.subscribers().get(it) } }
    var loaded by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }; var landmark by remember { mutableStateOf("") }
    var amps by remember { mutableStateOf("") }; var notes by remember { mutableStateOf("") }
    var startDate by remember { mutableStateOf(Fmt.today().toString()) }
    var day by remember { mutableStateOf(Fmt.today().dayOfMonth.toString()) }
    var photo by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(existing) {
        val s = existing
        if (s != null && !loaded) { loaded = true; name = s.fullName; phone = s.phone; address = s.address; landmark = s.landmark
            amps = s.amps.toString(); notes = s.notes; startDate = Fmt.date(s.startEpochDay); day = s.billingDay.toString(); photo = s.photoPath }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) photo = com.generator.accounts.output.ImageUtil.save(ctx, uri, "sub-" + UUID.randomUUID() + ".jpg")
    }
    Screen(if (id == null) "مشترك جديد" else "تعديل مشترك", onBack = { app.pop() }) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Field("الاسم الكامل", name, { name = it })
            Field("الهاتف", phone, { phone = it }, phone = true)
            Field("العنوان", address, { address = it })
            Field("أقرب نقطة دالة", landmark, { landmark = it })
            Field("عدد الأمبيرات", amps, { amps = it }, number = true)
            if (id == null) Field("تاريخ بداية الاشتراك (yyyy-MM-dd)", startDate, { startDate = Fmt.normDigits(it); runCatching { java.time.LocalDate.parse(Fmt.normDigits(it)) }.getOrNull()?.let { d -> day = d.dayOfMonth.toString() } })
            if (id == null) Field("يوم الاستحقاق من كل شهر (1-31)", day, { day = it }, number = true)
            if (id == null) Text("يُقترح تلقائياً يوم التسجيل، ويمكنك تعديله يدوياً.", color = t.sub, fontSize = 12.sp)
            Field("ملاحظات", notes, { notes = it }, singleLine = false)
            OutlinedButton(onClick = { pick.launch("image/*") }) { Text(if (photo == null) "إضافة صورة (اختياري)" else "تغيير الصورة") }
            BigButton("حفظ", t.primary, enabled = !busy && name.isNotBlank() && amps.isNotBlank()) {
                val a = Fmt.normDigits(amps).toIntOrNull(); val d = Fmt.normDigits(day).toIntOrNull()
                val sd = runCatching { java.time.LocalDate.parse(startDate) }.getOrNull()
                if (a == null || d == null || sd == null) { app.say("تحقق من الأمبيرات والتاريخ واليوم"); return@BigButton }
                busy = true
                val input = SubscriberInput(name, phone, address, landmark, a, sd.toEpochDay(), d, notes, photo)
                scope.launch {
                    if (id == null) app.handle(app.c.repo.addSubscriber(input, app.uid(), app.c.settings.get("first_month_mode", "FULL"), app.c.settings.getLong("amp_price", 10000)), "تمت إضافة المشترك") { app.pop() }
                    else app.handle(app.c.repo.updateSubscriber(id, input, app.uid()), "تم الحفظ") { app.pop() }
                    busy = false
                }
            }
        }
    }
}

@Composable
fun SubDetailScreen(id: String) {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope(); val ctx = LocalContext.current
    val sub by load(id) { app.c.db.subscribers().get(id) }
    val inv by load(id) { app.c.db.invoices().details(id) }
    val stmt by load(id) { Reports.statement(app.c.db, id) }
    val receipts by load(id) { app.c.db.receipts().forSubscriber(id).take(10) }
    var dialog by remember { mutableStateOf("") }
    var dayText by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    val s = sub
    Screen(s?.fullName ?: "المشترك", onBack = { app.pop() }, actions = {
        if (app.can(Perm.SUB_EDIT)) IconButton(onClick = { app.push(Route.SubForm(id)) }) { Icon(Icons.Filled.Edit, "تعديل", tint = Color.White) }
    }) {
        if (s == null) return@Screen
        val details = inv ?: emptyList()
        val total = details.sumOf { it.total }; val paid = details.sumOf { it.paid }; val rem = total - paid
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Card2(Modifier.fillMaxWidth()) {
                Info("رمز الاشتراك", s.code); Info("الهاتف", s.phone); Info("العنوان", s.address + if (s.landmark.isNotBlank()) " - ${s.landmark}" else "")
                Info("الأمبيرات", s.amps.toString()); Info("الاشتراك الشهري", Fmt.iqd(s.monthlyFeeIqd))
                Info("يوم الاستحقاق", "${s.billingDay} من كل شهر"); Info("بداية الاشتراك", Fmt.date(s.startEpochDay))
                Info("الحالة", statusAr(s.status), when (s.status) { "ACTIVE" -> t.good; "PAUSED" -> t.warn; else -> t.bad })
                if (s.exceptionPriceIqd > 0) Info("سعر استثنائي للأمبير", Fmt.iqd(s.exceptionPriceIqd), t.warn)
            }
            Card2(Modifier.fillMaxWidth()) {
                Info("إجمالي المستحق", Fmt.iqd(total)); Info("إجمالي المسدد", Fmt.iqd(paid), t.good)
                Info("المتبقي", Fmt.iqd(rem), if (rem > 0) t.bad else t.good)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (app.can(Perm.COLLECT)) BigButton("قبض", t.good, Modifier.weight(1f), icon = Icons.Filled.Payments) { app.push(Route.Collect(id)) }
                if (app.can(Perm.REMIND) && rem > 0) BigButton("تذكير", Color(0xFF25D366), Modifier.weight(1f), icon = Icons.Filled.Send) {
                    scope.launch { openWhatsApp(app, ctx, s, details) }
                }
            }
            if (app.can(Perm.SUB_EDIT)) {
                SectionTitle("إدارة الاشتراك")
                Chips(buildList {
                    if (s.status == "ACTIVE") add("pause" to "إيقاف مؤقت") else if (s.status != "CANCELLED") add("react" to "إعادة تفعيل")
                    if (s.status == "CANCELLED") add("react" to "إعادة تفعيل")
                    if (s.status != "CANCELLED") add("cancel" to "إلغاء الاشتراك")
                    add("day" to "تغيير يوم الاستحقاق"); add("price" to "سعر استثنائي")
                }, "") { k ->
                    when (k) {
                        "pause" -> scope.launch { app.handle(app.c.repo.setSubscriberStatus(id, "PAUSED", null, app.uid()), "تم الإيقاف") }
                        "react" -> scope.launch { app.handle(app.c.repo.setSubscriberStatus(id, "ACTIVE", null, app.uid()), "تمت إعادة التفعيل") }
                        "day" -> { dayText = s.billingDay.toString(); dialog = "day" }
                        else -> { priceText = ""; dialog = k }
                    }
                }
            }
            SectionTitle("فواتير الأشهر")
            details.forEach { d ->
                Card2(Modifier.fillMaxWidth()) { Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(d.periodYm, color = t.text, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        Text("الاستحقاق ${Fmt.date(d.dueEpochDay)}" + (DueDates.daysOverdue(java.time.LocalDate.ofEpochDay(d.dueEpochDay), Fmt.today()).takeIf { it > 0 && d.total > d.paid }?.let { " • متأخر $it يوم" } ?: ""), color = t.sub, fontSize = 12.sp) }
                    Column { Text(Fmt.money(d.total), color = t.text, fontSize = 13.sp); Text(Fmt.money(d.total - d.paid), color = if (d.total > d.paid) t.bad else t.good, fontSize = 13.sp) }
                } }
            }
            if (details.isEmpty()) Empty("لا توجد فواتير بعد. أنشئ شهراً مالياً من «الأشهر المالية».")
            SectionTitle("آخر السندات")
            (receipts ?: emptyList()).forEach { r ->
                Card2(Modifier.fillMaxWidth(), onClick = { app.push(Route.ReceiptView(r.id)) }) { Row {
                    Text(r.serialNo + if (r.status == "CANCELLED") " (ملغى)" else "", color = if (r.status == "CANCELLED") t.bad else t.text, modifier = Modifier.weight(1f))
                    Text(Fmt.iqd(r.amountIqd), color = t.text) } }
            }
            SectionTitle("كشف الحساب")
            stmt?.let { st ->
                DataTable(st.headers, st.rows, st.totals, listOf(140, 190, 90, 90, 100), Modifier.height(320.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { Exporter.share(ctx, Exporter.csv(ctx, "statement-${s.code}", st.headers, st.rows, st.totals), "text/csv") }) { Text("CSV") }
                    OutlinedButton(onClick = { Exporter.share(ctx, Exporter.pdfTable(ctx, "statement-${s.code}", "كشف حساب: ${s.fullName}", app.c.settings.get("gen_name") + " - " + Exporter.stamp(), st.headers, st.rows, st.totals), "application/pdf") }) { Text("PDF") }
                }
            }
        }
        if (dialog == "day") ConfirmDayDialog(dayText, { dayText = it }, { dialog = "" }) {
            val d = Fmt.normDigits(dayText).toIntOrNull() ?: 0
            scope.launch { app.handle(app.c.repo.changeBillingDay(id, d, app.uid()), "تم تغيير يوم الاستحقاق للدورات القادمة") }; dialog = ""
        }
        if (dialog == "cancel") ReasonDialog("إلغاء الاشتراك (يبقى السجل المالي)", "إلغاء الاشتراك", true, { dialog = "" }) { r ->
            scope.launch { app.handle(app.c.repo.setSubscriberStatus(id, "CANCELLED", r, app.uid()), "تم إلغاء الاشتراك") }; dialog = "" }
        if (dialog == "price") ExceptionPriceDialog(priceText, { priceText = it }, { dialog = "" }) { price, reason ->
            scope.launch { app.handle(app.c.repo.setExceptionPrice(id, price, reason, app.uid()), "تم حفظ السعر الاستثنائي للأشهر القادمة") }; dialog = "" }
    }
}

@Composable
private fun ConfirmDayDialog(v: String, onChange: (String) -> Unit, onDismiss: () -> Unit, onOk: () -> Unit) {
    val t = LocalTok.current
    AlertDialog(onDismissRequest = onDismiss, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text("يوم الاستحقاق الجديد") },
        text = { Column { Field("اليوم (1-31)", v, onChange, number = true); Text("يسري على الدورات القادمة فقط ولا يغيّر الفواتير المنشأة، ويُسجَّل في سجل التدقيق.", fontSize = 12.sp, color = t.sub) } },
        confirmButton = { TextButton(onClick = onOk) { Text("حفظ", color = t.primary) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("تراجع", color = t.sub) } })
}

@Composable
private fun ExceptionPriceDialog(v: String, onChange: (String) -> Unit, onDismiss: () -> Unit, onOk: (Long, String) -> Unit) {
    val t = LocalTok.current
    var reason by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text, title = { Text("سعر أمبير استثنائي") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("سعر الأمبير (0 = إلغاء الاستثناء)", v, onChange, number = true); Field("السبب (مطلوب)", reason, { reason = it }) } },
        confirmButton = { TextButton(onClick = { onOk(Fmt.parseMoney(v) ?: 0, reason) }) { Text("حفظ", color = t.primary) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("تراجع", color = t.sub) } })
}

/** يبني رسالة واتساب من القالب ويفتح المحادثة. يسجَّل «تم فتح التذكير» فقط؛ لا نجزم بوصول الرسالة. */
suspend fun openWhatsApp(app: AppState, ctx: android.content.Context, s: Subscriber, details: List<InvoiceDetail>, textOverride: String? = null) {
    val intl = PhoneFormat.toInternational(s.phone)
    if (intl == null) { app.say("رقم الهاتف غير صالح لواتساب"); return }
    val msg = textOverride ?: reminderText(app, s, details)
    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$intl?text=" + URLEncoder.encode(msg, "UTF-8"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        app.c.db.reminders().insert(ReminderLog(UUID.randomUUID().toString(), s.id, System.currentTimeMillis(), msg, app.uid()))
    }
    app.say("تم فتح التذكير (الإرسال بيدك)")
}

fun reminderText(app: AppState, s: Subscriber, details: List<InvoiceDetail>): String {
    val open = details.filter { it.total > it.paid }
    return app.c.settings.get("wa_template")
        .replace("{name}", s.fullName).replace("{amount}", Fmt.money(open.sumOf { it.total - it.paid })).replace("{amps}", s.amps.toString())
        .replace("{months}", open.joinToString("، ") { it.periodYm }).replace("{due}", open.minOfOrNull { it.dueEpochDay }?.let { Fmt.date(it) } ?: "-")
        .replace("{gen}", app.c.settings.get("gen_name"))
}
