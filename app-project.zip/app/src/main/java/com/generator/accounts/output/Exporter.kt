package com.generator.accounts.output

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.generator.accounts.core.Fmt
import com.generator.accounts.data.TableRow
import java.io.File

object Exporter {
    private fun dir(ctx: Context) = File(ctx.cacheDir, "exports").apply { mkdirs() }
    private fun safe(n: String) = n.replace(Regex("[^\\p{L}\\p{N}_-]"), "_")

    /** CSV بترميز UTF-8 مع BOM ليظهر العربي صحيحاً في Excel. */
    fun csv(ctx: Context, name: String, headers: List<String>, rows: List<TableRow>, totals: List<String>?): File {
        val f = File(dir(ctx), safe(name) + ".csv")
        fun esc(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        f.outputStream().use { o ->
            o.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
            val sb = StringBuilder()
            sb.append(headers.joinToString(",") { esc(it) }).append("\r\n")
            rows.forEach { r -> sb.append(r.cells.joinToString(",") { esc(it) }).append("\r\n") }
            totals?.let { sb.append(it.joinToString(",") { c -> esc(c) }).append("\r\n") }
            o.write(sb.toString().toByteArray(Charsets.UTF_8))
        }
        return f
    }

    /** PDF بحجم A4 (أفقي إذا كثرت الأعمدة)، ترتيب الأعمدة من اليمين لليسار. */
    fun pdfTable(ctx: Context, name: String, title: String, subtitle: String,
                 headers: List<String>, rows: List<TableRow>, totals: List<String>?): File {
        val landscape = headers.size > 6
        val pw = if (landscape) 842 else 595; val ph = if (landscape) 595 else 842
        val margin = 28f; val rowH = 24f
        val colW = (pw - 2 * margin) / headers.size
        val txt = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = if (headers.size > 8) 8.5f else 10f; color = Color.BLACK }
        val bold = TextPaint(txt).apply { isFakeBoldText = true; color = Color.WHITE }
        val head = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 16f; isFakeBoldText = true; color = Color.parseColor("#082F49") }
        val fill = Paint().apply { color = Color.parseColor("#082F49") }
        val alt = Paint().apply { color = Color.parseColor("#EEF4F8") }
        val line = Paint().apply { color = Color.parseColor("#C9D6DF"); strokeWidth = 0.6f }
        val doc = PdfDocument()
        var pageNo = 0
        var page: PdfDocument.Page? = null
        var canvas: Canvas? = null
        var y = 0f
        fun cell(c: Canvas, s: String, col: Int, yy: Float, p: TextPaint) {
            val right = pw - margin - col * colW
            val maxW = colW - 8
            val n = p.breakText(s, true, maxW, null)
            val shown = if (n < s.length) s.take(maxOf(0, n - 1)) + "…" else s
            c.drawText(shown, right - 4 - p.measureText(shown), yy, p)   // محاذاة لليمين (RTL)
        }
        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, pageNo).create())
            canvas = page!!.canvas
            val c = canvas!!
            c.drawText(title, pw - margin - head.measureText(title), margin + 14, head)
            val sub = TextPaint(txt)
            c.drawText(subtitle, pw - margin - sub.measureText(subtitle), margin + 32, sub)
            y = margin + 46
            c.drawRect(margin, y, pw - margin, y + rowH, fill)
            headers.forEachIndexed { i, h -> cell(c, h, i, y + 16, bold) }
            y += rowH
        }
        newPage()
        rows.forEachIndexed { idx, r ->
            if (y + rowH > ph - margin) newPage()
            val c = canvas!!
            if (idx % 2 == 1) c.drawRect(margin, y, pw - margin, y + rowH, alt)
            r.cells.forEachIndexed { i, s -> cell(c, s, i, y + 16, txt) }
            c.drawLine(margin, y + rowH, pw - margin, y + rowH, line)
            y += rowH
        }
        totals?.let {
            if (y + rowH > ph - margin) newPage()
            val c = canvas!!
            c.drawRect(margin, y, pw - margin, y + rowH, Paint().apply { color = Color.parseColor("#D4AF37") })
            it.forEachIndexed { i, s -> cell(c, s, i, y + 16, TextPaint(txt).apply { isFakeBoldText = true }) }
        }
        page?.let { doc.finishPage(it) }
        val f = File(dir(ctx), safe(name) + ".pdf")
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        return f
    }

    /** صفحة A4 تحتوي صورة السند (أو أي صورة) في أعلاها. */
    fun pdfFromBitmap(ctx: Context, name: String, bmp: Bitmap): File {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val w = 420f; val h = w * bmp.height / bmp.width
        page.canvas.drawBitmap(bmp, null, RectF((595 - w) / 2, 40f, (595 + w) / 2, 40f + h), Paint(Paint.FILTER_BITMAP_FLAG))
        doc.finishPage(page)
        val f = File(dir(ctx), safe(name) + ".pdf")
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        return f
    }

    fun stamp() = Fmt.dateTime(System.currentTimeMillis())

    fun share(ctx: Context, f: File, mime: String, title: String = "مشاركة") {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
