package com.generator.accounts.core

/** تفقيط المبلغ بالدينار العراقي (بلا كسور). */
object ArabicMoney {
    private val ones = listOf("", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة",
        "عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر")
    private val tens = listOf("", "", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون")
    private val hundreds = listOf("", "مائة", "مائتان", "ثلاثمائة", "أربعمائة", "خمسمائة", "ستمائة", "سبعمائة", "ثمانمائة", "تسعمائة")

    private fun below1000(n: Int): String {
        val parts = ArrayList<String>()
        val h = n / 100
        val r = n % 100
        if (h > 0) parts += hundreds[h]
        if (r in 1..19) parts += ones[r]
        else if (r >= 20) {
            val u = r % 10
            parts += if (u > 0) ones[u] + " و" + tens[r / 10] else tens[r / 10]
        }
        return parts.joinToString(" و")
    }

    private fun scaled(g: Int, one: String, two: String, few: String, many: String): String = when {
        g == 1 -> one
        g == 2 -> two
        g in 3..10 -> below1000(g) + " " + few
        else -> below1000(g) + " " + many
    }

    fun words(amount: Long): String {
        require(amount >= 0) { "negative amount" }
        if (amount == 0L) return "صفر دينار عراقي فقط لا غير"
        val billions = (amount / 1_000_000_000L).toInt()
        val millions = ((amount / 1_000_000L) % 1000).toInt()
        val thousands = ((amount / 1000L) % 1000).toInt()
        val rest = (amount % 1000).toInt()
        val parts = ArrayList<String>()
        if (billions > 0) parts += scaled(billions, "مليار", "ملياران", "مليارات", "مليار")
        if (millions > 0) parts += scaled(millions, "مليون", "مليونان", "ملايين", "مليون")
        if (thousands > 0) parts += scaled(thousands, "ألف", "ألفان", "آلاف", "ألف")
        if (rest > 0) parts += below1000(rest)
        return parts.joinToString(" و") + " دينار عراقي فقط لا غير"
    }
}
