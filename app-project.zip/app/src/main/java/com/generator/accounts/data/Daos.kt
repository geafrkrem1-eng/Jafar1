package com.generator.accounts.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

data class InvoiceBalance(val invoiceId: String, val dueEpochDay: Long, val total: Long, val paid: Long)
data class InvoiceDetail(val invoiceId: String, val periodYm: String, val dueEpochDay: Long, val total: Long, val paid: Long,
    val graceEndEpochDay: Long, val isProrated: Boolean, val daysCharged: Int, val cycleDays: Int, val note: String?)
data class AllocLine(val periodYm: String, val amount: Long, val total: Long, val paidUpTo: Long)
data class BoardCount(val boardId: String?, val cnt: Int)
data class SubscriberRow(val id: String, val code: String, val fullName: String, val phone: String, val amps: Int,
    val monthlyFeeIqd: Long, val billingDay: Int, val status: String,
    val prevDebt: Long, val paidThisMonth: Long, val remaining: Long, val boardId: String?)
data class SubTotals(val cnt: Int, val amps: Long, val fee: Long, val prev: Long, val paid: Long, val remaining: Long)

/** الاستعلام الأساسي لجدول المشتركين: الأرصدة تُحسب من الفواتير والتوزيعات الفعلية فقط. */
const val SUB_INNER = """SELECT s.id AS id, s.code AS code, s.fullName AS fullName, s.phone AS phone, s.amps AS amps,
 s.monthlyFeeIqd AS monthlyFeeIqd, s.billingDay AS billingDay, s.status AS status, s.boardId AS boardId,
 COALESCE((SELECT SUM(i.baseAmount + i.adjustmentAmount - COALESCE((SELECT SUM(a.amountIqd) FROM receipt_allocations a WHERE a.invoiceId = i.id),0))
   FROM invoices i WHERE i.subscriberId = s.id AND i.isDeleted = 0 AND i.periodYm < :ym),0) AS prevDebt,
 COALESCE((SELECT SUM(a.amountIqd) FROM receipt_allocations a JOIN invoices i ON i.id = a.invoiceId
   WHERE i.subscriberId = s.id AND i.periodYm = :ym AND i.isDeleted = 0),0) AS paidThisMonth,
 COALESCE((SELECT SUM(i.baseAmount + i.adjustmentAmount - COALESCE((SELECT SUM(a.amountIqd) FROM receipt_allocations a WHERE a.invoiceId = i.id),0))
   FROM invoices i WHERE i.subscriberId = s.id AND i.isDeleted = 0),0) AS remaining
 FROM subscribers s WHERE s.isDeleted = 0
 AND (:q = '' OR s.fullName LIKE '%' || :q || '%' OR s.phone LIKE '%' || :q || '%' OR s.code LIKE '%' || :q || '%')
 AND (:status = '' OR s.status = :status)
 AND (:board = '' OR (:board = '-' AND s.boardId IS NULL) OR s.boardId = :board)"""

const val SUB_ROWS = "SELECT * FROM (" + SUB_INNER + """) ORDER BY
        CASE WHEN :sort=0 AND :dir=0 THEN fullName END ASC, CASE WHEN :sort=0 AND :dir=1 THEN fullName END DESC,
        CASE WHEN :sort=1 AND :dir=0 THEN code END ASC, CASE WHEN :sort=1 AND :dir=1 THEN code END DESC,
        CASE WHEN :sort=2 AND :dir=0 THEN amps END ASC, CASE WHEN :sort=2 AND :dir=1 THEN amps END DESC,
        CASE WHEN :sort=3 AND :dir=0 THEN monthlyFeeIqd END ASC, CASE WHEN :sort=3 AND :dir=1 THEN monthlyFeeIqd END DESC,
        CASE WHEN :sort=4 AND :dir=0 THEN billingDay END ASC, CASE WHEN :sort=4 AND :dir=1 THEN billingDay END DESC,
        CASE WHEN :sort=5 AND :dir=0 THEN prevDebt END ASC, CASE WHEN :sort=5 AND :dir=1 THEN prevDebt END DESC,
        CASE WHEN :sort=6 AND :dir=0 THEN paidThisMonth END ASC, CASE WHEN :sort=6 AND :dir=1 THEN paidThisMonth END DESC,
        CASE WHEN :sort=7 AND :dir=0 THEN remaining END ASC, CASE WHEN :sort=7 AND :dir=1 THEN remaining END DESC,
        CASE WHEN :sort=8 AND :dir=0 THEN status END ASC, CASE WHEN :sort=8 AND :dir=1 THEN status END DESC,
        fullName ASC LIMIT :limit OFFSET :offset"""
const val SUB_TOTALS = "SELECT COUNT(*) AS cnt, COALESCE(SUM(amps),0) AS amps, COALESCE(SUM(monthlyFeeIqd),0) AS fee, COALESCE(SUM(prevDebt),0) AS prev, COALESCE(SUM(paidThisMonth),0) AS paid, COALESCE(SUM(remaining),0) AS remaining FROM (" + SUB_INNER + ")"

@Dao interface SubscriberDao {
    @Insert suspend fun insert(s: Subscriber)
    @Update suspend fun update(s: Subscriber)
    @Query("SELECT * FROM subscribers WHERE id=:id") suspend fun get(id: String): Subscriber?
    @Query("SELECT COUNT(*) FROM subscribers") suspend fun total(): Int
    @Query("SELECT COUNT(*) FROM subscribers WHERE code=:c") suspend fun codeExists(c: String): Int
    @Query("SELECT COUNT(*) FROM subscribers WHERE isDeleted=0") fun count(): Flow<Int>
    @Query("SELECT * FROM subscribers WHERE isDeleted=0 AND status='ACTIVE'") suspend fun activeAll(): List<Subscriber>
    @Query("SELECT * FROM subscribers WHERE isDeleted=0 AND (:q='' OR fullName LIKE '%'||:q||'%' OR phone LIKE '%'||:q||'%' OR code LIKE '%'||:q||'%') ORDER BY fullName LIMIT 30")
    suspend fun quickSearch(q: String): List<Subscriber>
    @Query("UPDATE subscribers SET monthlyFeeIqd=:fee, ampPriceIqd=:price WHERE id=:id")
    suspend fun setFee(id: String, fee: Long, price: Long)
    @Query(SUB_ROWS) suspend fun rows(ym: String, q: String, status: String, board: String, sort: Int, dir: Int, limit: Int, offset: Int): List<SubscriberRow>
    @Query(SUB_TOTALS) suspend fun totals(ym: String, q: String, status: String, board: String): SubTotals
    @Query("SELECT id FROM (" + SUB_INNER + ")") suspend fun idsFor(ym: String, q: String, status: String, board: String): List<String>
    @Query("SELECT boardId AS boardId, COUNT(*) AS cnt FROM subscribers WHERE isDeleted=0 GROUP BY boardId") suspend fun boardCounts(): List<BoardCount>
    @Query("UPDATE subscribers SET boardId=:board, updatedAt=:at, updatedBy=:by, updatedDeviceId=:dev WHERE id=:id")
    suspend fun setBoard(id: String, board: String?, at: Long, by: String, dev: String)
    @Query("UPDATE subscribers SET boardId=NULL, updatedAt=:at, updatedBy=:by, updatedDeviceId=:dev WHERE boardId=:board")
    suspend fun clearBoard(board: String, at: Long, by: String, dev: String): Int
}

@Dao interface MonthDao {
    @Insert suspend fun insert(m: MonthRecord)
    @Query("SELECT * FROM months WHERE ym=:ym") suspend fun byYm(ym: String): MonthRecord?
    @Query("SELECT * FROM months ORDER BY ym DESC") suspend fun all(): List<MonthRecord>
    @Query("UPDATE months SET status='CLOSED', closedAt=:at, updatedAt=:at, updatedBy=:by, updatedDeviceId=:dev WHERE ym=:ym AND status='OPEN'")
    suspend fun close(ym: String, at: Long, by: String, dev: String): Int
    @Query("UPDATE months SET ampPriceIqd=:p, updatedAt=:at, updatedBy=:by, updatedDeviceId=:dev WHERE ym=:ym")
    suspend fun setPrice(ym: String, p: Long, at: Long, by: String, dev: String)
}

@Dao interface InvoiceDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertIgnore(i: Invoice): Long
    @Query("SELECT * FROM invoices WHERE id=:id") suspend fun get(id: String): Invoice?
    @Query("SELECT COUNT(*) FROM invoices WHERE subscriberId=:sid") suspend fun countFor(sid: String): Int
    @Query("SELECT * FROM invoices WHERE subscriberId=:sid AND isDeleted=0 ORDER BY periodYm") suspend fun forSubscriber(sid: String): List<Invoice>
    @Query("""SELECT i.id AS invoiceId, i.dueEpochDay AS dueEpochDay,
        (i.baseAmount + i.adjustmentAmount) AS total,
        COALESCE((SELECT SUM(a.amountIqd) FROM receipt_allocations a WHERE a.invoiceId=i.id),0) AS paid
        FROM invoices i WHERE i.subscriberId=:sid AND i.isDeleted=0 ORDER BY i.dueEpochDay""")
    suspend fun balances(sid: String): List<InvoiceBalance>
    @Query("""SELECT i.id AS invoiceId, i.periodYm AS periodYm, i.dueEpochDay AS dueEpochDay,
        (i.baseAmount + i.adjustmentAmount) AS total,
        COALESCE((SELECT SUM(a.amountIqd) FROM receipt_allocations a WHERE a.invoiceId=i.id),0) AS paid,
        i.graceEndEpochDay AS graceEndEpochDay, i.isProrated AS isProrated, i.daysCharged AS daysCharged,
        i.cycleDays AS cycleDays, i.firstMonthNote AS note
        FROM invoices i WHERE i.subscriberId=:sid AND i.isDeleted=0 ORDER BY i.dueEpochDay""")
    suspend fun details(sid: String): List<InvoiceDetail>
    @Query("UPDATE invoices SET adjustmentAmount=:adj, adjustmentReason=:reason, updatedAt=:at, updatedBy=:by, updatedDeviceId=:dev WHERE id=:id")
    suspend fun setAdjustment(id: String, adj: Long, reason: String, at: Long, by: String, dev: String)
    @Query("SELECT * FROM invoices WHERE periodYm=:ym AND isDeleted=0") suspend fun forMonth(ym: String): List<Invoice>
    @Query("SELECT COUNT(*) FROM receipt_allocations a JOIN invoices i ON i.id=a.invoiceId WHERE i.periodYm=:ym") suspend fun allocationCount(ym: String): Int
    @Query("UPDATE invoices SET ampPriceIqd=:price, fullAmount=:full, baseAmount=:base, updatedAt=:at, updatedBy=:by, updatedDeviceId=:dev WHERE id=:id")
    suspend fun reprice(id: String, price: Long, full: Long, base: Long, at: Long, by: String, dev: String)
}

@Dao interface ReceiptDao {
    @Insert suspend fun insert(r: Receipt)
    @Query("SELECT * FROM receipts WHERE id=:id") suspend fun get(id: String): Receipt?
    @Query("SELECT * FROM receipts WHERE idempotencyKey=:k") suspend fun byKey(k: String): Receipt?
    @Query("SELECT * FROM receipts WHERE subscriberId=:sid ORDER BY paidAtMillis DESC") suspend fun forSubscriber(sid: String): List<Receipt>
    @Query("SELECT COALESCE(MAX(seq),0) FROM receipts WHERE deviceCode=:d AND year=:y")
    suspend fun maxSeq(d: String, y: Int): Int
    @Query("""UPDATE receipts SET status='CANCELLED', cancelReason=:reason, cancelledAt=:at, cancelledBy=:by,
        updatedAt=:at, updatedBy=:by, updatedDeviceId=:dev WHERE id=:id AND status='ACTIVE'""")
    suspend fun markCancelled(id: String, reason: String, at: Long, by: String, dev: String): Int
    @Query("UPDATE receipts SET printStatus=:st WHERE id=:id") suspend fun setPrintStatus(id: String, st: String)
}

@Dao interface AllocationDao {
    @Insert suspend fun insertAll(list: List<ReceiptAllocation>)
    @Query("SELECT * FROM receipt_allocations WHERE receiptId=:rid AND isReversal=0")
    suspend fun originalsFor(rid: String): List<ReceiptAllocation>
    @Query("""SELECT DISTINCT i.periodYm FROM receipt_allocations a JOIN invoices i ON i.id=a.invoiceId
        WHERE a.receiptId=:rid AND a.isReversal=0 ORDER BY i.periodYm""")
    suspend fun monthsFor(rid: String): List<String>
    @Query("""SELECT i.periodYm AS periodYm, a.amountIqd AS amount, (i.baseAmount + i.adjustmentAmount) AS total,
        COALESCE((SELECT SUM(a2.amountIqd) FROM receipt_allocations a2 WHERE a2.invoiceId=i.id AND a2.createdAt <= a.createdAt),0) AS paidUpTo
        FROM receipt_allocations a JOIN invoices i ON i.id=a.invoiceId
        WHERE a.receiptId=:rid AND a.isReversal=0 ORDER BY i.periodYm""")
    suspend fun linesFor(rid: String): List<AllocLine>
}

@Dao interface CashDao {
    @Insert suspend fun insert(e: CashEntry)
    @Query("SELECT COALESCE(SUM(CASE WHEN kind='IN' THEN amountIqd ELSE -amountIqd END),0) FROM cash_entries WHERE isDeleted=0")
    fun balance(): Flow<Long>
    @Query("SELECT COALESCE(SUM(CASE WHEN kind='IN' THEN amountIqd ELSE -amountIqd END),0) FROM cash_entries WHERE isDeleted=0")
    suspend fun balanceNow(): Long
    @Query("SELECT COUNT(*) FROM cash_entries WHERE sourceType=:t AND sourceId=:id") suspend fun countFor(t: String, id: String): Int
}

@Dao interface ExpenseDao {
    @Insert suspend fun insert(e: Expense)
    @Query("SELECT * FROM expenses WHERE id=:id") suspend fun get(id: String): Expense?
    @Query("UPDATE expenses SET status='VOID', voidReason=:reason, updatedAt=:at, updatedBy=:by, updatedDeviceId=:dev WHERE id=:id AND status='ACTIVE'")
    suspend fun markVoid(id: String, reason: String, at: Long, by: String, dev: String): Int
}

@Dao interface WorkerDao {
    @Insert suspend fun insert(w: Worker)
    @Update suspend fun update(w: Worker)
    @Query("SELECT * FROM workers WHERE id=:id") suspend fun get(id: String): Worker?
    @Query("SELECT * FROM workers WHERE isDeleted=0 ORDER BY name") suspend fun all(): List<Worker>
}

@Dao interface AdvanceDao {
    @Insert suspend fun insert(a: Advance)
    @Query("SELECT COALESCE(SUM(amountIqd),0) FROM advances WHERE workerId=:wid AND isDeleted=0") suspend fun total(wid: String): Long
}

@Dao interface SlipDao {
    @Insert suspend fun insert(s: PayrollSlip)
    @Update suspend fun update(s: PayrollSlip)
    @Query("SELECT * FROM payroll_slips WHERE id=:id") suspend fun get(id: String): PayrollSlip?
    @Query("SELECT * FROM payroll_slips WHERE workerId=:wid ORDER BY periodYm DESC") suspend fun forWorker(wid: String): List<PayrollSlip>
    @Query("SELECT COALESCE(SUM(advanceDeductionIqd),0) FROM payroll_slips WHERE workerId=:wid AND status IN ('APPROVED','PAID') AND id<>:exclude")
    suspend fun deducted(wid: String, exclude: String): Long
}

@Dao interface BoardDao {
    @Insert suspend fun insert(b: Board)
    @Query("SELECT * FROM boards WHERE isDeleted=0 ORDER BY sortOrder, name") suspend fun all(): List<Board>
    @Query("SELECT * FROM boards WHERE id=:id") suspend fun get(id: String): Board?
    @Query("UPDATE boards SET name=:name, updatedAt=:at, updatedBy=:by, updatedDeviceId=:dev WHERE id=:id")
    suspend fun rename(id: String, name: String, at: Long, by: String, dev: String)
    @Query("UPDATE boards SET isDeleted=1, updatedAt=:at, updatedBy=:by, updatedDeviceId=:dev WHERE id=:id")
    suspend fun softDelete(id: String, at: Long, by: String, dev: String)
}

@Dao interface ClosingDao { @Insert suspend fun insert(c: CashClosing) }
@Dao interface ReminderDao { @Insert suspend fun insert(r: ReminderLog) }
@Dao interface AuditDao { @Insert suspend fun insert(a: AuditLog) }

@Dao interface UserDao {
    @Insert suspend fun insert(u: AppUser)
    @Update suspend fun update(u: AppUser)
    @Query("SELECT * FROM app_users WHERE id=:id") suspend fun get(id: String): AppUser?
    @Query("SELECT * FROM app_users WHERE isDeleted=0 ORDER BY name") suspend fun all(): List<AppUser>
    @Query("SELECT COUNT(*) FROM app_users") suspend fun count(): Int
}

@Dao interface SettingDao {
    @Query("SELECT value FROM app_settings WHERE `key`=:k") suspend fun get(k: String): String?
    @Query("SELECT * FROM app_settings") suspend fun all(): List<AppSetting>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(s: AppSetting)
}
