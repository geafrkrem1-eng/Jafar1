package com.generator.accounts.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.generator.accounts.App
import com.generator.accounts.core.Perm
import com.generator.accounts.output.Backup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private var app: AppState? = null
    private var bgAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = (application as App).container
        val state = AppState(container); app = state
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl, LocalApp provides state) {
                var ready by remember { mutableStateOf(false) }
                var hasUsers by remember { mutableStateOf(true) }
                LaunchedEffect(Unit) {
                    withContext(Dispatchers.IO) { container.init(); hasUsers = container.db.users().count() > 0 }
                    ready = true
                }
                AppTheme(state.prefs()) {
                    Box(Modifier.fillMaxSize().pointerInput(Unit) {
                        awaitPointerEventScope { while (true) { awaitPointerEvent(PointerEventPass.Initial); state.lastTouch = System.currentTimeMillis() } }
                    }) {
                        if (!ready) Box(Modifier.fillMaxSize()) {}
                        else if (state.user == null) {
                            if (!hasUsers) SetupScreen { state.user = it; hasUsers = true; state.root(Route.Home) }
                            else LoginScreen { state.user = it; state.root(Route.Home) }
                        } else {
                            LaunchedEffect(Unit) { Backup.autoIfNeeded(container) }
                            // قفل تلقائي بعد خمول يحدده المدير
                            LaunchedEffect(state.user) {
                                while (true) {
                                    delay(10_000)
                                    val mins = container.settings.getLong("lock_minutes", 5)
                                    if (mins > 0 && System.currentTimeMillis() - state.lastTouch > mins * 60_000) state.user = null
                                }
                            }
                            Shell(state)
                        }
                        Banner()
                    }
                }
            }
        }
    }

    override fun onStop() { super.onStop(); bgAt = System.currentTimeMillis() }
    override fun onStart() {
        super.onStart()
        val s = app ?: return
        val mins = s.c.settings.getLong("lock_minutes", 5)
        if (s.user != null && bgAt > 0 && mins > 0 && System.currentTimeMillis() - bgAt > mins * 60_000) s.user = null
    }
}

private data class Tab(val route: Route, val label: String, val icon: ImageVector)

@Composable
fun Shell(app: AppState) {
    val t = LocalTok.current
    val tabs = listOf(Tab(Route.Home, "الرئيسية", Icons.Filled.Home), Tab(Route.Subscribers, "المشتركون", Icons.Filled.People),
        Tab(Route.Collect(), "التحصيل", Icons.Filled.Payments), Tab(Route.Debts, "الديون", Icons.Filled.Schedule), Tab(Route.More, "المزيد", Icons.Filled.Apps))
    val r = app.route
    val isRoot = tabs.any { it.route::class == r::class }
    BackHandler(enabled = app.stack.size > 1) { app.pop() }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) { Router(app, r) }
        if (isRoot) NavigationBar(containerColor = t.card) {
            tabs.forEach { tab ->
                NavigationBarItem(selected = tab.route::class == r::class, onClick = { app.root(tab.route) },
                    icon = { Icon(tab.icon, tab.label) }, label = { Text(tab.label) },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, selectedTextColor = t.primary,
                        indicatorColor = t.primary, unselectedIconColor = t.sub, unselectedTextColor = t.sub))
            }
        }
    }
}

@Composable
fun Router(app: AppState, r: Route) {
    when (r) {
        Route.Home -> HomeScreen()
        Route.Subscribers -> SubscribersScreen()
        is Route.Collect -> CollectScreen(r.subscriberId)
        Route.Debts -> DebtsScreen()
        Route.More -> MoreScreen()
        Route.FollowUp -> FollowUpScreen()
        is Route.SubDetail -> SubDetailScreen(r.id)
        is Route.SubForm -> SubFormScreen(r.id)
        Route.Receipts -> ReceiptsScreen()
        is Route.ReceiptView -> ReceiptViewScreen(r.id)
        Route.Months -> MonthsScreen()
        Route.Expenses -> ExpensesScreen()
        Route.Workers -> WorkersScreen()
        is Route.WorkerDetail -> WorkerDetailScreen(r.id)
        Route.Cash -> CashScreen()
        Route.Reports -> ReportsScreen()
        Route.Users -> UsersScreen()
        Route.Settings -> SettingsScreen()
        Route.BackupScreen -> BackupScreenUi()
        Route.PrinterScreen -> PrinterScreenUi()
    }
}

@Composable
fun MoreScreen() {
    val app = LocalApp.current; val t = LocalTok.current
    data class Item(val label: String, val icon: ImageVector, val color: Color, val perm: String?, val route: Route)
    val entries = listOf(
        Item("سجل السندات", Icons.Filled.ReceiptLong, t.primary, Perm.COLLECT, Route.Receipts),
        Item("الأشهر المالية", Icons.Filled.Event, t.secondary, Perm.MONTHS, Route.Months),
        Item("الوقود والمصاريف والصيانة", Icons.Filled.LocalGasStation, t.warn, Perm.EXPENSES, Route.Expenses),
        Item("العمال والرواتب", Icons.Filled.Groups, t.purple, Perm.WORKERS, Route.Workers),
        Item("الصندوق", Icons.Filled.AccountBalanceWallet, t.good, Perm.CASH, Route.Cash),
        Item("التقارير", Icons.Filled.BarChart, t.primary, Perm.REPORTS, Route.Reports),
        Item("المستخدمون والصلاحيات", Icons.Filled.Badge, t.purple, Perm.USERS, Route.Users),
        Item("الطابعة الحرارية", Icons.Filled.Print, t.secondary, Perm.SETTINGS, Route.PrinterScreen),
        Item("النسخ الاحتياطي والاستعادة", Icons.Filled.CloudUpload, t.good, Perm.BACKUP, Route.BackupScreen),
        Item("الإعدادات", Icons.Filled.Settings, t.accent, Perm.SETTINGS, Route.Settings)
    )
    val visible = entries.filter { it.perm == null || app.can(it.perm) }
    Screen("المزيد", actions = { TextButton(onClick = { app.user = null }) { Text("تبديل المستخدم", color = Color.White) } }) {
        LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(visible) { item ->
                Card2(Modifier.fillMaxWidth(), onClick = { app.push(item.route) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(item.icon, item.color, 44)
                        Spacer(Modifier.width(12.dp))
                        Text(item.label, color = t.text, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}
