package com.generator.accounts.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.generator.accounts.core.*
import com.generator.accounts.data.*
import com.generator.accounts.finance.FinResult
import com.generator.accounts.output.*
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun CollectScreen(preselect: String?) {
    val app = LocalApp.current; val t = LocalTok.current; val scope = rememberCoroutineScope()
    var sid by remember(preselect) { mutableStateOf(preselect) }
    var q by remember { mutableStateOf("") }
    val found by load(q, sid) { if (sid == null && q.length >= 1) app.c.db.subscribers().quickSearch(q.trim()) else emptyList() }
    val sub by load(sid) { sid?.let { app.c.db.subscribers().get(it) } }
    val inv by load(sid) { sid?.let { app.c.db.invoices().details(it) } ?: emptyList() }
    var amount by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var manual by remember { mutableStateOf(false) }
    val manualAmts = remember { mutableStateMapOf<String, String>() }
    var key by remember { mutableStateOf(UUID.randomUUID().toString()) }   // Idempotency Key
    var busy by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val methods = app.c.settings.get("pay_methods", "نقداً,تحويل").split(',').filter { it.isNotBlank() }
    if (method.isEmpty() && methods.isNotEmpty()) method = methods[0]
    val details = inv ?: emptyList()
    val open = details.filter { it.total > it.paid }
    val totalDue = open.sumOf { it.total - it.paid }
    val amt = Fmt.parseMoney(amount) ?: 0L
    val lines: List<AllocationLine>? = run {
        val oi = open.map { OpenInvoice(it.invoiceId, it.dueEpochDay, it.total - it.paid) }
        if (amt <= 0) null else if (manual) {
            val ml = manualAmts.mapNotNull { (k, v) -> Fmt.parseMoney(v)?.takeIf { it > 0 }?.let { AllocationLine(k, it) } }
            (PaymentAllocator.manual(oi, amt, ml) as? PaymentAllocator.Result.Ok)?.lines
        } else (PaymentAllocator.autoOldestFirst(oi, amt) as? PaymentAllocator.Result.Ok)?.lines
    }
    val ymOf = details.associate { it.invoiceId to it.periodYm }

    Screen("التحصيل", onBack = if (preselect != null) ({ app.pop() }) else null) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (sid == null) {
                Field("ابحث عن المشترك (اسم / هاتف / رمز)", q, { q = it })
                (found ?: emptyList()).forEach { s ->
                    Card2(Modifier.fillMaxWidth(), onClick = { sid = s.id }) { Row { Text(s.fullName, color = t.text, modifier = Modifier.weight(1f)); Text(s.code, color = t.sub) } }
                }
                if (q.isBlank()) Empty("اختر مشتركاً لبدء القبض")
            } else {
                val s = sub
                if (s != null) Card2(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(s.fullName, color = t.text, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { sid = null; amount = ""; manualAmts.clear() }) { Text("تغيير") }
                    }
                    Info("الأمبيرات", s.amps.toString()); Info("اشتراك الشهر", Fmt.iqd(s.monthlyFeeIqd))
                    Info("الديون السابقة", Fmt.iqd(open.filter { it.periodYm < currentYm() }.sumOf { it.total - it.paid }))
                    Info("إجمالي المطلوب", Fmt.iqd(details.sumOf { it.total })); Info("إجمالي ما سدّده", Fmt.iqd(details.sumOf { it.paid }), t.good)
                    Info("المتبقي", Fmt.iqd(totalDue), if (totalDue > 0) t.bad else t.good)
                }
                if (open.isEmpty()) Empty("لا توجد مبالغ مستحقة على هذا المشترك") else {
                    Field("المبلغ (د.ع)", amount, { amount = it }, number = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { amount = totalDue.toString() }) { Text("كامل المتبقي") }
                        open.firstOrNull()?.let { f -> OutlinedButton(onClick = { amount = (f.total - f.paid).toString() }) { Text("أقدم شهر") } }
                    }
                    Text("طريقة الدفع", color = t.sub, fontSize = 12.sp)
                    Chips(methods.map { it to it }, method) { method = it }
                    Field("ملاحظة (اختياري)", note, { note = it })
                    Row(verticalAlignment = Alignment.CenterVertically) { Switch(manual, { manual = it }); Spacer(Modifier.width(8.dp)); Text("توزيع يدوي على الأشهر", color = t.text) }
                    if (manual) open.forEach { d ->
                        Field("${d.periodYm} (متبقي ${Fmt.money(d.total - d.paid)})", manualAmts[d.invoiceId] ?: "", { manualAmts[d.invoiceId] = it }, number = true)
                    }
                    if (amt > 0 && lines == null) Text(if (amt > totalDue) "المبلغ أكبر من إجمالي المستحق" else "تحقق من التوزيع: يجب أن يساوي مجموعه المبلغ", color = t.bad, fontSize = 13.sp)
                    lines?.let { ls -> Card2(Modifier.fillMaxWidth()) {
                        Text("توزيع المبلغ", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = t.text)
                        ls.forEach { l -> Info(ymOf[l.invoiceId] ?: "", Fmt.iqd(l.amount)) }
                        Info("المتبقي بعد القبض", Fmt.iqd(totalDue - amt), t.warn)
                    } }
                    BigButton("اعتماد القبض", t.good, enabled = !busy && lines != null && app.can(Perm.COLLECT), icon = Icons.Filled.Check) { confirm = true }
                }
            }
        }
        if (confirm && lines != null) ConfirmDialog("تأكيد القبض", "قبض ${Fmt.iqd(amt)} من ${sub?.fullName ?: ""}؟", "اعتماد", { confirm = false }) {
            confirm = false; busy = true     // تعطيل الزر أثناء التنفيذ + مفتاح تكرار
            val sidNow = sid ?: return@ConfirmDialog
            scope.launch {
                val r = app.c.repo.collect(sidNow, amt, method, note.ifBlank { null }, app.uid(), key, if (manual) lines else null)
                busy = false
                if (r is FinResult.Ok) { key = UUID.randomUUID().toString(); amount = ""; note = ""; manualAmts.clear(); app.refresh(); app.say("تم القبض: ${r.value.serialNo}"); app.push(Route.ReceiptView(r.value.id)) }
                else if (r is FinResult.Err) app.say(r.message)
            }
        }
    }
}

@Composable
fun ReceiptsScreen() {
    val app = LocalApp.current
    var q by remember { mutableStateOf("") }; var from by remember { mutableStateOf(currentYm()) }; var to by remember { mutableStateOf(currentYm()) }
    val valid = runCatching { java.time.YearMonth.parse(from); java.time.YearMonth.parse(to) }.isSuccess
    Screen("سجل السندات", onBack = { app.pop() }) {
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("بحث (مشترك / رقم سند)", q, { q = it })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("من شهر", from, { from = Fmt.normDigits(it) }, Modifier.weight(1f)); Field("إلى شهر", to, { to = Fmt.normDigits(it) }, Modifier.weight(1f))
            }
            if (valid) SpecTable(Reports.receipts(q.trim(), from, to), listOf(110, 150, 100, 90, 130, 70), Modifier.weight(1f), "receipts", listOf(q, from, to),
                onRowClick = { r -> r.id?.let { app.push(Route.ReceiptView(it)) } },
                colorFor = { i, r -> if (i == 5 && r.cells[5] == "ملغى") Color(0xFFEF4444) else null })
            else Text("صيغة الشهر 2026-11")
        }
    }
}

@Composable
fun ReceiptViewScreen(id: String) {
    val app = LocalApp.current; val t = LocalTok.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val data by load(id) { buildReceiptData(app.c, id) }
    val width = if (app.c.settings.get("printer_width", "58") == "80") 576 else 384
    val bmp = remember(data, width) { data?.let { ReceiptRenderer.render(it.second, width) } }
    var cancel by remember { mutableStateOf(false) }
    var pendingPrint by remember { mutableStateOf(false) }
    fun doPrint() {
        val b = bmp ?: return; val addr = app.c.settings.get("printer_address")
        if (addr.isBlank()) { app.say("اختر الطابعة أولاً من: المزيد > الطابعة الحرارية"); return }
        scope.launch {
            val e = ThermalPrinter.print(ctx, addr, b, width)
            if (e == null) { app.c.repo.markPrinted(id); app.refresh(); app.say("أُرسل السند إلى الطابعة (تأكد من خروج الورق)") } else app.say(e)
        }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok && pendingPrint) doPrint() else if (!ok) app.say("لا توجد صلاحية البلوتوث") ; pendingPrint = false }
    Screen("سند قبض", onBack = { app.pop() }) {
        val d = data
        if (d == null || bmp == null) { Empty("جاري التحميل"); return@Screen }
        val (r, rd) = d
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Card2(Modifier.fillMaxWidth()) { Image(bmp.asImageBitmap(), "معاينة السند", Modifier.fillMaxWidth()) }
            Text("حالة الطباعة: " + if (r.printStatus == "SENT_TO_PRINTER") "أُرسل للطابعة (غير مؤكد فعلياً)" else "لم يُطبع", color = t.sub, fontSize = 12.sp)
            BigButton("طباعة حرارية", t.primary, icon = Icons.Filled.Print) {
                if (Build.VERSION.SDK_INT >= 31 && ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    pendingPrint = true; perm.launch(Manifest.permission.BLUETOOTH_CONNECT)
                } else doPrint()
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("PDF ومشاركة", t.secondary, Modifier.weight(1f), icon = Icons.Filled.Share) {
                    val big = ReceiptRenderer.render(rd, 576)
                    Exporter.share(ctx, Exporter.pdfFromBitmap(ctx, "receipt-${r.serialNo}", big), "application/pdf") }
            }
            if (r.status == "ACTIVE" && app.can(Perm.CANCEL_RECEIPT)) BigButton("إلغاء السند", t.bad, icon = Icons.Filled.Close) { cancel = true }
        }
        if (cancel) ReasonDialog("إلغاء السند ${r.serialNo}", "إلغاء السند", true, { cancel = false }) { reason ->
            cancel = false
            scope.launch { app.handle(app.c.repo.cancelReceipt(id, reason, app.uid()), "تم الإلغاء بقيد عكسي") }
        }
    }
}
