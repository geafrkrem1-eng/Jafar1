package com.generator.accounts.finance

import androidx.room.withTransaction
import com.generator.accounts.core.*
import com.generator.accounts.data.*
import java.time.LocalDate
import java.time.YearMonth
import java.util.UUID

sealed class FinResult<out T> {
    data class Ok<T>(val value: T) : FinResult<T>()
    data class Err(val message: String) : FinResult<Nothing>()
}

data class SubscriberInput(
    val fullName: String, val phone: String, val address: String, val landmark: String,
    val amps: Int, val startEpochDay: Long, val billingDay: Int, val notes: String, val photoPath: String?
)
data class ExpenseInput(
    val kind: String, val category: String, val amountIqd: Long, val epochDay: Long, val payee: String,
    val method: String, val description: String, val notes: String, val imagePath: String?,
    val fuelType: String? = null, val litersMilli: Long = 0, val pricePerLiterIqd: Long = 0,
    val supplier: String? = null, val voucherNo: String? = null,
    val nextDueEpochDay: Long? = null, val technician: String? = null
)

/**
 * الطبقة المالية المركزية الوحيدة. كل عملية داخل Transaction واحدة؛ أي خطأ (استثناء أو نتيجة Err)
 * يتراجع عن كل ما كُتب ضمن العملية. لا تُكتب أي حركة مالية خارج هذه الفئة.
 */
class FinanceRepository(
    private val db: AppDatabase,
    private val deviceIdProvider: () -> String,
    private val deviceCodeProvider: () -> String,
    private val now: () -> Long = { System.currentTimeMillis() }
) {
    private val deviceId get() = deviceIdProvider()
    private class Rollback(val err: FinResult.Err) : RuntimeException()

    private suspend fun <T> tx(block: suspend () -> FinResult<T>): FinResult<T> = try {
        db.withTransaction { val r = block(); if (r is FinResult.Err) throw Rollback(r); r }
    } catch (e: Rollback) { e.err } catch (e: Exception) {
        FinResult.Err("فشلت العملية ولم يُسجَّل شيء: ${e.message}")
    }

    private fun meta(user: String, t: Long) = Meta(t, t, user, user, deviceId, deviceId)
    private fun uid() = UUID.randomUUID().toString()
    private fun err(m: String) = FinResult.Err(m)
    private fun validAmount(a: Long) = a in 1..MAX_AMOUNT

    private suspend fun audit(type: String, id: String, action: String, before: String?, after: String?, reason: String?, user: String, t: Long) =
        db.audit().insert(AuditLog(uid(), type, id, action, before, after, reason, user, deviceId, t))

    private suspend fun cash(kind: String, amount: Long, category: String, srcType: String, srcId: String,
                             rev: Boolean, desc: String, user: String, t: Long) =
        db.cash().insert(CashEntry(uid(), kind, amount, category, srcType, srcId, rev, t, desc, meta(user, t)))

    // ───────────── المشتركون ─────────────
    suspend fun addSubscriber(i: SubscriberInput, user: String, firstMode: String, defaultPrice: Long): FinResult<Subscriber> = tx {
        if (i.fullName.isBlank()) return@tx err("الاسم مطلوب")
        if (i.amps !in 1..1000) return@tx err("عدد الأمبيرات غير منطقي")
        if (i.billingDay !in 1..31) return@tx err("يوم الاستحقاق يجب أن يكون بين 1 و31")
        val t = now()
        var n = 1000 + db.subscribers().total() + 1
        while (db.subscribers().codeExists(n.toString()) > 0) n++
        val s = Subscriber(uid(), n.toString(), i.fullName.trim(), i.phone.trim(), i.address.trim(), i.landmark.trim(),
            i.amps, defaultPrice, i.amps * defaultPrice, 0, i.startEpochDay, i.billingDay, "ACTIVE",
            i.notes, i.photoPath, meta(user, t))
        db.subscribers().insert(s)
        audit("Subscriber", s.id, "CREATE", null, "code=${s.code};day=${s.billingDay}", null, user, t)
        // إن كان شهر دورته مفتوحاً أصلاً تُنشأ له فاتورته فوراً
        val ym = cycleMonthFor(s)
        db.months().byYm(ym.toString())?.takeIf { it.status == "OPEN" }?.let { issueInvoice(s, it, firstMode, user, t) }
        FinResult.Ok(s)
    }

    /** الشهر الذي تقع فيه دورة المشترك عند تاريخ بدايته. */
    private fun cycleMonthFor(s: Subscriber): YearMonth {
        val start = LocalDate.ofEpochDay(s.startEpochDay)
        val cur = YearMonth.from(start)
        val due = DueDates.dueDate(cur, s.billingDay)
        return if (start.isBefore(due)) cur.minusMonths(1) else cur
    }

    suspend fun updateSubscriber(id: String, i: SubscriberInput, user: String): FinResult<Unit> = tx {
        val s = db.subscribers().get(id) ?: return@tx err("المشترك غير موجود")
        if (i.fullName.isBlank()) return@tx err("الاسم مطلوب")
        if (i.amps !in 1..1000) return@tx err("عدد الأمبيرات غير منطقي")
        val t = now()
        db.subscribers().update(s.copy(fullName = i.fullName.trim(), phone = i.phone.trim(), address = i.address.trim(),
            landmark = i.landmark.trim(), amps = i.amps, notes = i.notes, photoPath = i.photoPath ?: s.photoPath,
            monthlyFeeIqd = i.amps * (if (s.exceptionPriceIqd > 0) s.exceptionPriceIqd else s.ampPriceIqd),
            meta = s.meta.copy(updatedAt = t, updatedBy = user, updatedDeviceId = deviceId)))
        audit("Subscriber", id, "UPDATE", "name=${s.fullName};amps=${s.amps}", "name=${i.fullName};amps=${i.amps}", null, user, t)
        FinResult.Ok(Unit)
    }

    suspend fun setSubscriberStatus(id: String, status: String, reason: String?, user: String): FinResult<Unit> = tx {
        val s = db.subscribers().get(id) ?: return@tx err("المشترك غير موجود")
        if (status !in listOf("ACTIVE", "PAUSED", "CANCELLED")) return@tx err("حالة غير صالحة")
        if (status == "CANCELLED" && (reason ?: "").trim().length < 3) return@tx err("سبب الإلغاء مطلوب")
        val t = now()
        db.subscribers().update(s.copy(status = status, meta = s.meta.copy(updatedAt = t, updatedBy = user, updatedDeviceId = deviceId)))
        audit("Subscriber", id, "STATUS", s.status, status, reason, user, t)   // السجل المالي يبقى كما هو
        FinResult.Ok(Unit)
    }

    /** تغيير يوم الاستحقاق: يسري على الدورات القادمة فقط ولا يمس الفواتير المنشأة. */
    suspend fun changeBillingDay(id: String, day: Int, user: String): FinResult<Unit> = tx {
        val s = db.subscribers().get(id) ?: return@tx err("المشترك غير موجود")
        if (day !in 1..31) return@tx err("اليوم يجب أن يكون بين 1 و31")
        val t = now()
        db.subscribers().update(s.copy(billingDay = day, meta = s.meta.copy(updatedAt = t, updatedBy = user, updatedDeviceId = deviceId)))
        audit("Subscriber", id, "BILLING_DAY", s.billingDay.toString(), day.toString(), null, user, t)
        FinResult.Ok(Unit)
    }

    /** سعر استثنائي لمشترك بعينه (0 = إلغاء الاستثناء) بسبب موثّق؛ يسري على الأشهر القادمة. */
    suspend fun setExceptionPrice(id: String, price: Long, reason: String, user: String): FinResult<Unit> = tx {
        val s = db.subscribers().get(id) ?: return@tx err("المشترك غير موجود")
        if (price < 0 || price > MAX_AMOUNT) return@tx err("سعر غير صالح")
        if (reason.trim().length < 3) return@tx err("السبب مطلوب")
        val t = now()
        db.subscribers().update(s.copy(exceptionPriceIqd = price, meta = s.meta.copy(updatedAt = t, updatedBy = user, updatedDeviceId = deviceId)))
        audit("Subscriber", id, "EXCEPTION_PRICE", s.exceptionPriceIqd.toString(), price.toString(), reason, user, t)
        FinResult.Ok(Unit)
    }

    // ───────────── الأشهر والفواتير ─────────────
    private suspend fun issueInvoice(s: Subscriber, m: MonthRecord, firstMode: String, user: String, t: Long): Boolean {
        val ym = YearMonth.parse(m.ym)
        val due = DueDates.dueDate(ym, s.billingDay)
        val end = DueDates.cycleEnd(ym, s.billingDay)
        if (LocalDate.ofEpochDay(s.startEpochDay).isAfter(end)) return false
        val price = if (s.exceptionPriceIqd > 0) s.exceptionPriceIqd else m.ampPriceIqd
        var base = s.amps * price
        var note: String? = null
        if (db.invoices().countFor(s.id) == 0) {
            val r = FirstMonth.apply(base, firstMode, LocalDate.ofEpochDay(s.startEpochDay), due, end)
            base = r.first; note = r.second
        }
        val inv = Invoice(uid(), s.id, m.ym, s.amps, price, base, 0, null, due.toEpochDay(), note, meta(user, t))
        val ok = db.invoices().insertIgnore(inv) != -1L     // يمنع تكرار (مشترك + شهر)
        if (ok) db.subscribers().setFee(s.id, s.amps * price, price)
        return ok
    }

    /** إنشاء شهر مالي جديد وتوليد اشتراكات كل المشتركين الفعالين بسعر مثبّت للشهر. */
    suspend fun createMonth(ym: String, ampPrice: Long, firstMode: String, user: String): FinResult<Int> = tx {
        runCatching { YearMonth.parse(ym) }.getOrNull() ?: return@tx err("صيغة الشهر يجب أن تكون 2026-11")
        if (!validAmount(ampPrice)) return@tx err("سعر الأمبير غير صالح")
        if (db.months().byYm(ym) != null) return@tx err("هذا الشهر موجود مسبقاً")
        val t = now()
        val m = MonthRecord(uid(), ym, ampPrice, "OPEN", null, meta(user, t))
        db.months().insert(m)
        var n = 0
        for (s in db.subscribers().activeAll()) if (issueInvoice(s, m, firstMode, user, t)) n++
        audit("Month", m.id, "CREATE", null, "ym=$ym;price=$ampPrice;invoices=$n", null, user, t)
        FinResult.Ok(n)
    }

    suspend fun closeMonth(ym: String, user: String): FinResult<Unit> = tx {
        val t = now()
        if (db.months().close(ym, t, user, deviceId) == 0) return@tx err("الشهر غير موجود أو مغلق")
        audit("Month", ym, "CLOSE", "OPEN", "CLOSED", null, user, t)
        FinResult.Ok(Unit)
    }

    /** رسم أو خصم استثنائي موثّق على فاتورة (delta موجب = رسم، سالب = خصم). ممنوع على شهر مغلق. */
    suspend fun adjustInvoice(invoiceId: String, delta: Long, reason: String, user: String): FinResult<Unit> = tx {
        val inv = db.invoices().get(invoiceId) ?: return@tx err("الفاتورة غير موجودة")
        val m = db.months().byYm(inv.periodYm)
        if (m?.status == "CLOSED") return@tx err("الشهر مغلق، لا تعديل على حركاته")
        if (reason.trim().length < 3) return@tx err("السبب مطلوب")
        val newAdj = inv.adjustmentAmount + delta
        if (inv.baseAmount + newAdj < 0) return@tx err("الخصم أكبر من قيمة الفاتورة")
        val paid = db.invoices().balances(inv.subscriberId).first { it.invoiceId == invoiceId }.paid
        if (inv.baseAmount + newAdj < paid) return@tx err("القيمة الجديدة أقل مما سُدّد على الفاتورة")
        val t = now()
        db.invoices().setAdjustment(invoiceId, newAdj, reason.trim(), t, user, deviceId)
        audit("Invoice", invoiceId, "ADJUST", inv.adjustmentAmount.toString(), newAdj.toString(), reason.trim(), user, t)
        FinResult.Ok(Unit)
    }

    // ───────────── التحصيل والسندات ─────────────
    suspend fun collect(
        subscriberId: String, amountIqd: Long, method: String, note: String?, user: String,
        idempotencyKey: String, manual: List<AllocationLine>? = null
    ): FinResult<Receipt> = tx {
        db.receipts().byKey(idempotencyKey)?.let { return@tx FinResult.Ok(it) }   // ضغط مكرر → نفس السند
        if (!validAmount(amountIqd)) return@tx err("المبلغ غير صالح")
        db.subscribers().get(subscriberId) ?: return@tx err("المشترك غير موجود")
        val open = db.invoices().balances(subscriberId).map { OpenInvoice(it.invoiceId, it.dueEpochDay, it.total - it.paid) }
        val res = if (manual != null) PaymentAllocator.manual(open, amountIqd, manual) else PaymentAllocator.autoOldestFirst(open, amountIqd)
        val lines = when (res) {
            is PaymentAllocator.Result.Ok -> res.lines
            is PaymentAllocator.Result.Error -> return@tx err(res.message)
        }
        val before = open.sumOf { maxOf(0L, it.outstanding) }
        val t = now()
        val code = deviceCodeProvider()
        val year = Fmt.year(t)
        val seq = db.receipts().maxSeq(code, year) + 1
        val r = Receipt(uid(), "%s-%d-%04d".format(code, year, seq), code, year, seq, subscriberId, amountIqd, t,
            method, note, idempotencyKey, before, before - amountIqd, "ACTIVE", null, null, null, "NOT_PRINTED", meta(user, t))
        db.receipts().insert(r)
        db.allocations().insertAll(lines.map { ReceiptAllocation(uid(), r.id, it.invoiceId, it.amount, false, meta(user, t)) })
        cash("IN", amountIqd, "SUBSCRIBER_RECEIPT", "RECEIPT", r.id, false, "سند قبض ${r.serialNo}", user, t)
        audit("Receipt", r.id, "CREATE", null, "serial=${r.serialNo};amount=$amountIqd", null, user, t)
        FinResult.Ok(r)
    }

    /** إلغاء سند بقيد عكسي، دون حذف. السند الأصلي يبقى بحالة «ملغى». */
    suspend fun cancelReceipt(receiptId: String, reason: String, user: String): FinResult<Unit> = tx {
        if (reason.trim().length < 3) return@tx err("سبب الإلغاء مطلوب")
        val t = now()
        val r = db.receipts().get(receiptId) ?: return@tx err("السند غير موجود")
        if (db.receipts().markCancelled(receiptId, reason.trim(), t, user, deviceId) == 0) return@tx err("السند ملغى مسبقاً")
        db.allocations().insertAll(db.allocations().originalsFor(receiptId).map {
            ReceiptAllocation(uid(), receiptId, it.invoiceId, -it.amountIqd, true, meta(user, t))
        })
        cash("OUT", r.amountIqd, "RECEIPT_REVERSAL", "RECEIPT", receiptId, true, "إلغاء سند ${r.serialNo}: ${reason.trim()}", user, t)
        audit("Receipt", receiptId, "CANCEL", "status=ACTIVE", "status=CANCELLED", reason.trim(), user, t)
        FinResult.Ok(Unit)
    }

    suspend fun markPrinted(receiptId: String) = db.receipts().setPrintStatus(receiptId, "SENT_TO_PRINTER")

    // ───────────── المصاريف والوقود والصيانة ─────────────
    suspend fun addExpense(i: ExpenseInput, user: String): FinResult<String> = tx {
        var amount = i.amountIqd
        if (i.kind == "FUEL") {
            if (i.litersMilli <= 0 || i.pricePerLiterIqd <= 0) return@tx err("أدخل كمية اللترات وسعر اللتر")
            amount = (i.litersMilli * i.pricePerLiterIqd + 500) / 1000     // تقريب لأقرب دينار، بلا Double
        }
        if (!validAmount(amount)) return@tx err("المبلغ غير صالح")
        if (i.kind !in listOf("GENERAL", "FUEL", "MAINTENANCE")) return@tx err("نوع غير صالح")
        val t = now()
        val e = Expense(uid(), i.kind, i.category, amount, i.epochDay, i.payee, i.method, i.description, i.notes, i.imagePath,
            i.fuelType, i.litersMilli, i.pricePerLiterIqd, i.supplier, i.voucherNo, i.nextDueEpochDay, i.technician,
            "ACTIVE", null, meta(user, t))
        db.expenses().insert(e)
        cash("OUT", amount, i.category, "EXPENSE", e.id, false, "${i.category}: ${i.description}", user, t)
        audit("Expense", e.id, "CREATE", null, "kind=${i.kind};amount=$amount", null, user, t)
        FinResult.Ok(e.id)
    }

    suspend fun voidExpense(id: String, reason: String, user: String): FinResult<Unit> = tx {
        if (reason.trim().length < 3) return@tx err("السبب مطلوب")
        val e = db.expenses().get(id) ?: return@tx err("المصروف غير موجود")
        val t = now()
        if (db.expenses().markVoid(id, reason.trim(), t, user, deviceId) == 0) return@tx err("المصروف ملغى مسبقاً")
        cash("IN", e.amountIqd, e.category, "EXPENSE", id, true, "إلغاء مصروف: ${reason.trim()}", user, t)
        audit("Expense", id, "VOID", "ACTIVE", "VOID", reason.trim(), user, t)
        FinResult.Ok(Unit)
    }

    // ───────────── الصندوق ─────────────
    suspend fun manualCash(kind: String, amount: Long, category: String, reason: String, user: String): FinResult<Unit> = tx {
        if (kind != "IN" && kind != "OUT") return@tx err("نوع غير صالح")
        if (!validAmount(amount)) return@tx err("المبلغ غير صالح")
        if (reason.trim().length < 3) return@tx err("السبب مطلوب")
        val t = now()
        val id = uid()
        cash(kind, amount, category, "MANUAL", id, false, reason.trim(), user, t)
        audit("CashEntry", id, "MANUAL", null, "$kind;$amount", reason.trim(), user, t)
        FinResult.Ok(Unit)
    }

    /** إغلاق الصندوق: مقارنة النقد الفعلي برصيد النظام؛ الفرق يستلزم سبباً. */
    suspend fun closeCash(actual: Long, reason: String, user: String): FinResult<Long> = tx {
        if (actual < 0 || actual > MAX_AMOUNT) return@tx err("المبلغ غير صالح")
        val system = db.cash().balanceNow()
        val diff = actual - system
        if (diff != 0L && reason.trim().length < 3) return@tx err("يوجد فرق ($diff) ولا يمكن الإغلاق دون توضيحه")
        val t = now()
        val c = CashClosing(uid(), t, system, actual, diff, reason.trim().ifEmpty { null }, user, meta(user, t))
        db.closings().insert(c)
        audit("CashClosing", c.id, "CLOSE", "system=$system", "actual=$actual;diff=$diff", reason.trim(), user, t)
        FinResult.Ok(diff)
    }

    // ───────────── العمال والرواتب والسلف ─────────────
    suspend fun saveWorker(existingId: String?, name: String, phone: String, address: String, job: String, startEpochDay: Long,
                           payType: String, rate: Long, status: String, notes: String, user: String): FinResult<String> = tx {
        if (name.isBlank()) return@tx err("الاسم مطلوب")
        if (payType !in listOf("MONTHLY", "DAILY", "HOURLY")) return@tx err("طريقة الأجر غير صالحة")
        if (!validAmount(rate)) return@tx err("الأجر غير صالح")
        val t = now()
        if (existingId == null) {
            val w = Worker(uid(), name.trim(), phone, address, job, startEpochDay, payType, rate, status, notes, meta(user, t))
            db.workers().insert(w); audit("Worker", w.id, "CREATE", null, name, null, user, t)
            FinResult.Ok(w.id)
        } else {
            val w = db.workers().get(existingId) ?: return@tx err("العامل غير موجود")
            db.workers().update(w.copy(name = name.trim(), phone = phone, address = address, job = job, startEpochDay = startEpochDay,
                payType = payType, rateIqd = rate, status = status, notes = notes, meta = w.meta.copy(updatedAt = t, updatedBy = user, updatedDeviceId = deviceId)))
            audit("Worker", w.id, "UPDATE", w.rateIqd.toString(), rate.toString(), null, user, t)
            FinResult.Ok(w.id)
        }
    }

    suspend fun advanceBalance(workerId: String): Long = db.advances().total(workerId) - db.slips().deducted(workerId, "")

    suspend fun addAdvance(workerId: String, amount: Long, epochDay: Long, note: String, user: String): FinResult<Unit> = tx {
        if (!validAmount(amount)) return@tx err("المبلغ غير صالح")
        db.workers().get(workerId) ?: return@tx err("العامل غير موجود")
        val t = now()
        val a = Advance(uid(), workerId, amount, epochDay, note, meta(user, t))
        db.advances().insert(a)
        cash("OUT", amount, "ADVANCE", "ADVANCE", a.id, false, "سلفة: $note", user, t)
        audit("Advance", a.id, "CREATE", null, "worker=$workerId;amount=$amount", null, user, t)
        FinResult.Ok(Unit)
    }

    suspend fun createSlip(workerId: String, ym: String, units: Long, bonus: Long, deductions: Long, advanceDeduction: Long, user: String): FinResult<String> = tx {
        val w = db.workers().get(workerId) ?: return@tx err("العامل غير موجود")
        runCatching { YearMonth.parse(ym) }.getOrNull() ?: return@tx err("صيغة الشهر غير صحيحة")
        if (bonus < 0 || deductions < 0 || advanceDeduction < 0) return@tx err("قيم سالبة غير مسموحة")
        val basic = if (w.payType == "MONTHLY") w.rateIqd else w.rateIqd * units
        if (w.payType != "MONTHLY" && units <= 0) return@tx err("أدخل عدد الأيام أو الساعات")
        if (advanceDeduction > advanceBalance(workerId)) return@tx err("استقطاع السلفة أكبر من الرصيد المتبقي")
        val net = basic + bonus - deductions - advanceDeduction
        if (net < 0) return@tx err("صافي الراتب سالب")
        val t = now()
        val s = PayrollSlip(uid(), workerId, ym, units, basic, bonus, deductions, advanceDeduction, net, "DRAFT", null, null, meta(user, t))
        try { db.slips().insert(s) } catch (e: Exception) { return@tx err("يوجد كشف لهذا العامل في هذا الشهر") }
        audit("PayrollSlip", s.id, "CREATE", null, "net=$net", null, user, t)
        FinResult.Ok(s.id)
    }

    suspend fun approveSlip(id: String, user: String): FinResult<Unit> = tx {
        val s = db.slips().get(id) ?: return@tx err("الكشف غير موجود")
        if (s.status != "DRAFT") return@tx err("الكشف ليس مسودة")
        val bal = db.advances().total(s.workerId) - db.slips().deducted(s.workerId, id)
        if (s.advanceDeductionIqd > bal) return@tx err("استقطاع السلفة أكبر من الرصيد المتبقي")
        val t = now()
        db.slips().update(s.copy(status = "APPROVED", meta = s.meta.copy(updatedAt = t, updatedBy = user, updatedDeviceId = deviceId)))
        audit("PayrollSlip", id, "APPROVE", "DRAFT", "APPROVED", null, user, t)
        FinResult.Ok(Unit)
    }

    /** صرف الراتب يسجَّل في الصندوق تلقائياً (صافي المبلغ). */
    suspend fun paySlip(id: String, user: String): FinResult<Unit> = tx {
        val s = db.slips().get(id) ?: return@tx err("الكشف غير موجود")
        if (s.status != "APPROVED") return@tx err("يجب اعتماد الكشف قبل الصرف")
        val t = now()
        db.slips().update(s.copy(status = "PAID", paidAt = t, meta = s.meta.copy(updatedAt = t, updatedBy = user, updatedDeviceId = deviceId)))
        if (s.netIqd > 0) cash("OUT", s.netIqd, "PAYROLL", "PAYROLL", id, false, "راتب ${s.periodYm}", user, t)
        audit("PayrollSlip", id, "PAY", "APPROVED", "PAID", null, user, t)
        FinResult.Ok(Unit)
    }

    suspend fun voidSlip(id: String, reason: String, user: String): FinResult<Unit> = tx {
        val s = db.slips().get(id) ?: return@tx err("الكشف غير موجود")
        if (s.status == "PAID" || s.status == "VOID") return@tx err("لا يمكن إلغاء كشف مصروف")
        if (reason.trim().length < 3) return@tx err("السبب مطلوب")
        val t = now()
        db.slips().update(s.copy(status = "VOID", voidReason = reason.trim(), meta = s.meta.copy(updatedAt = t, updatedBy = user, updatedDeviceId = deviceId)))
        audit("PayrollSlip", id, "VOID", s.status, "VOID", reason.trim(), user, t)
        FinResult.Ok(Unit)
    }

    // ───────────── المستخدمون ─────────────
    suspend fun createUser(name: String, role: String, pin: String, perms: Set<String>, user: String): FinResult<String> = tx {
        if (name.isBlank()) return@tx err("الاسم مطلوب")
        if (pin.length !in 4..8 || !pin.all { it.isDigit() }) return@tx err("الـ PIN يجب أن يكون من 4 إلى 8 أرقام")
        val salt = PinHasher.newSalt()
        val t = now()
        val u = AppUser(uid(), name.trim(), role, PinHasher.hash(pin.toCharArray(), salt),
            java.util.Base64.getEncoder().encodeToString(salt), perms.joinToString(","), true, meta(user, t))
        db.users().insert(u)
        audit("User", u.id, "CREATE", null, "role=$role", null, user, t)
        FinResult.Ok(u.id)
    }

    suspend fun updateUser(id: String, name: String, role: String, perms: Set<String>, active: Boolean, newPin: String?, user: String): FinResult<Unit> = tx {
        val u = db.users().get(id) ?: return@tx err("المستخدم غير موجود")
        var hash = u.pinHash; var saltB64 = u.pinSalt
        if (!newPin.isNullOrEmpty()) {
            if (newPin.length !in 4..8 || !newPin.all { it.isDigit() }) return@tx err("الـ PIN يجب أن يكون من 4 إلى 8 أرقام")
            val salt = PinHasher.newSalt(); hash = PinHasher.hash(newPin.toCharArray(), salt)
            saltB64 = java.util.Base64.getEncoder().encodeToString(salt)
        }
        val others = db.users().all().filter { it.id != id && it.active && it.role == "ADMIN" }
        if ((!active || role != "ADMIN") && u.role == "ADMIN" && others.isEmpty()) return@tx err("يجب أن يبقى مدير فعّال واحد على الأقل")
        val t = now()
        db.users().update(u.copy(name = name.trim(), role = role, permissionsCsv = perms.joinToString(","), active = active,
            pinHash = hash, pinSalt = saltB64, meta = u.meta.copy(updatedAt = t, updatedBy = user, updatedDeviceId = deviceId)))
        audit("User", id, "UPDATE", "role=${u.role};active=${u.active}", "role=$role;active=$active", null, user, t)
        FinResult.Ok(Unit)
    }

    companion object { const val MAX_AMOUNT = 100_000_000_000L }
}
