package com.generator.accounts.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.generator.accounts.data.TableRow

@Composable
fun Screen(title: String, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    val t = LocalTok.current
    Column(Modifier.fillMaxSize().background(t.bg)) {
        Row(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(t.dark, t.primary))).padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = Color.White) }
            Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
            actions()
        }
        content()
    }
}

@Composable
fun Card2(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val t = LocalTok.current
    val m = modifier.shadow2(t).clip(RoundedCornerShape(t.radius.dp)).background(t.card).let { if (onClick != null) it.clickable(onClick = onClick) else it }
    Column(m.padding(14.dp), content = content)
}

private fun Modifier.shadow2(t: Tokens): Modifier = this.then(Modifier.drawBehind { })   // ظل خفيف عبر الحدود أدناه
    .border(1.dp, t.line, RoundedCornerShape(t.radius.dp))

@Composable
fun IconBadge(icon: ImageVector, color: Color, size: Int = 40) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(Brush.linearGradient(listOf(color, color.copy(alpha = 0.65f)))), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size((size * 0.55f).dp))
    }
}

@Composable
fun Kpi(title: String, value: String, icon: ImageVector, color: Color, modifier: Modifier = Modifier) {
    val t = LocalTok.current
    Card2(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon, color)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, color = t.sub, fontSize = 12.sp)
                Text(value, color = t.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
    }
}

@Composable
fun BigButton(text: String, color: Color, modifier: Modifier = Modifier.fillMaxWidth(), enabled: Boolean = true, icon: ImageVector? = null, onClick: () -> Unit) {
    val t = LocalTok.current
    Button(onClick = onClick, enabled = enabled, modifier = modifier.height(52.dp), shape = RoundedCornerShape(t.radius.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White,
            disabledContainerColor = Color(0xFF94A3B8), disabledContentColor = Color.White)) {
        if (icon != null) { Icon(icon, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier.fillMaxWidth(),
          number: Boolean = false, phone: Boolean = false, singleLine: Boolean = true, password: Boolean = false, readOnly: Boolean = false) {
    val t = LocalTok.current
    OutlinedTextField(value = value, onValueChange = onChange, label = { Text(label) }, modifier = modifier, singleLine = singleLine, readOnly = readOnly,
        keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Number else if (phone) KeyboardType.Phone else if (password) KeyboardType.NumberPassword else KeyboardType.Text),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        shape = RoundedCornerShape((t.radius / 1.5f).dp),
        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = t.text, unfocusedTextColor = t.text, focusedBorderColor = t.primary,
            unfocusedBorderColor = t.line, focusedLabelColor = t.primary, unfocusedLabelColor = t.sub, cursorColor = t.primary,
            focusedContainerColor = t.card, unfocusedContainerColor = t.card))
}

@Composable
fun Chips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    val t = LocalTok.current
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (k, label) ->
            val on = k == selected
            Box(Modifier.clip(RoundedCornerShape(50)).background(if (on) t.primary else t.card)
                .border(1.dp, if (on) t.primary else t.line, RoundedCornerShape(50)).clickable { onSelect(k) }.padding(horizontal = 14.dp, vertical = 8.dp)) {
                Text(label, color = if (on) Color.White else t.text, fontSize = 14.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}

@Composable
fun Empty(text: String) {
    val t = LocalTok.current
    Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(64.dp).clip(CircleShape).background(t.altRow))
            Spacer(Modifier.height(12.dp))
            Text(text, color = t.sub, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = LocalTok.current.text, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(vertical = 6.dp))
}

@Composable
fun Info(label: String, value: String, color: Color? = null) {
    val t = LocalTok.current
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, color = t.sub, modifier = Modifier.weight(1f), fontSize = 14.sp)
        Text(value, color = color ?: t.text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun ReasonDialog(title: String, confirmLabel: String, danger: Boolean = true, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    val t = LocalTok.current
    var reason by remember { mutableStateOf("") }
    var sure by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("السبب (مطلوب)", reason, { reason = it })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(sure, { sure = it }); Text("أؤكد أنني أريد تنفيذ هذه العملية", fontSize = 13.sp)
                }
            }
        },
        confirmButton = { TextButton(enabled = sure && reason.trim().length >= 3, onClick = { onConfirm(reason.trim()) }) {
            Text(confirmLabel, color = if (danger) t.bad else t.primary, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("تراجع", color = t.sub) } })
}

@Composable
fun ConfirmDialog(title: String, body: String, confirmLabel: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    val t = LocalTok.current
    AlertDialog(onDismissRequest = onDismiss, containerColor = t.card, titleContentColor = t.text, textContentColor = t.text,
        title = { Text(title) }, text = { Text(body) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmLabel, color = t.primary, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("تراجع", color = t.sub) } })
}

/**
 * جدول حقيقي: رأس ثابت عند التمرير العمودي، عمود أول (الاسم) ثابت عند التمرير الأفقي،
 * صفوف متناوبة، فرز بالضغط على العنوان، صف إجمالي ثابت، وتحميل تدريجي.
 */
@Composable
fun DataTable(
    headers: List<String>, rows: List<TableRow>, totals: List<String>?, widths: List<Int>,
    modifier: Modifier = Modifier, sortCol: Int = -1, sortDesc: Boolean = false, onSort: ((Int) -> Unit)? = null,
    onRowClick: ((TableRow) -> Unit)? = null, colorFor: (Int, TableRow) -> Color? = { _, _ -> null },
    hasMore: Boolean = false, onLoadMore: () -> Unit = {}
) {
    val t = LocalTok.current
    val hs = rememberScrollState()
    fun w(i: Int) = (widths.getOrNull(i) ?: 110).dp
    @Composable fun cell(text: String, i: Int, color: Color, bold: Boolean = false, onClick: (() -> Unit)? = null) {
        Box(Modifier.width(w(i)).heightIn(min = 46.dp)
            .drawBehind { drawLine(t.line, Offset(0f, 0f), Offset(0f, size.height), 1f) }
            .let { if (onClick != null) it.clickable(onClick = onClick) else it }.padding(horizontal = 8.dp, vertical = 8.dp), contentAlignment = Alignment.CenterStart) {
            Text(text, color = color, fontSize = 13.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
    Column(modifier.clip(RoundedCornerShape((t.radius / 2).dp)).border(1.dp, t.line, RoundedCornerShape((t.radius / 2).dp))) {
        Row(Modifier.fillMaxWidth().background(t.dark)) {
            fun h(i: Int) = headers[i] + if (i == sortCol) (if (sortDesc) " ▼" else " ▲") else ""
            if (headers.isNotEmpty()) cell(h(0), 0, Color.White, true, onSort?.let { f -> { f(0) } })
            Row(Modifier.weight(1f).horizontalScroll(hs)) { for (i in 1 until headers.size) cell(h(i), i, Color.White, true, onSort?.let { f -> { f(i) } }) }
        }
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(rows) { idx, row ->
                Column {
                    Row(Modifier.fillMaxWidth().background(if (idx % 2 == 0) t.card else t.altRow)
                        .let { if (onRowClick != null) it.clickable { onRowClick(row) } else it }) {
                        if (row.cells.isNotEmpty()) cell(row.cells[0], 0, colorFor(0, row) ?: t.text, true)
                        Row(Modifier.weight(1f).horizontalScroll(hs)) {
                            for (i in 1 until row.cells.size) cell(row.cells[i], i, colorFor(i, row) ?: t.text)
                        }
                    }
                    HorizontalDivider(color = t.line)
                }
            }
            if (hasMore) item {
                LaunchedEffect(rows.size) { onLoadMore() }
                Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(24.dp)) }
            }
            if (rows.isEmpty() && !hasMore) item { Empty("لا توجد بيانات") }
        }
        if (totals != null) Row(Modifier.fillMaxWidth().background(t.accent.copy(alpha = if (t.isDark) 0.35f else 0.28f))) {
            cell(totals.getOrElse(0) { "" }, 0, t.text, true)
            Row(Modifier.weight(1f).horizontalScroll(hs)) { for (i in 1 until totals.size) cell(totals[i], i, t.text, true) }
        }
    }
}

@Composable
fun Banner() {
    val app = LocalApp.current
    val t = LocalTok.current
    val m = app.message
    LaunchedEffect(m) { if (m != null) { kotlinx.coroutines.delay(3500); if (app.message == m) app.message = null } }
    if (m != null) Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.TopCenter) {
        Text(m, color = Color.White, modifier = Modifier.clip(RoundedCornerShape(t.radius.dp)).background(t.dark).padding(14.dp, 10.dp), fontSize = 14.sp)
    }
}
