package com.generator.accounts.core

data class OpenInvoice(val invoiceId: String, val dueEpochDay: Long, val outstanding: Long)
data class AllocationLine(val invoiceId: String, val amount: Long)

/** توزيع الدفعة (Long فقط). الأقدم أولاً، أو توزيع يدوي بعد التحقق. */
object PaymentAllocator {
    sealed class Result {
        data class Ok(val lines: List<AllocationLine>) : Result()
        data class Error(val message: String) : Result()
    }

    fun autoOldestFirst(open: List<OpenInvoice>, amount: Long): Result {
        if (amount <= 0) return Result.Error("المبلغ يجب أن يكون أكبر من صفر")
        val totalDue = open.sumOf { maxOf(0L, it.outstanding) }
        if (totalDue == 0L) return Result.Error("لا توجد مبالغ مستحقة على هذا المشترك")
        if (amount > totalDue) return Result.Error("المبلغ أكبر من إجمالي المستحق")
        var left = amount
        val out = ArrayList<AllocationLine>()
        for (inv in open.filter { it.outstanding > 0 }.sortedBy { it.dueEpochDay }) {
            if (left == 0L) break
            val take = minOf(left, inv.outstanding)
            out += AllocationLine(inv.invoiceId, take)
            left -= take
        }
        return Result.Ok(out)
    }

    fun manual(open: List<OpenInvoice>, amount: Long, lines: List<AllocationLine>): Result {
        if (amount <= 0) return Result.Error("المبلغ يجب أن يكون أكبر من صفر")
        if (lines.any { it.amount <= 0 }) return Result.Error("مبلغ توزيع غير صالح")
        if (lines.sumOf { it.amount } != amount) return Result.Error("مجموع التوزيع لا يساوي المبلغ")
        val byId = open.associateBy { it.invoiceId }
        for (l in lines) {
            val inv = byId[l.invoiceId] ?: return Result.Error("فاتورة غير موجودة")
            if (l.amount > inv.outstanding) return Result.Error("التوزيع يتجاوز المتبقي في فاتورة")
        }
        return Result.Ok(lines)
    }
}
